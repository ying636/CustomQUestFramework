﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;
using HarmonyLib;
using RimWorld.Planet;

namespace QuestEditor_Library
{
    [HarmonyPatch(typeof(SitePartParams), "ExposeData")]
    public class Patch_SitePartParams
    {
        [HarmonyPostfix]
        static void PostFix(SitePartParams __instance)
        {
            if (__instance is CustomSitePartParams customParams) 
            {
                Scribe_Values.Look(ref customParams.expandingIconPath, "QE_CustomParams_expandingIconPath");
                Scribe_Values.Look(ref customParams.siteIconPath, "QE_CustomParams_siteIconPath");
                Scribe_Defs.Look(ref customParams.mapData, "QE_CustomParams_mapData");
                Scribe_References.Look(ref customParams.quest, "QE_CustomParams_quest");
            }
        }
    }
}