﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;
using HarmonyLib;
using RimWorld.Planet;

namespace QuestEditor_Library
{
    [HarmonyPatch(typeof(PawnUIOverlay), "DrawPawnGUIOverlay")]
    public class Patch_DrawQuestIcon
    {
        [HarmonyPostfix]
        static void PostFix(PawnUIOverlay __instance,Pawn ___pawn)
        {
            if (GameComponent_Editor.component != null && GameComponent_Editor.component.Dialogs.ContainsKey(___pawn)) 
            {
                ___pawn?.Map?.overlayDrawer?.DrawOverlay(___pawn, OverlayTypes.QuestionMark);
            }
        }
    }
}