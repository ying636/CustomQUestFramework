﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;
using HarmonyLib;
using RimWorld.Planet;
using UnityEngine;

namespace QuestEditor_Library
{
    [HarmonyPatch(typeof(Site), "ExpandingIcon", MethodType.Getter)]
    public class Patch_SiteTextureEx
    {
        public static Texture2D GetTexture(string path) 
        {
            if (!Patch_SiteTextureEx.siteTexture.ContainsKey(path)) 
            {
                Patch_SiteTextureEx.siteTexture.Add(path,ContentFinder<Texture2D>.Get(path));
            }
            return Patch_SiteTextureEx.siteTexture[path];
        }
        [HarmonyPrefix]
        public static bool Prefix(Site __instance,ref Texture2D __result)
        {
            if (__instance.parts.Find(x => x.def.defName == "QE_CustomSite") is SitePart part) 
            {
                __result = Patch_SiteTextureEx.GetTexture(((CustomSitePartParams)(part.parms)).expandingIconPath);
                return false;
            }
            return true;
        }
        public static Dictionary<string, Texture2D> siteTexture = new Dictionary<string, Texture2D>();
    }

    [HarmonyPatch(typeof(Site), "Material", MethodType.Getter)]
    public class Patch_SiteTexture
    {
        public static Material GetTexture(string path,SitePart part,Site __instance)
        {
            if (!Patch_SiteTexture.siteTexture.ContainsKey(path))
            {
                Color color = __instance.Faction == null ? Color.white : __instance.Faction.Color;
                Patch_SiteTexture.siteTexture.Add(path, MaterialPool.MatFrom(((CustomSitePartParams)(part.parms)).siteIconPath, ShaderDatabase.WorldOverlayTransparentLit, color, WorldMaterials.WorldObjectRenderQueue));
            }
            return Patch_SiteTexture.siteTexture[path];
        }
        [HarmonyPrefix]
        public static bool PreFix(Site __instance,ref Material __result)
        {
            if (__instance.parts.Find(x => x.def.defName == "QE_CustomSite") is SitePart part)
            {
                __result = Patch_SiteTexture.GetTexture(((CustomSitePartParams)(part.parms)).siteIconPath,part,__instance);
                return false;
            }
            return true;
        }
        public static Dictionary<string, Material> siteTexture = new Dictionary<string, Material>();
    }
}