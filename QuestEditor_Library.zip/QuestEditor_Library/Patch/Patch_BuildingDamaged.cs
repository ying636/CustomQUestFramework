﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;
using HarmonyLib;
using Verse.AI.Group;

namespace QuestEditor_Library
{
    [HarmonyPatch(typeof(Building), "PreApplyDamage")]
    public class Patch_BuildingDamaged
    {
        [HarmonyPostfix]
        public static void PostFix(Building __instance)
        {
            if (__instance.Spawned && __instance.Map.GetComponent<MapComponent_CustomMapData>() is MapComponent_CustomMapData component && component.PawnSpawnDatas_Building.TryGetValue(__instance, out List<PawnSpawnData> list))
            {
                foreach (PawnSpawnData data in list)
                {
                    if (data.spawnType == SpawnType.BuildingDamaged)
                    {
                        data.Spawn(__instance.Position,__instance.Map, null,component.QuestTag);
                    }
                }
            }
        }
    }
    [HarmonyPatch(typeof(Building), "Destroy")]
    public class Patch_BuildingDestroy
    {
        [HarmonyPrefix]
        public static bool PreFix(Building __instance)
        {
            if (__instance.Spawned && __instance.Map.GetComponent<MapComponent_CustomMapData>() is MapComponent_CustomMapData component && component.PawnSpawnDatas_Building.TryGetValue(__instance, out List<PawnSpawnData> list))
            {
                foreach (PawnSpawnData data in list)
                {
                    if (data.spawnType == SpawnType.BuildingDestroyed)
                    {
                        data.Spawn(__instance.Position, __instance.Map, null, component.QuestTag);
                    }
                }
            }
            return true;
        }
    }
}