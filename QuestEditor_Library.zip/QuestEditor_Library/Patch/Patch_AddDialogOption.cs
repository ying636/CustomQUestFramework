﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;
using HarmonyLib;
using UnityEngine;
using Verse.AI;

namespace QuestEditor_Library
{
    [HarmonyPatch(typeof(FloatMenuMakerMap), "AddHumanlikeOrders")]
    public class Patch_AddDialogOption
    {
        [HarmonyPostfix]
        public static void postfix(Vector3 clickPos, Pawn pawn, List<FloatMenuOption> opts)
        {
            if (clickPos.InBounds(pawn.Map) && Current.Game.GetComponent<GameComponent_Editor>().Dialogs is Dictionary<Thing, DialogManagerDef> dialogs && dialogs.Any())
            {
                foreach (Thing thing in clickPos.ToIntVec3().GetThingList(pawn.Map))
                {
                    if (dialogs.TryGetValue(thing, out DialogManagerDef manager) && manager.GetTree(pawn, thing) is DialogTreeDef def) 
                    {
                        if (def.requireNonHostile && thing.HostileTo(pawn)) 
                        {
                            opts.Add(new FloatMenuOption("UnableToInterviewTargetIsHostile".Translate().CapitalizeFirst(), null));
                            return;
                        }
                        if (!pawn.CanReach(thing, PathEndMode.OnCell, Danger.Deadly))
                        {
                            opts.Add(new FloatMenuOption("NoPath".Translate().CapitalizeFirst(),null));
                        }
                        else 
                        {
                            opts.Add(new FloatMenuOption(def.dialogReportKey.Translate(thing is Pawn target ? target.Name.ToString() : thing.Label),() => 
                            {
                                Job job = JobMaker.MakeJob(QEDefOf.QE_StartDialog, thing);
                                job.reportStringOverride = def.dialogReportKey.Translate();
                                pawn.jobs.StartJob(job);
                            }));
                        }
                    }
                } 
            }
        }
    }
}
