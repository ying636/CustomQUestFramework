﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;
using System.Xml;
using System.Xml.Linq;
using RimWorld.QuestGen;
using Verse.Grammar;
using System.Reflection;
using UnityEngine;
using System.Collections;
using Verse.AI;
using Verse.AI.Group;
using System.IO;

namespace QuestEditor_Library
{
    [StaticConstructorOnStartup]
    public static class EditorTools
    {
        public static List<string> TargetTexts => new List<string>() { "Interviewee", "Interviewer", "CustomThing", "Trigger" };
        public static List<ThingDef> MapExitDefs
        {
            get
            {
                if (!EditorTools.customMapExitDefs.Any())
                {
                    DefDatabase<ThingDef>.AllDefsListForReading.ForEach(x =>
                    {
                        if (x.thingClass.IsSubclassOf(typeof(CustomMapExit)) || x.thingClass == typeof(CustomMapExit))
                        {
                            EditorTools.customMapExitDefs.Add(x);
                        }
                    });
                }
                return EditorTools.customMapExitDefs;
            }
        }
        public static void DrawLabelAndText_SlateRef_Line(float y, string label, ref SlateRef<string> text, float x = 0f, float width = 60f)
        {
            Widgets.Label(new Rect(x, y, 350f, 20f), label);
            string bufferText = Widgets.TextField(new Rect(Text.CalcSize(label).x + x + 5f, y, width, 20f), text.ToString());
            text = text.ToString() == bufferText ? text : new SlateRef<string>(bufferText);
        }
        public static void DrawLabelAndText_SlateRef_Line<T>(float y, string label, ref SlateRef<T> text, float x = 0f, float width = 60f)
        {
            Widgets.Label(new Rect(x, y, 350f, 25f), label);
            string bufferText = Widgets.TextField(new Rect(Text.CalcSize(label).x + x + 5f, y, width, 25f), text.ToString());
            text = text.ToString() == bufferText ? text : new SlateRef<T>(bufferText);
        }
        public static void DrawLabelAndText_Line<T>(float y, string label, ref T text, ref string buffer, float x = 0f, float width = 60f) where T : struct
        {
            Widgets.Label(new Rect(x, y, 350f, 25f), label);
            Widgets.TextFieldNumeric<T>(new Rect(Text.CalcSize(label).x + x + 5f, y, width, 25f), ref text, ref buffer);
        }
        public static void DrawLabelAndText_Line(float y, string label, ref float text, ref string buffer, float x = 0f, float width = 60f)
        {
            Widgets.Label(new Rect(x, y, 350f, 25f), label);
            Widgets.TextFieldPercent(new Rect(Text.CalcSize(label).x + x + 5f, y, width, 25f), ref text, ref buffer);
        }
        public static void DrawLabelAndText_Line(float y, string label, ref string text, float x = 0f, float width = 60f)
        {
            bool nullText = label.NullOrEmpty();
            if (!nullText)
            {
                Widgets.Label(new Rect(x, y, 350f, 25f), label);
            }
            text = Widgets.TextField(new Rect(nullText ? x + 5f : Text.CalcSize(label).x + x + 5f, y, width, 25f), text);
        }
        public static void DrawSelectableText(float y, string label, ref string text,Action selectAction,float x = 0f, float width = 60f)
        {
            bool nullText = label.NullOrEmpty();
            if (!nullText)
            {
                if (Widgets.ButtonText(new Rect(x, y,Text.CalcSize(label).x, 25f), label,false)) 
                {
                    selectAction();
                }
            }
            text = Widgets.TextField(new Rect(nullText ? x + 5f : Text.CalcSize(label).x + x + 5f, y, width, 25f), text);
        }
        public static void DrawFieldAndText(ref float y, string label, ref string text, float x = 0f, float width = 350f)
        {
            Widgets.Label(new Rect(x, y, width, 25f), label);
            y += 25f;
            text = Widgets.TextField(new Rect(x, y, width, 25f), text);
        }
        public static void DrawIntRange(ref float y, string label, ref IntRange num,ref string bufferMin,ref string bufferMax, float x = 0f, float width = 30f)
        {
            Widgets.Label(new Rect(x, y, 350f, 25f), label);
            int min = num.min;
            int max = num.max;
            Rect rect = new Rect(Text.CalcSize(label).x + x + 5f, y, width, 25f);
            Widgets.TextFieldNumeric(rect, ref min, ref bufferMin);
            rect.x += width;
            Widgets.Label(rect,"~");
            rect.x += 7f;
            Widgets.TextFieldNumeric(rect, ref max, ref bufferMax);
            num = new IntRange(min, max);
        }

        public static void DrawFloatRange(ref float y, string label, ref FloatRange num, ref string bufferMin, ref string bufferMax, float x = 0f, float width = 30f)
        {
            Widgets.Label(new Rect(x, y, 350f, 25f), label);
            float min = num.min;
            float max = num.max;
            Rect rect = new Rect(Text.CalcSize(label).x + x + 5f, y, width, 25f);
            Widgets.TextFieldNumeric(rect, ref min, ref bufferMin);
            rect.x += width;
            Widgets.Label(rect, "~");
            rect.x += 7f;
            Widgets.TextFieldNumeric(rect, ref max, ref bufferMax);
            num = new FloatRange(min,max);
        }


        public static void DrawButtonAndText(ref float y, string text, string buttonText, Action buttonAction, float x = 0f)
        {
            Widgets.Label(new Rect(x, y, 300f, 25f), text);
            y += 30f;
            if (Widgets.ButtonText(new Rect(x, y, 200f, 25f), buttonText))
            {
                buttonAction();
            }
            y += 30f;
        }
        public static void DrawFloatMenu<T>(List<T> list, Action<T> action, Func<T, string> text, List<FloatMenuOption> extra = null, Func<T, bool> validator = null)
        {
            List<FloatMenuOption> options = new List<FloatMenuOption>();
            if (extra != null)
            {
                options.AddRange(extra);
            }
            foreach (T t in list)
            {
                if (validator == null || validator(t))
                {
                    FloatMenuOption option = new FloatMenuOption(text(t), () =>
                    {
                        action(t);
                    });
                    options.Add(option);
                }
            }
            if (options.Any())
            {
                Find.WindowStack.Add(new FloatMenu(options));
            }
        }
        public static List<FloatMenuOption> DrawFloatMenuWithRsult<T>(List<T> list, Action<T> action, Func<T, string> text, List<FloatMenuOption> extra = null, Func<T, bool> validator = null)
        {
            List<FloatMenuOption> options = new List<FloatMenuOption>();
            if (extra != null)
            {
                options.AddRange(extra);
            }
            foreach (T t in list)
            {
                if (validator == null || validator(t))
                {
                    FloatMenuOption option = new FloatMenuOption(text(t), () =>
                    {
                        action(t);
                    });
                    options.Add(option);
                }
            }
            return options;
        }
        public static void DrawFloatMenu<T, V>(Dictionary<T, V> dictionary, Action<T, V> action, Func<T, V, string> text, List<FloatMenuOption> extra = null, Func<T, V, bool> validator = null)
        {
            List<FloatMenuOption> options = new List<FloatMenuOption>();
            if (extra != null)
            {
                options.AddRange(extra);
            }
            foreach (KeyValuePair<T, V> pair in dictionary)
            {
                if (validator == null || validator(pair.Key, pair.Value))
                {
                    FloatMenuOption option = new FloatMenuOption(text(pair.Key, pair.Value), () =>
                     {
                         action(pair.Key, pair.Value);
                     });
                    options.Add(option);
                }
            }
            if (options.Any())
            {
                Find.WindowStack.Add(new FloatMenu(options));
            }
        }
        public static void DrawButtonForList(ref float y, List<string> list, Func<string, string> getText, float x = 10f, float interval = 290f, Vector2? size = null)
        {
            if (size == null)
            {
                size = new Vector2(120f, 25f);
            }
            if (Widgets.ButtonText(new Rect(x + 5f, y, size.Value.x, size.Value.y), "Add".Translate()))
            {
                list.Add("undefined");
            }
            if (Widgets.ButtonText(new Rect(x + 5f + interval, y, size.Value.x, size.Value.y), "Remove".Translate()) && list.Any())
            {
                EditorTools.DrawFloatMenu(list, (d) => list.Remove(d), (d) => getText(d));
            }
            y += size.Value.y + 5f;
        }

        public static void DrawButtonForList<T>(ref float y, List<T> list, Func<T, string> getText, float x = 10f, float interval = 290f, Vector2? size = null) where T : new()
        {
            if (size == null)
            {
                size = new Vector2(120f, 35f);
            }
            if (Widgets.ButtonText(new Rect(x + 5f, y, size.Value.x, size.Value.y), "Add".Translate()))
            {
                list.Add(new T());
            }
            if (Widgets.ButtonText(new Rect(x + 5f + interval, y, size.Value.x, size.Value.y), "Remove".Translate()) && list.Any())
            {
                EditorTools.DrawFloatMenu<T>(list, (d) => list.Remove(d), (d) => getText(d));
            }
            y += 40f;
        }
        public static void DrawButtonForList<T>(ref float y, List<T> list, Func<T, string> getText, Action addAction, float x = 10f, float interval = 290f, Vector2? size = null)
        {
            if (size == null)
            {
                size = new Vector2(120f, 35f);
            }
            if (Widgets.ButtonText(new Rect(x + 5f, y, size.Value.x, size.Value.y), "Add".Translate()))
            {
                addAction();
            }
            if (Widgets.ButtonText(new Rect(x + 5f + interval, y, size.Value.x, size.Value.y), "Remove".Translate()) && list.Any())
            {
                EditorTools.DrawFloatMenu<T>(list, (d) => list.Remove(d), (d) => getText(d));
            }
            y += 40f;
        }
        public static void DrawButtonForList<T>(ref float y, List<T> list, Func<T, string> getText, Action<T> addAction, Action removeAction, float x = 10f)
        {
            if (Widgets.ButtonText(new Rect(x + 5f, y, 120f, 35f), "Add".Translate()))
            {
                EditorTools.DrawFloatMenu<T>(list, (d) => addAction(d), (d) => getText(d));
            }
            if (Widgets.ButtonText(new Rect(x + 295f, y, 120f, 35f), "Remove".Translate()) && list.Any())
            {
                removeAction();
            }
            y += 40f;
        }
        public static void DrawButtonForPawnData(float y, List<PawnSpawnData> list, float x = 10f)
        {
            if (Widgets.ButtonText(new Rect(x + 5f, y, 120f, 38f), "AddNewPawns".Translate()))
            {
                List<Type> types = new List<Type>();
                types.Add(typeof(PawnSpawnData));
                types.AddRange(typeof(PawnSpawnData).AllSubclassesNonAbstract());
                EditorTools.DrawFloatMenu(types, a =>
     list.Add((PawnSpawnData)Activator.CreateInstance(a)), a => a.Name.Translate());
            }
            if (Widgets.ButtonText(new Rect(x + 150f, y, 120f, 38f), "PastePawns".Translate()) && EditorTools.data != null)
            {
                list.Add(EditorTools.data);
            }
            if (Widgets.ButtonText(new Rect(x + 295f, y, 120f, 38f), "DeleteNewPawns".Translate()) && list.Any())
            {
                EditorTools.DrawFloatMenu<PawnSpawnData>(list, (d) => list.Remove(d), (d) => d.dataName);
            }
        }

        public static void DrawEditableStringList(List<string> list, ref float y, string title = null, string tip = null, bool needBox = false, float x = 10f,float width = 180f)
        {
            float initY = y;
            if (title != null)
            {
                y += 5f;
                Text.Font = GameFont.Medium;
                Rect rectTitle = new Rect(x + 10, y, 1020f, 35f);
                Widgets.Label(rectTitle, title.Colorize(ColorLibrary.SkyBlue));
                if (tip != null)
                {
                    TooltipHandler.TipRegionByKey(rectTitle, tip);
                }
                Text.Font = GameFont.Small;
                y += 40f;
                float textWidth = Text.CalcSize(title).x + 20f;
                width = textWidth > width ? textWidth : width;
            }
            Rect textField = new Rect(x + 10, y, 150f, 25f);
            for (int i = 0; i < list.Count; i++)
            {
                string text = list[i];
                list[i] = Widgets.TextField(textField, text);
                y += 30f;
                textField.y += 30f;
            }
            y += 5f;
            if (needBox)
            {
                Widgets.DrawBox(new Rect(x, initY, width, y - initY), 1, QuestEditor_Dialog.blueTex);
            }
            y += 10f;
            EditorTools.DrawButtonForList(ref y, list, t => t, x - 5f, width - 70f, new Vector2(70f, 25f));
        }
        public static void DrawSelectableStringList(List<string> list, ref float y, Action<Rect, string,int> drawAction, string title = null, string tip = null, bool needBox = false, float x = 10f, float defaultWidth = 180f)
        {
            float initY = y;
            float width = defaultWidth;
            if (title != null)
            {
                y += 5f;
                Text.Font = GameFont.Medium;
                Rect rectTitle = new Rect(x + 10, y, 1020f, 35f);
                Widgets.Label(rectTitle, title.Colorize(ColorLibrary.SkyBlue));
                if (tip != null)
                {
                    TooltipHandler.TipRegionByKey(rectTitle, tip);
                }
                Text.Font = GameFont.Small;
                y += 40f;
                float textWidth = Text.CalcSize(title).x + 20f;
                width = textWidth > width ? textWidth : width;
            }
            Rect textField = new Rect(x + 10, y, 150f, 25f);
            for (int i = 0; i < list.Count; i++)
            {
                drawAction(textField, list[i],i);
                y += 30f;
                textField.y += 30f;
            }
            y += 5f;
            if (needBox)
            {
                Widgets.DrawBox(new Rect(x, initY, width, y - initY), 1, QuestEditor_Dialog.blueTex);
            }
            y += 5f;
            EditorTools.DrawButtonForList(ref y, list, t => t, x - 5f, width - 70f, new Vector2(70f, 25f));
        }
        public static void DrawEditableList<T>(List<T> list, ref float y, Action<Rect, T> drawAction, Func<T, string> getText, string title = null, string tip = null, bool needBox = false, float x = 10f, float defaultWidth = 180f) where T : new()
        {
            float initY = y;
            float width = defaultWidth;
            if (title != null)
            {
                y += 5f;
                Text.Font = GameFont.Medium;
                Rect rectTitle = new Rect(x + 10, y, 1020f, 35f);
                Widgets.Label(rectTitle, title.Colorize(ColorLibrary.SkyBlue));
                if (tip != null)
                {
                    TooltipHandler.TipRegionByKey(rectTitle, tip);
                }
                Text.Font = GameFont.Small;
                y += 40f;
                float textWidth = Text.CalcSize(title).x + 20f;
                width = textWidth > width ? textWidth : width;
            }
            Rect textField = new Rect(x + 10, y, 150f, 25f);
            for (int i = 0; i < list.Count; i++)
            {
                drawAction(textField, list[i]);
                y += 30f;
                textField.y += 30f;
            }
            y += 5f;
            if (needBox)
            {
                Widgets.DrawBox(new Rect(x, initY, width, y - initY), 1, QuestEditor_Dialog.blueTex);
            }
            y += 10f;
            EditorTools.DrawButtonForList<T>(ref y, list, t => getText(t), x - 5f, width - 70f, new Vector2(70f, 25f));
        }
        public static void DrawEditableList<T>(List<T> list, ref float y, Action<Rect, T> drawAction, Func<T, string> getText,Action addAction,string title = null, string tip = null, bool needBox = false, float x = 10f, float defaultWidth = 180f) where T : new()
        {
            float initY = y;
            float width = defaultWidth;
            if (title != null)
            {
                y += 5f;
                Text.Font = GameFont.Medium;
                Rect rectTitle = new Rect(x + 10, y, 1020f, 35f);
                Widgets.Label(rectTitle, title.Colorize(ColorLibrary.SkyBlue));
                if (tip != null)
                {
                    TooltipHandler.TipRegionByKey(rectTitle, tip);
                }
                Text.Font = GameFont.Small;
                y += 40f;
                float textWidth = Text.CalcSize(title).x + 20f;
                width = textWidth > width ? textWidth : width;
            }
            Rect textField = new Rect(x + 10, y, 150f, 25f);
            for (int i = 0; i < list.Count; i++)
            {
                drawAction(textField, list[i]);
                y += 30f;
                textField.y += 30f;
            }
            y += 5f;
            if (needBox)
            {
                Widgets.DrawBox(new Rect(x, initY, width, y - initY), 1, QuestEditor_Dialog.blueTex);
            }
            y += 10f;
            EditorTools.DrawButtonForList<T>(ref y, list, t => getText(t), addAction, x - 5f, width - 70f, new Vector2(70f, 25f));
        }
        public static void DrawIDrawList_UseWindow<T>(ref float y, float x, List<T> list, Rect inRect, string title,Func<T,string> getString) where T : IDrawable
        {
            Widgets.Label(new Rect(x, y, 255f, 25f), title.Colorize(ColorLibrary.PaleBlue));
            y += 30f;
            foreach (T d in list)
            {
                if (Widgets.ButtonText(new Rect(x,y,600f,25f), getString(d), false))
                {
                    Find.WindowStack.Add(new Dialog_EditIDrawable(d));
                }
                y += 30f;
            }
            y += 5f;
            List<Type> types = new List<Type>();
            if (!typeof(T).IsAbstract) 
            {
                types.Add(typeof(T));
            }
            types.AddRange(typeof(T).AllSubclassesNonAbstract());
            EditorTools.DrawButtonForList(ref y, list, d => d.GetType().Name.Translate(), () => EditorTools.DrawFloatMenu(types, a =>
  list.Add((T)Activator.CreateInstance(a)), a => a.Name.Translate()));
        }
        public static void DrawIDrawList_UseWindow(ref float y, float x, List<PawnSpawnData> list, Rect inRect, string title, Func<PawnSpawnData, string> getString)
        {
            Widgets.Label(new Rect(x, y, 255f, 25f), title.Colorize(ColorLibrary.PaleBlue));
            y += 30f;
            foreach (PawnSpawnData d in list)
            {
                if (Widgets.ButtonText(new Rect(x, y, 600f, 25f), getString(d), false))
                {
                    Find.WindowStack.Add(new Dialog_EditIDrawable(d));
                }
                y += 30f;
            }
            y += 5f;
            List<Type> types = new List<Type>();
            if (!typeof(PawnSpawnData).IsAbstract)
            {
                types.Add(typeof(PawnSpawnData));
            }
            types.AddRange(typeof(PawnSpawnData).AllSubclassesNonAbstract());
            EditorTools.DrawButtonForPawnData(y,list,x);
        }
        public static void DrawIDrawList<T>(ref float y, float x, List<T> list, Rect inRect, string title) where T : IDrawable
        {
            Widgets.Label(new Rect(x, y, 255f, 25f), title.Colorize(ColorLibrary.PaleBlue));
            y += 30f;
            Vector2 start = new Vector2(x, y);
            Vector2 end = new Vector2(inRect.width - (x * 2) - 10f, y);
            Widgets.DrawLine(start, end, ColorLibrary.SkyBlue, 1f);
            foreach (IDrawable d in list)
            {
                y += 3f;
                d.Draw(ref y, inRect, x);
                y += 3f;
                start.y = y;
                end.y = y;
                Widgets.DrawLine(start, end, ColorLibrary.SkyBlue, 1f);
            }
            y += 25f;
            EditorTools.DrawButtonForList(ref y, list,d => d.GetType().Name.Translate(),() => EditorTools.DrawFloatMenu(typeof(T).AllSubclassesNonAbstract(), a =>
list.Add((T)Activator.CreateInstance(a)), a => a.Name.Translate()));
        }
        public static void DrawIDrawList<T>(ref float y, float x, List<T> list, Rect inRect, string title,Action addAction,Func<T,string> getText) where T : IDrawable
        {
            Widgets.Label(new Rect(x, y, 255f, 25f), title.Colorize(ColorLibrary.PaleBlue));
            y += 30f;
            Vector2 start = new Vector2(x, y);
            Vector2 end = new Vector2(inRect.width - (x * 2) - 10f, y);
            Widgets.DrawLine(start, end, ColorLibrary.SkyBlue, 1f);
            foreach (IDrawable d in list)
            {
                y += 3f;
                d.Draw(ref y, inRect, x);
                y += 3f;
                start.y = y;
                end.y = y;
                Widgets.DrawLine(start, end, ColorLibrary.SkyBlue, 1f);
            }
            y += 25f;
            EditorTools.DrawButtonForList(ref y, list, getText,addAction);
        }
        public static void DrawIDrawList<T>(ref float y, float x, List<T> list, Rect inRect, string title, Action addAction, Func<T, string> getText,Func<T, float, Rect,float,float> drawAction)
        {
            Widgets.Label(new Rect(x, y, 255f, 25f), title.Colorize(ColorLibrary.PaleBlue));
            y += 30f;
            Vector2 start = new Vector2(x, y);
            Vector2 end = new Vector2(inRect.width - (x * 2) - 10f, y);
            Widgets.DrawLine(start, end, ColorLibrary.SkyBlue, 1f);
            foreach (T d in list)
            {
                y += 3f;
                y = drawAction(d,y,inRect,x);
                y += 3f;
                start.y = y;
                end.y = y;
                Widgets.DrawLine(start, end, ColorLibrary.SkyBlue, 1f);
            }
            y += 25f;
            EditorTools.DrawButtonForList(ref y, list, getText, addAction);
        }
        public static List<T> GetObject<T>(string path, string objectName)
        {
            List<T> result = new List<T>();
            DirectoryInfo ruleDir = new DirectoryInfo(path);
            foreach (FileInfo file in ruleDir.GetFiles("*.xml"))
            {
                XmlDocument xml = new XmlDocument();
                xml.Load(file.FullName);
                foreach (XmlNode xmlNode in xml.SelectNodes(objectName))
                {
                    result.Add(DirectXmlToObject.ObjectFromXml<T>(xmlNode, false));
                }
            }
            return result;
        }
        public static string GetSaveValue<T>(T t) 
        {
            return t is Def def ? def.defName : t.ToString();
        }
        public static XElement SaveDictionary<T, K>(Dictionary<T, K> dictionary, string nodeName)
        {
            XElement result = new XElement(nodeName);
            XElement li = new XElement("li");
            foreach (KeyValuePair<T, K> value in dictionary)
            {
                li.Add(new XElement("key", GetSaveValue(value.Key)));
                li.Add(new XElement("value", GetSaveValue(value.Value)));
            }
            result.Add(result);
            return result;
        }
        public static XElement SaveDictionary_Saveable<T,K>(Dictionary<T,K> dictionary, string nodeName) where K : ISaveable
        {
            XElement result = new XElement(nodeName);
            XElement li = new XElement("li");
            foreach (KeyValuePair<T, K> value in dictionary)
            {
                li.Add(new XElement("key", GetSaveValue(value.Key)));
                li.Add(value.Value.SaveToXElement("value"));
            }   
            result.Add(result);
            return result;
        }
        public static XElement SaveDictionary_List<T, K>(Dictionary<T,List<K>> dictionary, string nodeName)
        {
            XElement result = new XElement(nodeName);
            foreach (KeyValuePair<T, List<K>> value in dictionary)
            {   
                XElement li = new XElement("li");
                li.Add(new XElement("key", GetSaveValue(value.Key)));
                XElement valueX = new XElement("value");
                value.Value.ForEach(v => valueX.Add(new XElement("li",GetSaveValue(v))));
                li.Add(valueX);
                result.Add(li);
            }
            return result;
        }
        public static XElement SaveDictionary_Saveable_List<T, K>(Dictionary<T, List<K>> dictionary, string nodeName) where K : ISaveable
        {
            XElement result = new XElement(nodeName);
            foreach (KeyValuePair<T, List<K>> value in dictionary)
            {
                XElement li = new XElement("li");
                li.Add(new XElement("key", GetSaveValue(value.Key)));
                XElement valueX = new XElement("value");
                value.Value.ForEach(v => valueX.Add(v.SaveToXElement("li")));
                li.Add(valueX);
                result.Add(li);
            }
            return result;
        }
        public static XElement SaveList<T>(List<T> list, string nodeName)
        {
            XElement result = new XElement(nodeName);
            list.ForEach(x => result.Add(new XElement("li",GetSaveValue(x))));
            return result;
        }
        public static XElement SaveList_Saveable<T>(List<T> list, string nodeName) where T : ISaveable
        {
            XElement result = new XElement(nodeName);
            list.ForEach(x => result.Add(x.SaveToXElement("li")));
            return result;
        }


        public static List<TagWithChance> tagWithChance = new List<TagWithChance>();
        public static List<MapDefWithChance> mapDefWithChance = new List<MapDefWithChance>();

        public static InteractionOperation operation = null;
        public static PawnSpawnData data = null;
        public static LootData lootData = null;
        public static ActionComp actionComp = null;

        public static List<InteractionOperation> operations = new List<InteractionOperation>();
        public static List<InteractionDataDef> operationDefs = new List<InteractionDataDef>();

        public static string lootBoxName = "Undefined";
        public static int tickToOpen = 100;
        public static bool destroyAfterOpening = false;
        public static string openReport = "OpenLoot";
        public static List<LootData> loots = new List<LootData>();
        public static string buffer;
        public static bool useLootDef = true;
        public static LootDataDef lootDef = null;

        public static ThingData thingData = null;

        public static List<ThingDef> customMapExitDefs = new List<ThingDef>();

        public static Rot4 coreRotation = Rot4.Invalid;
        public static bool isCenter = true;
        public static ThingData reserveThing = null;
        public static List<ZoneCondition> conditions = new List<ZoneCondition>();
        public static List<string> coreTags = new List<string>();

        

        public static Dictionary<string, List<IntVec3>> route = new Dictionary<string, List<IntVec3>>();
        public static readonly Texture2D icon_Border = ContentFinder<Texture2D>.Get("UI/Border");
        public static readonly Texture2D icon_DestroyThing = ContentFinder<Texture2D>.Get("UI/Icons/Icon_DestroyThing");
        public static readonly Texture2D icon_Route = ContentFinder<Texture2D>.Get("UI/Icons/Icon_Route");

        public static bool disgenerateByCore = false;
    }
    public static class GameTools
    {
        public static List<Thing> AllConsumableThing(Map map)
        {
            return map.listerThings.AllThings.FindAll(t => !t.IsForbidden(Faction.OfPlayer) && !t.Position.Fogged(map)).ListFullCopy();
        }
        public static List<Thing> AllConsumableThingForDef(ThingDef def,Map map) 
        {
            return map.listerThings.ThingsOfDef(def).FindAll(t => !t.IsForbidden(Faction.OfPlayer) && !t.Position.Fogged(map)).ListFullCopy();
        }
        public static bool CheckRequiredThings(List<LootThingData> requiredThings, List<Thing> things,out ThingDef def,out int count)
        {
            Dictionary<ThingDef, int> counts = new Dictionary<ThingDef, int>();
            requiredThings.ForEach(d => counts.Add(((CQFThingDefCount)d).thing, d.count.min));
            foreach (Thing t in things)
            {
                if (counts.ContainsKey(t.def))
                {
                    counts[t.def] -= t.stackCount;
                }
            }
            if (counts.ToList().Find(c => c.Value > 0) is KeyValuePair<ThingDef, int> thing)
            {
                def = thing.Key;
                count = thing.Value;
                return false;
            }
            def = null;
            count = 0;
            return true;
        }
        public static void ConsumeRequiredThings(Pawn interviwer, Pawn interviwee,List<LootThingData> requiredThings)
        {
            if (requiredThings.Any())
            {
                if (interviwer.Map.IsPlayerHome)
                {
                    requiredThings.ForEach(d =>
                    {
                        GameTools.ConsumeThings(((CQFThingDefCount)d).thing, d.count.min, interviwer.Map, null);
                    });
                }
                else
                {
                    Dictionary<ThingCategoryDef, int> categoryAndCount = new Dictionary<ThingCategoryDef, int>();
                    foreach (LootThingData data in requiredThings)
                    {
                        if (data is CQFThingDefCount tData)
                        {
                            interviwer.inventory.innerContainer.Take(interviwer.inventory.innerContainer.ToList().Find(i => i.def == tData.thing), tData.count.min).Destroy();
                        }
                        if (data is CQFThingCategoryCount cData)
                        {
                            categoryAndCount.Add(cData.category, cData.count.min);
                        }
                    }
                }
            }
        }
        public static void ConsumeThings(ThingDef def,int count,Map map,Pawn receiver = null) 
        {
            foreach(Thing t in AllConsumableThingForDef(def,map))         
            {
                int spliteCount = t.stackCount <= count ? t.stackCount : count;
                Thing thing = t.SplitOff(spliteCount);
                count -= spliteCount;
                if (receiver == null)
                {
                    thing.Destroy();
                }
                else 
                {
                    receiver.inventory.TryAddAndUnforbid(thing);
                }
                if (count <= 0) 
                {
                    break;
                }
            };
        }
    }
    public class ThingData : IExposable , ISaveable
    {
        public void OpenSelectDialog()
        {
            Find.WindowStack.Add(new Dialog_Select<ThingDef>(Designator_SpawnThing.Bespawnable,
t => t.uiIcon, t => t.label, "Select".Translate(),
t =>
{
    this.def = t;
    this.hitPoint = t.BaseMaxHitPoints;
    if (t.MadeFromStuff)
    {
        Find.WindowStack.Add(new Dialog_Select<ThingDef>(GenStuff.AllowedStuffsFor(t).ToList(), s => s.uiIcon, s => s.label, "SelectStuff".Translate(), s =>
        {
            this.stuff = s;
            this.hitPoint = (int)(t.BaseMaxHitPoints * (s.stuffProps.statFactors.Find(s2 => s2.stat == StatDefOf.MaxHitPoints) is StatModifier stat ? stat.value : 1f));
        }, t2 => t2.graphic?.Color ?? Color.white));
    }
}, t => t.graphic?.Color ?? Color.white));
        }
        public ThingData(){ }
        public ThingData(Thing thing, IntVec3 pos)
        {
            this.def = thing.def;
            this.rotation = thing.Rotation;
            this.position = pos;
            this.count = thing.stackCount;
            this.stuff = thing.Stuff;
            this.style = thing.StyleDef;
            this.faction = thing.Faction?.def;
            if (thing is Plant plant)
            {
                this.growth = plant.Growth;
            }
            if (thing.def.useHitPoints)
            {
                this.hitPoint = thing.HitPoints;
            }
        }
        public Thing Spawn(Map map,IntVec3 pos,Func<ThingDef,ThingDef> getDef,ThingDef forcedStuff = null,Rot4? forcedRot = null) 
        {
            ThingDef def = getDef(this.def);
            if (def == null) 
            {
                Log.Error("Spawn thing data error:" + this.ToString());
                return null;
            }
            Thing thing = ThingMaker.MakeThing(def, def.MadeFromStuff ? forcedStuff ?? getDef(this.stuff) : null);
            thing.stackCount = this.count;
            thing.StyleDef = this.style;
            thing.Rotation = this.rotation;
            thing.stackCount = this.count;
            if (thing.def.useHitPoints)
            {
                thing.HitPoints = (int)(((float)this.hitPoint / (float)this.def.GetStatValueAbstract(StatDefOf.MaxHitPoints, this.stuff ?? GenStuff.DefaultStuffFor(this.def)) * thing.MaxHitPoints));
            }
            if (thing is Plant plant)
            {
                plant.Growth = this.growth;
            }
            if (this.faction != null && Find.FactionManager.FirstFactionOfDef(this.faction) is Faction faction)
            {
                thing.SetFaction(faction);
            }
            return GenSpawn.Spawn(thing, pos,map,forcedRot ?? this.rotation);
        }
        public XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            result.Add(new XElement("def", this.def?.defName)); 
            if (this.stuff != null)
            {
                result.Add(new XElement("stuff", this.stuff?.defName));
            }
            if (this.style != null)
            {
                result.Add(new XElement("style", this.style?.defName));
            }
            if (this.rotation != Rot4.North) 
            {
                result.Add(new XElement("rotation", this.rotation.AsInt));
            }
            if (this.count > 1)
            {
                result.Add(new XElement("count", this.count));
            }
            if (this.faction != null)
            {
                result.Add(new XElement("faction", this.faction.defName));
            }
            if (this.growth != 0f)
            {
                result.Add(new XElement("growth", this.growth));
            }
            if (this.def.useHitPoints)
            {
                result.Add(new XElement("hitPoint", this.hitPoint));
            }
            if (this.allPositions != null && this.allPositions.Any())
            {
                result.Add(EditorTools.SaveList(this.allPositions, "allPositions"));
            }
            else
            {
                XElement pos = new XElement("position", $"({this.position.x},{this.position.y},{this.position.z})");
                result.Add(pos);
            }
            return result;
        }
        public ThingData Copy() 
        {
            ThingData result = new ThingData();
            result.def = this.def;
            result.stuff = this.stuff;
            result.style = this.style;
            result.faction = this.faction;
            result.rotation = this.rotation;
            result.position = this.position;
            result.count = this.count;
            result.growth = this.growth;
            result.hitPoint = this.hitPoint;
            result.allPositions = this.allPositions.ListFullCopy();
            return result;
        }
        public void ExposeData()
        {
            Scribe_Defs.Look(ref this.def, "def");
            Scribe_Defs.Look(ref this.style, "style");
            Scribe_Defs.Look(ref this.stuff, "stuff");
            Scribe_Defs.Look(ref this.faction, "faction");
            Scribe_Values.Look(ref this.hitPoint, "QE_ThingData_hitPoint");
            Scribe_Values.Look(ref this.growth, "QE_ThingData_growth");
            Scribe_Values.Look(ref this.rotation, "QE_ThingData_rotation");
            Scribe_Values.Look(ref this.count, "QE_ThingData_count");
            Scribe_Collections.Look(ref this.allPositions, "positions",LookMode.Value);
        }

        public bool Equals_Def(ThingData data) 
        {
            return data.def == this.def && data.stuff == this.stuff && data.style == this.style && data.faction == this.faction && data.rotation == this.rotation && data.count == this.count
               && data.hitPoint == this.hitPoint && this.growth == data.growth;
        }

        public ThingDef def = null;
        public ThingDef stuff = null;
        public ThingStyleDef style = null;
        public FactionDef faction = null;
        public Rot4 rotation = Rot4.North;
        public IntVec3 position = IntVec3.Zero;
        public List<IntVec3> allPositions = new List<IntVec3>();
        public int count = 1;
        public float growth = 0f;
        public int hitPoint = 1;
    }
    public class PawnSpawnData : IExposable, ISaveable,IDrawable
    {
        public virtual void Draw(ref float y, Rect inRect, float x)
        {
            Rect rect = new Rect(16f + x, y + 10f, 500f, 45f);
            this.DrawName(ref y, x, rect);
            if (Widgets.ButtonText(new Rect(20f + x, y, 250f, 25f), "QE_PawnKind".Translate(this.kind?.label), false))
            {
                EditorTools.DrawFloatMenu<PawnKindDef>(DefDatabase<PawnKindDef>.AllDefs.ToList(), (k) => this.kind = k, (k) =>
                {
                    string result = k.label;
                    return result;
                });
            }
            y += 30f;
            if (Widgets.ButtonText(new Rect(20f + x, y, 250f, 25f), "CurFaction".Translate(this.faction), false))
            {
                EditorTools.DrawFloatMenu<FactionDef>(DefDatabase<FactionDef>.AllDefs.ToList().FindAll((f) => !f.isPlayer), (f) => this.faction = f.defName, (f) => f.label);
            }
            y += 30f;
            TooltipHandler.TipRegion(rect, "Copy".Translate());
            if (Widgets.ButtonText(new Rect(20f + x, y, 420f, 25f), "SpawnType".Translate(this.spawnType.ToString().Translate()), false))
            {
                EditorTools.DrawFloatMenu<SpawnType>(new List<SpawnType>() { SpawnType.BuildingDamaged, SpawnType.BuildingTick, SpawnType.MapGeneration, SpawnType.BuildingDestroyed }, (t) => this.spawnType = t, (t) => t.ToString().Translate());
            }
            if (this.spawnType == SpawnType.BuildingTick)
            {
                y += 30f;
                string text_Time = "TimeToSpawn".Translate();
                Widgets.Label(new Rect(20f + x, y, 150f, 25f), text_Time);
                Widgets.TextFieldNumeric<int>(new Rect(Text.CalcSize(text_Time).x + x + 25f, y, 150f, 25f), ref this.timeToSpawn, ref this.buffer_time);
            }
            y += 30f;
            string text_Spawn = "SpawnMessage".Translate();
            Widgets.Label(new Rect(20f + x, y, 150f, 25f), text_Spawn);
            this.spawnMessage = Widgets.TextField(new Rect(Text.CalcSize(text_Spawn).x + x + 25f, y, 300f, 25f), this.spawnMessage);
            y += 30f;
            EditorTools.DrawIntRange(ref y, "QE_Count".Translate(), ref this.count, ref this.buffer, ref this.bufferMax, x + 20f);
            y += 30f;
            Rect enable = new Rect(20f + x, y, 150f, 25f);
            Widgets.CheckboxLabeled(enable, "EnableLord".Translate(), ref this.enableLord);
            TooltipHandler.TipRegion(enable, new TipSignal("LordAndFactionTip".Translate()));
            y += 30f;
            if (this.enableLord)
            {
                Rect rectDuty = new Rect(20f + x, y, 250f, 25f);
                if (Widgets.ButtonText(rectDuty, "DutyType".Translate(this.duty == null ? null : this.duty.GetType() == typeof(CQFPawnDutyDef) ? this.duty.label : this.duty.defName.Translate().ToString()),false))
                {
                    List<DutyDef> defs = new List<DutyDef>() { DutyDefOf.Defend };
                    defs.AddRange(DefDatabase<CQFPawnDutyDef>.AllDefsListForReading);
                    EditorTools.DrawFloatMenu<DutyDef>(defs, (d) => this.duty = d, (d) => d.defName.Translate());
                }
                if (!(this.duty?.description.NullOrEmpty()).Value) 
                {
                    TooltipHandler.TipRegion(rectDuty,this.duty.description);
                }
                if (this.duty == QEDefOf.QE_Duty_Guard && Widgets.ButtonText(new Rect(180f + x, y, 200f, 25f), "CurRoute".Translate(this.routeName)) && EditorTools.route.Any())
                {
                    EditorTools.DrawFloatMenu<string>(EditorTools.route.Keys.ToList(), (r) => this.routeName = r, (r) => r);
                }
                y += 30f;
                if (this.duty == QEDefOf.QE_Duty_Waiter)
                {
                    EditorTools.DrawButtonAndText(ref y, "PawnRotation".Translate(this.rotation.ToStringHuman()), "SelectRotation".Translate(), () => EditorTools.DrawFloatMenu<Rot4>(new List<Rot4>() { Rot4.East, Rot4.West, Rot4.North, Rot4.South }, (r) => this.rotation = r, (r) => r.ToStringHuman()), 20f + x);
                }
            }
            EditorTools.DrawButtonAndText(ref y, "DialogTree".Translate(this.dialogManager?.defName), "Select".Translate(),
                () => EditorTools.DrawFloatMenu(DefDatabase<DialogManagerDef>.AllDefs.ToList(), (t) => this.dialogManager = t, (t) => t.defName), 20f + x);
            y += 5f;
            if (Widgets.ButtonText(new Rect(20f + x, y, 300f, 30f), "Misc".Translate(), false))
            {
                Find.WindowStack.Add(new QuestEditor_PawnDataMisc(this));
            }
            y += 35f;
            this.DrawInventory(ref y, x);
            y += 5f;
        }
        public void DrawName(ref float y, float x, Rect nameRect)
        {
            Text.Font = GameFont.Medium;
            Widgets.Label(nameRect, this.dataName.Colorize(ColorLibrary.SkyBlue));
            nameRect.width -= 300f;
            TooltipHandler.TipRegion(nameRect, "PawnDataNameTip".Translate());
            Text.Font = GameFont.Small;
            Rect rect = new Rect(370f + x, y, 30f, 30f);
            if (Widgets.ButtonImage(rect, TexButton.Copy))
            {
                EditorTools.data = this;
            }
            y += 50f;
            if (Widgets.ButtonText(new Rect(16f + x, y, 150f, 25f), "Rename".Translate()))
            {
                Find.WindowStack.Add(new Dialog_RenameForQE((name) => this.dataName = name));
            }
            y += 40f;
        }
        public void DrawInventory(ref float y, float x = 0f)
        {
            Widgets.Label(new Rect(16f + x, y, 150f, 25f), "InventoryThing".Translate());
            y += 30f;
            Widgets.DrawLine(new Vector2(16f + x, y), new Vector2(465f + x, y), ColorLibrary.SkyBlue, 2.5f);
            foreach (CQFThingDefCount thing in this.inventoryThings)
            {
                y += 5f;
                thing.Draw(ref y,new Rect(), x);
                y += 5f;
                Widgets.DrawLine(new Vector2(16f + x, y), new Vector2(465f + x, y), ColorLibrary.SkyBlue, 2.5f);
            }
            y += 20f;
            if (Widgets.ButtonText(new Rect(16f + x, y, 150f, 38f), "Add".Translate()))
            {
                Find.WindowStack.Add(new Dialog_Select<ThingDef>(DefDatabase<ThingDef>.AllDefsListForReading.FindAll((t) => t.category == ThingCategory.Item && !t.IsCorpse),t => t.uiIcon,t => t.label,"Select".Translate(),
                      (t) => this.inventoryThings.Add(new CQFThingDefCount() { thing = t })));
            }
            if (Widgets.ButtonText(new Rect(170f + x, y, 150f, 38f), "Delete".Translate()))
            {
                EditorTools.DrawFloatMenu(this.inventoryThings, (t) => this.inventoryThings.Remove(t), (t) => t.thing.label + "x" + t.count);
            }
            y += 45f;
            Widgets.Label(new Rect(16f + x, y, 150f, 25f), "InventoryThingCategorys".Translate());
            y += 30f;
            Widgets.DrawLine(new Vector2(16f + x, y), new Vector2(465f + x, y), ColorLibrary.SkyBlue, 2f);
            foreach (CQFThingCategoryCount cetegory in this.inventoryCategorys)
            {
                y += 5f;
                cetegory.Draw(ref y, new Rect(), x);
                y += 5f;
                Widgets.DrawLine(new Vector2(16f + x, y), new Vector2(465f + x, y), ColorLibrary.SkyBlue, 2f);
            }
            y += 20f;
            if (Widgets.ButtonText(new Rect(16f + x, y, 150f, 38f), "Add".Translate()))
            {
                EditorTools.DrawFloatMenu<ThingCategoryDef>(DefDatabase<ThingCategoryDef>.AllDefsListForReading.FindAll((t) => t.defName != "Corpses" && !t.Parents.Contains(ThingCategoryDefOf.Corpses) && t != ThingCategoryDefOf.Animals), (t) => this.inventoryCategorys.Add(new CQFThingCategoryCount() { category = t }),
                    (t) => t.label);
            }
            if (Widgets.ButtonText(new Rect(170f + x, y, 150f, 38f), "Delete".Translate()))
            {
                EditorTools.DrawFloatMenu(this.inventoryCategorys, (c) => this.inventoryCategorys.Remove(c), (c) => c.category.label + "x" + c.count);
            }
            y += 45f;
        }
        public virtual XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            if (this.GetType() != typeof(PawnSpawnData))
            {
                result.SetAttributeValue("Class", this.GetType().FullName);
            }
            if (this.dataName != "undefined")
            {
                result.Add(new XElement("dataName", this.dataName));
            }
            if (this.kind != null)
            {
                result.Add(new XElement("kind", this.kind.defName));
            }
            if (this.enableLord)
            {
                result.Add(new XElement("enableLord", this.enableLord));
            }
            result.Add(new XElement("count", this.count));
            if (this.spawnType == SpawnType.BuildingTick)
            {
                result.Add(new XElement("timeToSpawn", this.timeToSpawn));
            }
            if (this.faction != null)
            {
                result.Add(new XElement("faction", this.faction));
            } 
            if (this.routeName != null)
            {
                result.Add(new XElement("routeName", this.routeName));
            }
            if (this.generationChance != 1f)
            {
                result.Add(new XElement("generationChance", this.generationChance));
            }
            if (this.dialogManager != null)
            {
                result.Add(new XElement("dialogManager", this.dialogManager.defName));
            }
            if (this.enableLord)
            {
                result.Add(new XElement("duty", this.duty?.defName));
            }
            result.Add(new XElement("spawnType", this.spawnType));
            if (this.rotation != Rot4.South) 
            {
                result.Add(new XElement("rotation", this.rotation.ToStringWord()));
            }
            if (this.spawnMessage != null && this.spawnMessage != "")
            {
                result.Add(new XElement("spawnMessage", this.spawnMessage));
            }
            if (this.extraKinds != null && this.extraKinds.Any()) 
            {
                XElement extra = new XElement("extraKinds");
                this.extraKinds.ForEach(x => extra.Add(new XElement("li", x.defName)));
                result.Add(extra);
            }
            if (this.actions.Any())
            {
                XElement actions = new XElement("actions");
                this.actions.ForEach(x => actions.Add(x.SaveToXElement("li")));
                result.Add(actions);
            }
            if (this.hediffs.Any())
            {
                XElement hediffs = new XElement("hediffs");
                this.hediffs.ForEach(x => hediffs.Add(x.SaveToXElement("li")));
                result.Add(hediffs);
            }
            if (this.inventoryThings.Any())
            {
                XElement thingData = new XElement("inventoryThings");
                this.inventoryThings.ForEach((x) => thingData.Add(x.SaveToXElement("li")));
                result.Add(thingData);
            }
            if (this.inventoryCategorys.Any())
            {
                XElement categoryData = new XElement("inventoryCategorys");
                this.inventoryCategorys.ForEach((x) => categoryData.Add(x.SaveToXElement("li")));
                result.Add(categoryData);
            }
            return result;
        }
        public virtual List<Pawn> Spawn(IntVec3 position, Map map, string questTag)
        {
            if (!Rand.Chance(this.generationChance)) 
            {
                return null;
            }
            Faction faction = this.faction.NullOrEmpty() ? null : Find.FactionManager.FirstFactionOfDef(FactionDef.Named(this.faction));
            List<Pawn> result = new List<Pawn>();
            if (!position.Fogged(map) && this.spawnMessage != null && !this.spawnMessage.NullOrEmpty())
            {
                Messages.Message(this.spawnMessage.Translate(), new LookTargets(position, map), MessageTypeDefOf.NeutralEvent);
            }
            List<PawnKindDef> kinds = new List<PawnKindDef>();
            kinds.AddRange(this.extraKinds);
            kinds.Add(this.kind);
            foreach (PawnKindDef kind in kinds)
            {
                int count = this.count.RandomInRange;
                for (int i = 0; i < count; i++)
                {
                    Pawn pawn = (Pawn)GenSpawn.Spawn(PawnGenerator.GeneratePawn(kind,faction), position, map);
                    this.actions.ForEach(x => x.DoAction(pawn));
                    foreach (HediffInformation hediff in this.hediffs)
                    {
                        BodyPartRecord record = null;
                        if (hediff.part != null)
                        {
                            List<BodyPartRecord> records = pawn.RaceProps.body.GetPartsWithDef(hediff.part);
                            record = hediff.partLabel == null || hediff.partLabel == "" ? records.First() : records.Find(x => x.customLabel == hediff.partLabel);
                        }
                        pawn.health.AddHediff(hediff.hediff, record).Severity = hediff.severity;
                    }
                    if (this.dialogManager != null)
                    {
                        Current.Game.GetComponent<GameComponent_Editor>().AddDialog(pawn, this.dialogManager);
                    }
                    pawn.questTags = new List<string>()
                {
                 string.Concat(new object[]
                  {
                       questTag,
                       ".",
                       this.dataName,   
                      ".",
                     i
                   })
                 ,
                 questTag
                };
                    this.inventoryThings.ForEach(x =>
                    {
                        Thing thing = ThingMaker.MakeThing(x.thing, x.stuff);
                        thing.stackCount = x.count.RandomInRange;
                        pawn.inventory.innerContainer.TryAdd(thing);
                    });

                    this.inventoryCategorys.ForEach(x =>
                    {
                        Thing thing = ThingMaker.MakeThing(x.category.DescendantThingDefs.RandomElement(), x.stuff);
                        thing.stackCount = x.count.RandomInRange;
                        pawn.inventory.innerContainer.TryAdd(thing);
                    });
                    result.Add(pawn);
                }
            }
            return result;
        }
        public virtual List<Pawn> Spawn(IntVec3 position, Map map, Lord lord, string questTag)
        {
            if (!Rand.Chance(this.generationChance))
            {
                return null;
            }
            Faction faction = this.faction.NullOrEmpty() ? null : Find.FactionManager.FirstFactionOfDef(FactionDef.Named(this.faction));
            List<Pawn> result = new List<Pawn>();
            if (!position.Fogged(map) && this.spawnMessage != null && !this.spawnMessage.NullOrEmpty())
            {
                Messages.Message(this.spawnMessage.Translate(), new LookTargets(position, map), MessageTypeDefOf.NeutralEvent);
            }
            List<PawnKindDef> kinds = new List<PawnKindDef>();
            kinds.AddRange(this.extraKinds);
            kinds.Add(this.kind);
            foreach (PawnKindDef kind in kinds)
            {
                int count = this.count.RandomInRange;
                for (int i = 0; i < count; i++)
                {
                    Pawn pawn = (Pawn)GenSpawn.Spawn(PawnGenerator.GeneratePawn(kind, faction), position, map);
                    this.actions.ForEach(x => x.DoAction(pawn));
                    foreach (HediffInformation hediff in this.hediffs)
                    {
                        BodyPartRecord record = null;
                        if (hediff.part != null)
                        {
                            List<BodyPartRecord> records = pawn.RaceProps.body.GetPartsWithDef(hediff.part);
                            record = hediff.partLabel == null || hediff.partLabel == "" ? records.First() : records.Find(x => x.untranslatedCustomLabel == hediff.partLabel);
                        }
                        if (record != null && pawn.health.hediffSet.PartIsMissing(record))
                        {
                            pawn.health.RestorePart(record);
                        }
                        pawn.health.AddHediff(hediff.hediff, record).Severity = hediff.severity;
                    }
                    if (this.dialogManager != null)
                    {
                        Current.Game.GetComponent<GameComponent_Editor>().AddDialog(pawn, this.dialogManager);
                    }
                    pawn.questTags = new List<string>()
                {
                 string.Concat(new object[]
                  {
                       questTag,
                       ".",
                       this.dataName,  
                      ".",
                     i
                   })
                 ,
                 questTag
                };
                    if (lord != null)
                    {
                        lord.AddPawn(pawn);
                        PawnDuty duty = new PawnDuty(this.duty);
                        duty.overrideFacing = this.rotation;
                        duty.focus = new LocalTargetInfo(position);
                        pawn.mindState.duty = duty;
                        ((LordJob_Custom)lord.LordJob).pawnDutyDatas.Add(pawn, this.duty);
                    }
                    this.inventoryThings.ForEach(x =>
                    {
                        Thing thing = ThingMaker.MakeThing(x.thing, x.stuff);
                        thing.stackCount = x.count.RandomInRange;
                        pawn.inventory.innerContainer.TryAdd(thing);
                    });

                    this.inventoryCategorys.ForEach(x =>
                    {
                        Thing thing = ThingMaker.MakeThing(x.category.DescendantThingDefs.RandomElement(), x.stuff);
                        thing.stackCount = x.count.RandomInRange;
                        pawn.inventory.innerContainer.TryAdd(thing);
                    });
                    result.Add(pawn);
                }
            }
            return result;
        }
        public virtual void ExposeData()
        {
            Scribe_Values.Look(ref this.dataName, "QE_PawnData_dataName");
            Scribe_Values.Look(ref this.buffer, "QE_PawnData_buffer"); 
            Scribe_Values.Look(ref this.bufferMax, "QE_PawnData_bufferMax");
            Scribe_Values.Look(ref this.buffer_time, "QE_PawnData_buffer_time");
            Scribe_Values.Look(ref this.enableLord, "QE_PawnData_isOneOfLord");
            Scribe_Values.Look(ref this.count, "QE_PawnData_count");
            Scribe_Values.Look(ref this.timeToSpawn, "QE_PawnData_timeToSpawn");
            Scribe_Values.Look(ref this.faction, "QE_PawnData_faction");
            Scribe_Values.Look(ref this.routeName, "QE_PawnData_routeName");
            Scribe_Values.Look(ref this.spawnType, "QE_PawnData_spawnType");
            Scribe_Values.Look(ref this.spawnMessage, "QE_PawnData_spawnMessage");
            Scribe_Values.Look(ref this.rotation, "QE_PawnData_rotation");
            Scribe_Values.Look(ref this.buffer_chance, "buffer_chance");
            Scribe_Values.Look(ref this.generationChance, "QE_PawnData_generationChance");
            Scribe_Defs.Look(ref this.duty, "QE_PawnData_duty");
            Scribe_Defs.Look(ref this.dialogManager, "QE_PawnData_dialogManager");
            Scribe_Defs.Look(ref this.kind, "QE_PawnData_kind");
            Scribe_Collections.Look(ref this.extraKinds, "QE_PawnSpawnData_extraKind", LookMode.Def);
            Scribe_Collections.Look(ref this.inventoryThings, "QE_PawnSpawnData_inventoryThings", LookMode.Deep);
            Scribe_Collections.Look(ref this.inventoryCategorys, "QE_PawnSpawnData_inventoryCategorys", LookMode.Deep);
            Scribe_Collections.Look(ref this.hediffs, "QE_PawnSpawnData_hediffs", LookMode.Deep);
            Scribe_Collections.Look(ref this.actions, "QE_PawnSpawnData_actions", LookMode.Deep);
        }

        public string dataName = "undefined";
        public string buffer;
        public string bufferMax;
        public string buffer_time;
        public string buffer_chance;
        public float generationChance = 1f;
        public IntRange count = new IntRange(1,2);
        public int timeToSpawn = 0;
        public bool enableLord = false;
        public string spawnMessage = null;
        public string faction = null;
        public string routeName = null;
        public Rot4 rotation = Rot4.South;
        public SpawnType spawnType = SpawnType.MapGeneration;
        public DutyDef duty = DutyDefOf.Defend;
        public PawnKindDef kind = null;
        public List<PawnKindDef> extraKinds = new List<PawnKindDef>();
        public DialogManagerDef dialogManager = null;
        public List<HediffInformation> hediffs = new List<HediffInformation>();
        public List<SpawnAfterAction> actions = new List<SpawnAfterAction>();
        public List<CQFThingDefCount> inventoryThings = new List<CQFThingDefCount>();
        public List<CQFThingCategoryCount> inventoryCategorys = new List<CQFThingCategoryCount>();
    }
    public class PawnSpawnData_Random : PawnSpawnData
    {
        public override void Draw(ref float y, Rect inRect, float x)
        {
            Rect rect = new Rect(16f + x, y + 10f, 500f, 45f);
            this.DrawName(ref y, x, rect);
            if (Widgets.ButtonText(new Rect(16f + x, y, 420f, 25f), "SpawnType".Translate(this.spawnType.ToString().Translate()), false))
            {
                EditorTools.DrawFloatMenu<SpawnType>(new List<SpawnType>() { SpawnType.BuildingDamaged, SpawnType.BuildingTick, SpawnType.MapGeneration, SpawnType.BuildingDestroyed }, (t) => this.spawnType = t, (t) => t.ToString().Translate());
            }
            if (this.spawnType == SpawnType.BuildingTick)
            {
                y += 30f;
                string text_Time = "TimeToSpawn".Translate();
                Widgets.Label(new Rect(16f + x, y, 150f, 25f), text_Time);
                Widgets.TextFieldNumeric<int>(new Rect(Text.CalcSize(text_Time).x + x + 25f, y, 150f, 25f), ref this.timeToSpawn, ref this.buffer_time);
            }
            y += 30f;
            EditorTools.DrawIDrawList_UseWindow(ref y, 16f + x,this.datas,inRect, "PawnSpawnDatas".Translate(),d => d.dataName);
        }

        public override List<Pawn> Spawn(IntVec3 position, Map map, Lord lord, string questTag)
        {
            if (!this.datas.Any()) 
            {
                Log.Error("Custom Quset Framework Error:Pawn data list of PawnSpawnData_Random is empty");
                return null;
            }
            return this.datas.RandomElement().Spawn(position, map, lord, questTag);
        }

        public override List<Pawn> Spawn(IntVec3 position, Map map, string questTag)
        {
            if (!this.datas.Any())
            {
                Log.Error("Custom Quset Framework Error:Pawn data list of PawnSpawnData_Random is empty");
                return null;
            }
            return this.datas.RandomElement().Spawn(position, map, questTag);
        }
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(EditorTools.SaveList_Saveable<PawnSpawnData>(this.datas, "datas"));
            return result;
        }
        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref this.datas, "PawnSpawnData_Random_datas",LookMode.Deep);
        }

        public List<PawnSpawnData> datas = new List<PawnSpawnData>();
    }
    public class SpawnAfterAction : ISaveable, IExposable, IDrawable
    {
        public virtual void DoAction(Pawn pawn)
        {

        }

        public void Draw(ref float y, Rect inRect, float x)
        {
            Rect rect = new Rect(x, y, 150f, 25f);
            Widgets.Label(rect, this.GetType().Name.Translate().Colorize(ColorLibrary.SkyBlue));
            if ((this.GetType().Name + "_Tip").CanTranslate())
            {
                TooltipHandler.TipRegion(rect, (this.GetType().Name + "_Tip").Translate());
            }
            y += 30f;
        }

        public virtual void ExposeData()
        {

        }

        public virtual XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            result.SetAttributeValue("Class", this.GetType().FullName);
            return result;
        }
    }
    public class HediffInformation : ISaveable, IExposable
    {
        public HediffInformation() { }
        public HediffInformation(HediffDef hediff, BodyPartDef part, float severity, string partLabel)
        {
            this.partLabel = partLabel;
            this.part = part;
            this.hediff = hediff;
            this.severity = severity;
            this.buffer = "";
        }
        public XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            result.Add(new XElement("partLabel", this.partLabel));
            result.Add(new XElement("hediff", this.hediff.defName));
            result.Add(new XElement("part", this.part?.defName));
            result.Add(new XElement("severity", this.severity));
            result.Add(new XElement("partLabelForSeeing", this.partLabelForSeeing));
            return result;
        }

        public void ExposeData()
        {
            Scribe_Values.Look(ref this.partLabelForSeeing, "HediffInformation_partLabelForSeeing");
            Scribe_Values.Look(ref this.severity, "HediffInformation_severity");
            Scribe_Values.Look(ref this.partLabel, "HediffInformation_partLabel");
            Scribe_Defs.Look(ref this.part, "HediffInformation_part");
            Scribe_Defs.Look(ref this.hediff, "HediffInformation_hediff");
        }

        public string buffer;
        public float severity;
        public string partLabelForSeeing;
        public string partLabel;
        public BodyPartDef part;
        public HediffDef hediff;
    }
    public class RuleData
    {
        public RulePack GetRulePack()
        {
            RulePack result = new RulePack();
            if (this.rulesFiles != null)
            {
                typeof(RulePack).GetField("rulesFiles", BindingFlags.NonPublic | BindingFlags.Instance).SetValue(result, this.rulesFiles);
            }
            typeof(RulePack).GetField("rulesStrings", BindingFlags.NonPublic | BindingFlags.Instance).SetValue(result, this.stringRules);
            return result;
        }
        public RulePackDef GetRulePackDef()
        {
            RulePackDef result = new RulePackDef();
            result.defName = this.ruleName;
            RulePack pack = new RulePack();
            if (this.rulesFiles != null)
            {
                typeof(RulePack).GetField("rulesFiles", BindingFlags.NonPublic | BindingFlags.Instance).SetValue(pack, this.rulesFiles);
            }
            typeof(RulePack).GetField("rulesStrings", BindingFlags.NonPublic | BindingFlags.Instance).SetValue(pack, this.stringRules);
            typeof(RulePackDef).GetField("rulePack", BindingFlags.NonPublic | BindingFlags.Instance).SetValue(result, pack);
            return result;
        }
        public XElement GetXmlNode(string nodeName)
        {
            XElement result = new XElement(nodeName);
            XElement ruleStrings = new XElement("rulesStrings");
            foreach (string rule in this.stringRules)
            {
                XElement li = new XElement("li", @rule);
                ruleStrings.Add(li);
            }
            result.Add(ruleStrings);
            return result;
        }

        public string ruleName = "";
        public List<string> rulesFiles;
        public List<string> stringRules = new List<string>() { "" };
    }
    public abstract class CQFAction : ISaveable, IDrawable, IExposable
    {
        public virtual CQFAction Copy()
        {
            XElement x = this.SaveToXElement("CQFAction");
            XmlNode node = new XmlDocument().ReadNode(x.CreateReader()) as XmlNode;
            CQFAction result = DirectXmlToObject.ObjectFromXml<CQFAction>(node, false);
            DirectXmlCrossRefLoader.ResolveAllWantedCrossReferences(FailMode.LogErrors);
            return result;
        }
        public virtual void Draw(ref float y, Rect inRect, float x)
        {
            Rect rect = new Rect(x, y, 250f, 25f);
            Widgets.Label(rect, this.GetType().Name.Translate().Colorize(ColorLibrary.SkyBlue));
            if ((this.GetType().Name + "_Tip").CanTranslate())
            {
                TooltipHandler.TipRegion(rect, (this.GetType().Name + "_Tip").Translate());
            }
            y += 30f;
        }
        public virtual XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            result.SetAttributeValue("Class", this.GetType().FullName);
            return result;
        }
        public abstract void ExposeData();
        public abstract void Work(Dictionary<string, TargetInfo> targets);

    }
    public class CQFAction_Sequence : CQFAction
    {
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
            EditorTools.DrawIDrawList_UseWindow(ref y,x,this.actions,inRect,"TriggerActions".Translate(),a => a.GetType().Name.Translate());
            y += 30f;
        }
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(EditorTools.SaveList_Saveable(this.actions, "actions"));
            return result;
        }
        public override void Work(Dictionary<string, TargetInfo> targets)
        {
            this.actions.ForEach(a => a.Work(targets));
        }
        
        public override void ExposeData()
        {
            Scribe_Collections.Look(ref this.actions, "actions",LookMode.Deep);
        }

        public List<CQFAction> actions = new List<CQFAction>();
    }
    public class CQFAction_Random : CQFAction
    {
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
            EditorTools.DrawIDrawList_UseWindow(ref y, x, this.actions, inRect, "TriggerActions".Translate(), a => a.GetType().Name.Translate());
            y += 30f;
        }
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(EditorTools.SaveList_Saveable(this.actions, "actions"));
            return result;
        }
        public override void Work(Dictionary<string, TargetInfo> targets)
        {
            this.actions.RandomElement().Work(targets);
        }

        public override void ExposeData()
        {
            Scribe_Collections.Look(ref this.actions, "actions", LookMode.Deep);
        }

        public List<CQFAction> actions = new List<CQFAction>();
    }
    public class CQFAction_Chance : CQFAction
    {
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
            if (this.action != null) 
            {
                Widgets.DrawLine(new Vector2(x,y),new Vector2(inRect.width,y),ColorLibrary.SkyBlue,1f);
                this.action.Draw(ref y,inRect,x);
                Widgets.DrawLine(new Vector2(x, y), new Vector2(inRect.width, y), ColorLibrary.SkyBlue, 1f);
                y += 5f;
            }
            if (Widgets.ButtonText(new Rect(x,y,150f,25f),"SelectAction".Translate(),false)) 
            {
                EditorTools.DrawFloatMenu(typeof(CQFAction).AllSubclassesNonAbstract(),a => this.action = (CQFAction)Activator.CreateInstance(a),a => a.Name.Translate());
            }
            y += 30f;
            EditorTools.DrawLabelAndText_Line(y, "LootChance".Translate(),ref this.chance,ref this.buffer,x,150f);
            y += 30f;
        }
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(this.action.SaveToXElement("action"));
            result.Add(new XElement("chance",this.chance));
            return result;
        }
        public override void Work(Dictionary<string, TargetInfo> targets)
        {
            if (Rand.Chance(this.chance)) 
            {
                this.action.Work(targets);
            }
        }

        public override void ExposeData()
        {
            Scribe_Values.Look(ref this.buffer, "buffer");
            Scribe_Values.Look(ref this.chance,"chance");
            Scribe_Deep.Look(ref this.action,"action");
        }

        public string buffer;
        public float chance;
        public CQFAction action;
    }
    public class CQFAction_SentSignal : CQFAction
    {
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
            EditorTools.DrawLabelAndText_Line(y, "OutSignal".Translate(), ref this.signal, x, 350f);
            y += 30f; 
            Rect rect = new Rect(x, y, 250f, 25f);
            Widgets.CheckboxLabeled(rect, "SignalOnlyIsValidInPart".Translate(), ref this.signalIsOnlyValidInPart);
            TooltipHandler.TipRegion(rect, "SignalOnlyIsValidInPartTip".Translate());
            y += 30f;
        }
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("signal", this.signal));
            result.Add(new XElement("signalIsOnlyValidInPart", this.signalIsOnlyValidInPart));
            return result;
        }
        public override void Work(Dictionary<string, TargetInfo> targets)
        {
            Find.SignalManager.SendSignal(new Signal(this.signal));
        }
        public override void ExposeData()
        {
            Scribe_Values.Look(ref this.signal, "CQFAction_SentSignal_signal");
            Scribe_Values.Look(ref this.signalIsOnlyValidInPart, "CQFAction_SentSignal_signalIsOnlyValidInPart");
        }

        public string signal;
        public bool signalIsOnlyValidInPart = false;
    }
    public class CQFAction_Message : CQFAction
    {
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
            EditorTools.DrawLabelAndText_Line(y, "CQFMessage".Translate(), ref this.message, x, 240f);
            y += 30f;
            if (Widgets.ButtonText(new Rect(x,y,450f,25f),"CQFMessageType".Translate(this.type?.defName.Translate().ToString()),false)) 
            {
                EditorTools.DrawFloatMenu(DefDatabase<MessageTypeDef>.AllDefsListForReading, (d) => this.type = d, (d) => d.defName.Translate());
            }
            y += 30f;
        }
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("message", this.message));
            result.Add(new XElement("type", this.type?.defName));
            return result;
        }
        public override void Work(Dictionary<string, TargetInfo> targets)
        {
            if (targets.TryGetValue("Trigger",out TargetInfo t1) && t1.Thing is Thing thing && thing.Faction != Faction.OfPlayer) 
            {
                return;
            }
            string message = this.message.Translate();
            targets.ToList().ForEach(t =>
            {
                string replaceText ="";
                if (t.Value.HasThing) 
                {
                    replaceText = t.Value.Thing.Label;  
                    if (t.Value.Thing is Pawn pawn) 
                    {
                        replaceText = pawn.Name.ToString();
                    }
                }
                string replacedText = "{" + $"{t.Key}" + "}";
                message = message.Replace(replacedText, replaceText);
            });
            Messages.Message(message,new LookTargets(targets.Values),this.type);
        }

        public override void ExposeData()
        {
            Scribe_Values.Look(ref this.message, "CQFAction_Message_message");
            Scribe_Defs.Look(ref this.type, "CQFAction_Message_type");
        }

        public string message;
        public MessageTypeDef type = MessageTypeDefOf.PositiveEvent;
    }
    public class CQFAction_StartDialog : CQFAction
    {
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
            if (Widgets.ButtonText(new Rect(x,y,320f,25f), "DialogManagerForSpawner".Translate(this.dialog?.defName),false)) 
            {
                EditorTools.DrawFloatMenu(DefDatabase<DialogManagerDef>.AllDefsListForReading,m => this.dialog = m,m => m.defName);
            }
            y += 30f;
            EditorTools.DrawSelectableText(y, "Interviewer".Translate(), ref this.interviewerText, () => EditorTools.DrawFloatMenu(EditorTools.TargetTexts, t => this.interviewerText = t, t => t.Translate()), x, 150f);
            y += 30f;
            EditorTools.DrawSelectableText(y, "Interviewee".Translate(), ref this.intervieeText, () => EditorTools.DrawFloatMenu(EditorTools.TargetTexts, t => this.intervieeText = t, t => t.Translate()),x,150f);
            y += 30f;
        }
        public override void Work(Dictionary<string, TargetInfo> targets)
        {
            Thing interviewer = null; 
            Thing interviee = null;
            targets.ToList().ForEach(t => 
            {
                if (t.Key == this.interviewerText) 
                {
                    interviewer = t.Value.Thing;
                }
                if (t.Key == this.intervieeText)
                {
                    interviee = t.Value.Thing;
                }
            });
            Find.WindowStack.Add(this.dialog.GetTree(interviewer, interviee)?.CreateDialog(interviewer, interviee));
        }    
        public override void ExposeData()
        {
            Scribe_Defs.Look(ref this.dialog,"dialog");
            Scribe_Values.Look(ref this.interviewerText, "interviewerText");
            Scribe_Values.Look(ref this.intervieeText, "intervieeText");
        }

        public DialogManagerDef dialog;
        [NoTranslate]
        public string interviewerText;
        [NoTranslate]
        public string intervieeText;
    }
    public abstract class CQFAction_Target : CQFAction
    {
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
            EditorTools.DrawSelectableStringList(this.targetsText,ref y,(rect,text,index) => 
            {
                string text2 = text;
                EditorTools.DrawSelectableText(rect.y + 4.5f, "DialogueTarget".Translate(), ref text2, () => EditorTools.DrawFloatMenu(EditorTools.TargetTexts,
                    t =>
                    {
                        text2 = t;
                        this.targetsText[index] = t;
                    }, t => t.Translate()), x + 5f, 150f);
                this.targetsText[index] = text2;
            },null, "CQFTargetTextTip".Translate(),true,x,320f);
            y += 20f;
        }
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(EditorTools.SaveList(this.targetsText, "targetsText"));
            return result;
        }
        public abstract void RealWork(Dictionary<string, TargetInfo> targets);
        public override void Work(Dictionary<string, TargetInfo> targets)
        {
            Dictionary<string, TargetInfo> eligibleTargets = new Dictionary<string, TargetInfo>();
            targets.ToList().ForEach(t =>
            {
                if (this.targetsText.Contains(t.Key)) 
                {
                    eligibleTargets.Add(t.Key,t.Value);
                }
            });
            this.RealWork(eligibleTargets);
        }

        public override void ExposeData()
        {
            Scribe_Collections.Look(ref this.targetsText, "CQFAction_Target_targetsText",LookMode.Value);
        }

        [NoTranslate]
        public List<string> targetsText = new List<string>() {"null"};
    }
    public class CQFAction_Spawn : CQFAction_Target
    {
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
            Rect rectData = new Rect(10f, y, 600f, 25f);
            float initY = y;
            y += 5f;
            foreach (LootData data in this.datas)
            {
                if (Widgets.ButtonText(rectData, data.dataName, false))
                {
                    Find.WindowStack.Add(new Dialog_EditIDrawable((IDrawable)data));
                }
                y += 30f;
                rectData.y += 30f;
            }
            y -= 5f;
            Widgets.DrawBox(new Rect(x, initY, inRect.width - 40f - (2 * x), y - initY), 1, QuestEditor_Dialog.blueTex);
            y += 7f;
            if (Widgets.ButtonText(new Rect(10f, y, 150f, 25f), "AddNewLootData".Translate()))
            {
                this.datas.Add(new LootData());
            }
            if (Widgets.ButtonText(new Rect(174f, y, 150f, 25f), "DeleteLootData".Translate()) && this.datas.Any())
            {
                EditorTools.DrawFloatMenu(this.datas, (d) => this.datas.Remove(d), (d) => d.dataName);
            }
            y += 30f;
        }

        public override void RealWork(Dictionary<string, TargetInfo> targets)
        {
            targets.ToList().ForEach(t =>
            {
                this.datas.ForEach(d =>
                {
                    if (t.Value.CenterCell.IsValid && t.Value.Map != null)
                    {
                        d.SpawnLoots(t.Value.Map, t.Value.CenterCell, t.Value.Thing is Pawn targetPawn ? targetPawn.GetLord() : null, t.Value.Thing);
                    }
                });
            });
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref this.datas, "CQFAction_Spawn_datas", LookMode.Deep);
        }
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            XElement datas = new XElement("datas");
            this.datas.ForEach(d => datas.Add(d.SaveToXElement("li")));
            result.Add(datas);
            return result;
        }

        public List<LootData> datas = new List<LootData>();
    }
    public class CQFAction_RemoveDialogManager : CQFAction_Target
    {
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
        }

        public override void RealWork(Dictionary<string, TargetInfo> targets)
        {
            targets.ToList().ForEach(t =>
            {
                if (t.Value.HasThing)
                {
                    Current.Game.GetComponent<GameComponent_Editor>().RemoveDialog(t.Value.Thing);
                }
            });
        }

        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            return result;
        }
    }
    public class CQFAction_Replace : CQFAction_Target
    {
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
            if (Widgets.ButtonText(new Rect(x,y,250f,25f), "CQFReplaceThing".Translate(this.data.stuff?.label + " " + this.data.def?.label),false)) 
            {
                this.data.OpenSelectDialog();
            }
            y += 30f;
            Widgets.CheckboxLabeled(new Rect(x,y,150f,25f), "UseSameStuff".Translate(),ref this.useSameStuff);
            y += 30f;
        }

        public override void RealWork(Dictionary<string, TargetInfo> targets)
        {
            targets.ToList().ForEach(t =>
            {
                if (t.Value.CenterCell.IsValid && t.Value.Map != null)
                {
                    Thing thing = this.data.Spawn(t.Value.Map,t.Value.Thing?.Position ?? t.Value.CenterCell, d => d,this.useSameStuff ? t.Value.Thing?.Stuff : null,t.Value.Thing?.Rotation);
                    if (t.Value.Thing != null && !t.Value.Thing.Destroyed) 
                    {
                        t.Value.Thing.Destroy();
                    }
                }
            });
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref this.useSameStuff, "useSameStuff");
            Scribe_Deep.Look(ref this.data,"data");
        }
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(data.SaveToXElement("data"));
            if (this.useSameStuff) 
            {
                result.Add(new XElement("useSameStuff", this.useSameStuff));
            }
            return result;
        }

        public ThingData data = new ThingData();
        public bool useSameStuff = false; 
    }
    public class CQFAction_OpenLootBox : CQFAction_Target
    {
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            return result;
        }
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
        }
        public override void RealWork(Dictionary<string, TargetInfo> targets)
        {
            this.targetsText.ForEach(t =>
            {
                if (targets.TryGetValue(t,out TargetInfo target) && target.Thing is LootBox box && !box.opened)
                {
                    box.Open();
                }
            });
        }
    }
    public class CQFAction_Faction : CQFAction_Target
    {
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("faction", this.faction.defName));
            return result;
        }
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
            Rect rect = new Rect(x, y, 150f, 25f);
            Widgets.Label(rect, "Faction".Translate() + ":" + this.faction?.label);
            rect.x = 160f;
            if (Widgets.ButtonText(rect, "Select".Translate()))
            {
                EditorTools.DrawFloatMenu(DefDatabase<FactionDef>.AllDefsListForReading, f => this.faction = f, f => f.label);
            }
            y += 30f;
        }
        public override void RealWork(Dictionary<string, TargetInfo> targets)
        {
            targets.ToList().ForEach(t =>
                {
                    if (t.Value.Thing is Thing thing && thing.def.CanHaveFaction)
                    {
                        if (this.faction.isPlayer)
                        {
                            thing.SetFaction(Faction.OfPlayer);
                            return;
                        }
                        thing.SetFaction(Find.FactionManager.FirstFactionOfDef(this.faction));
                    }
                });
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref this.faction, "CQFAction_Faction_faction");
        }

        public FactionDef faction;
    }
    public class CQFAction_SetDuty : CQFAction_Target
    {
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("duty", this.duty.defName));
            return result;
        }
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
            Rect rect = new Rect(x, y, 150f, 25f);
            if (Widgets.ButtonText(rect, "DutyType".Translate(this.duty is CQFPawnDutyDef ? this.duty?.label : this.duty?.defName.Translate().ToString())))
            {
                List<DutyDef> defs = new List<DutyDef>() { DutyDefOf.Defend };
                defs.AddRange(DefDatabase<CQFPawnDutyDef>.AllDefsListForReading);
                EditorTools.DrawFloatMenu<DutyDef>(defs, (d) => this.duty = d, (d) => d.defName.Translate());
            }
            y += 30f;
        }
        public override void RealWork(Dictionary<string, TargetInfo> targets)
        {
            targets.ToList().ForEach(t =>
            {
                if (t.Value.Thing is Pawn pawn)
                {
                    pawn.mindState.duty = new PawnDuty(this.duty);
                    if (pawn.GetLord()?.LordJob is LordJob_Custom custom) 
                    {
                        custom.pawnDutyDatas.SetOrAdd(pawn,this.duty);
                    }
                }
            });
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref this.duty, "CQFAction_Duty_duty");
        }

        public DutyDef duty;
    }
    public class CQFAction_Hediff : CQFAction_Target
    {
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("hediff", this.hediff.defName));
            result.Add(new XElement("severity", this.severity));
            return result;
        }
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);

            Rect rect = new Rect(x, y, 150f, 25f);
            rect = new Rect(x, y, 150f, 25f);
            Widgets.Label(rect, "GivenHediff".Translate() + this.hediff?.label);
            rect.x = 160f;
            if (Widgets.ButtonText(rect, "Select".Translate()))
            {
                EditorTools.DrawFloatMenu(DefDatabase<HediffDef>.AllDefsListForReading, h => this.hediff = h, h => h.label);
            }
            y += 30f;
            EditorTools.DrawLabelAndText_Line<float>(y, "SeverityOfHediff".Translate(), ref this.severity, ref this.buffer, x);
            y += 30f;
        }
        public override void RealWork(Dictionary<string, TargetInfo> targets)
        {
            targets.ToList().ForEach(t =>
            {
                if (t.Value.Thing is Pawn pawn)
                {
                    HealthUtility.AdjustSeverity(pawn, this.hediff, this.severity);
                }
            });
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref this.severity, "CQFAction_Hediff_severity");
            Scribe_Defs.Look(ref this.hediff, "CQFAction_Hediff_hediff");
        }


        public string buffer;
        public HediffDef hediff;
        public float severity;
    }
    public class CQFAction_Trait : CQFAction_Target
    {
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("trait", this.trait.defName));
            result.Add(new XElement("degree", this.degree));
            return result;
        }
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);

            Rect rect = new Rect(x, y, 150f, 25f);
            List<KeyValuePair<TraitDef, TraitDegreeData>> stagets = new List<KeyValuePair<TraitDef, TraitDegreeData>>();
            DefDatabase<TraitDef>.AllDefsListForReading.ForEach(t =>
            {
                t.degreeDatas.ForEach(s =>
                {
                    stagets.Add(new KeyValuePair<TraitDef, TraitDegreeData>(t, s));
                });
            });
            if (Widgets.ButtonText(rect, "RequiredTrait".Translate(this.trait?.degreeDatas.Count > this.degree ? this.trait?.degreeDatas[this.degree].label : ""), false))
            {
                Find.WindowStack.Add(new Dialog_Select<KeyValuePair<TraitDef, TraitDegreeData>>(stagets, null, t => t.Value.label, "Select".Translate(), t =>
                {
                    this.trait = t.Key;
                    this.degree = t.Key.degreeDatas.IndexOf(t.Value);
                }));
            }
            y += 30f;
        }
        public override void RealWork(Dictionary<string, TargetInfo> targets)
        {
            targets.ToList().ForEach(t =>
            {
                this.DoAction(t.Value.Thing);
            });
        }
        public void DoAction(Thing targetPawn)
        {
            if (targetPawn is Pawn pawn && pawn.story?.traits is TraitSet set)
            {
                if (!set.HasTrait(this.trait))
                {
                    set.allTraits.Add(new Trait(this.trait, this.degree));
                }
                else
                {
                    set.RemoveTrait(set.GetTrait(this.trait));
                    set.allTraits.Add(new Trait(this.trait, this.degree));
                }
            }
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref this.degree, "CQFAction_Trait_degree");
            Scribe_Defs.Look(ref this.trait, "CQFAction_Trait_trait");
        }

        public string buffer;
        public TraitDef trait;
        public int degree;
    }
    public class CQFAction_Explosion : CQFAction_Target
    {
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("damage", this.damage.defName));
            result.Add(new XElement("amount", this.amount));
            return result;
        }
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);

            Rect rect = new Rect(x, y, 350f, 25f);
            if (Widgets.ButtonText(rect, "ExplostionDamageType".Translate() + this.damage?.label,false))
            {
                EditorTools.DrawFloatMenu(DefDatabase<DamageDef>.AllDefsListForReading, d => this.damage = d, d => d.label);
            }
            y += 30f;
            EditorTools.DrawLabelAndText_Line<int>(y, "DamageAmount".Translate(), ref this.amount, ref this.buffer, x);
            y += 30f;
            EditorTools.DrawLabelAndText_Line<float>(y, "ExplosionRadius".Translate(), ref this.radius, ref this.bufferR, x);
            y += 30f;
        }
        public override void RealWork(Dictionary<string, TargetInfo> targets)
        {
            targets.ToList().ForEach(t =>
            {
                this.DoAction(t.Value.CenterCell, t.Value.Map);
            });
        }

        public void DoAction(IntVec3 pos, Map map)
        {
            GenExplosion.DoExplosion(pos, map, this.radius, this.damage, null, this.amount);
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref this.radius, "CQFAction_Explosion_radius");
            Scribe_Values.Look(ref this.amount, "CQFAction_Explosion_amount");
            Scribe_Defs.Look(ref this.damage, "CQFAction_Explosion_damage");
        }

        public string bufferR;
        public string buffer;
        public DamageDef damage;
        public int amount;
        public float radius;
    }
    public class CQFAction_TakeDamage : CQFAction_Target
    {
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("damage", this.damage.defName));
            result.Add(new XElement("amount", this.amount));
            return result;
        }
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);

            Rect rect = new Rect(x, y, 350f, 25f);
            if (Widgets.ButtonText(rect, "DamageType".Translate() + this.damage?.label,false))
            {
                EditorTools.DrawFloatMenu(DefDatabase<DamageDef>.AllDefsListForReading, d => this.damage = d, d => d.label);
            }
            y += 30f;
            EditorTools.DrawLabelAndText_Line<float>(y, "DamageAmount".Translate(), ref this.amount, ref this.buffer, x);
            y += 30f;
        }
        public override void RealWork(Dictionary<string, TargetInfo> targets)
        {
            targets.ToList().ForEach(t =>
            {
                this.DoAction(t.Value.Thing);
            });
        }

        public void DoAction(Thing targetPawn)
        {
            targetPawn.TakeDamage(new DamageInfo(this.damage, this.amount));
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref this.amount, "CQFAction_TakeDamage_severity");
            Scribe_Defs.Look(ref this.damage, "CQFAction_TakeDamage_damage");
        }


        public string buffer;
        public DamageDef damage;
        public float amount;
    }
    public class CQFAction_GainMood : CQFAction_Target
    {
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("thought", this.thought.defName));
            result.Add(new XElement("stage", this.stage));
            return result;
        }
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);

            Rect rect = new Rect(x, y, 350f, 25f);
            List<KeyValuePair<ThoughtDef, ThoughtStage>> stagets = new List<KeyValuePair<ThoughtDef, ThoughtStage>>();
            DefDatabase<ThoughtDef>.AllDefsListForReading.ForEach(t => 
            {
                t.stages.ForEach(s => 
                {
                    stagets.Add(new KeyValuePair<ThoughtDef, ThoughtStage>(t,s));
                });
            });
            if (Widgets.ButtonText(rect, "CQF_ThoughtDef".Translate(this.thought?.stages.Count > this.stage  ? this.thought?.stages[this.stage].label : ""), false))
            {
                Find.WindowStack.Add(new Dialog_Select<KeyValuePair<ThoughtDef, ThoughtStage>>(stagets, null,t => t.Value?.label,"Select".Translate(),t => 
                {
                    this.thought = t.Key;
                    if (t.Key.stages.Contains(t.Value))
                    {
                        this.stage = t.Key.stages.IndexOf(t.Value);
                    }
                    else
                    {
                        Log.Message("CQF Action Gain Mood Error:A thoughtstage without thought");
                    }
                }));
            }
            y += 30f;
        }
        public override void RealWork(Dictionary<string, TargetInfo> targets)
        {
            targets.ToList().ForEach(t =>
            {
                if (t.Value.Thing is Pawn pawn)
                {
                    this.DoAction(pawn);
                }
            });
        }

        public void DoAction(Pawn targetPawn)
        {
            targetPawn.needs.mood.thoughts.memories.TryGainMemory(ThoughtMaker.MakeThought(this.thought,this.stage));
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Defs.Look(ref this.thought, "thought");
            Scribe_Values.Look(ref this.stage, "stage");
            Scribe_Values.Look(ref this.buffer, "buffer");
        }

        public ThoughtDef thought;
        public int stage;
        public string buffer;
    }
    public class CQFAction_GainExperience : CQFAction_Target
    {
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            if (this.skill != null)
            {
                result.Add(new XElement("skill", this.skill.defName));
            }
            result.Add(new XElement("experienceRange", this.experienceRange.ToString()));
            return result;
        }
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
            Rect rect = new Rect(x, y, 350f, 25f);
            if (Widgets.ButtonText(rect, "SkillType".Translate(this.skill == null ? "Random".Translate().ToString() : this.skill?.label), false))
            {
                EditorTools.DrawFloatMenu(DefDatabase<SkillDef>.AllDefsListForReading, d => this.skill = d, d => d.label, new List<FloatMenuOption>() { new FloatMenuOption("Random".Translate().ToString(), () => this.skill = null) });
            }
            y += 30f;
            EditorTools.DrawFloatRange(ref y, "GainExperienceRange".Translate(), ref this.experienceRange, ref this.buffer, ref this.maxBuffer, x, 100f);
            y += 30f;
        }
        public override void RealWork(Dictionary<string, TargetInfo> targets)
        {
            targets.ToList().ForEach(t =>
            {
                this.DoAction(t.Value.Thing);
            });
        }

        public void DoAction(Thing targetPawn)
        {
            if (targetPawn is Pawn pawn)
            {
                float experience = this.experienceRange.RandomInRange;
                SkillDef skill = this.skill == null ? pawn.skills.skills.RandomElement().def : this.skill;
                pawn.skills.Learn(skill, experience);
                Messages.Message("PawnGainExperience".Translate(pawn.Name.ToString(), experience, skill.label), MessageTypeDefOf.PositiveEvent);
            }
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref this.buffer, "buffer");
            Scribe_Values.Look(ref this.maxBuffer, "maxBuffer");
            Scribe_Values.Look(ref this.experienceRange, "experienceRange");
            Scribe_Defs.Look(ref this.skill, "skill");
        }

        public string buffer;
        public string maxBuffer;
        public SkillDef skill;
        public FloatRange experienceRange;
    }

    public class CQFAction_Destory : CQFAction_Target
    {
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            return result;
        }
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
        }
        public override void RealWork(Dictionary<string, TargetInfo> targets)
        {
            targets.ToList().ForEach(t =>
            {
                t.Value.Thing?.Destroy();
            });
        }

        public override void ExposeData()
        {
            base.ExposeData();
        }
    }
    public abstract class DialogCondition : ISaveable, IDrawable, IExposable
    {
        public virtual XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            result.SetAttributeValue("Class", this.GetType().FullName);
            return result;
        }
        public virtual void Draw(ref float y, Rect inRect, float x)
        {
            Widgets.Label(new Rect(x, y, 150f, 25f), this.GetType().Name.Translate().Colorize(ColorLibrary.SkyBlue));
            y += 30f;
        }
        public abstract bool Satisfied(Dictionary<string, TargetInfo> targets, out string reason);

        public abstract void ExposeData();


    }
    public abstract class DialogCondition_Target : DialogCondition
    {
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("targetText", this.targetText));
            return result;
        }
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
            EditorTools.DrawSelectableText(y, "DialogueTarget".Translate(), ref this.targetText, () => EditorTools.DrawFloatMenu(EditorTools.TargetTexts,
            t =>
            {
               this.targetText = t;
            }, t => t.Translate()), x, 150f);
            y += 30f;
        }
        public bool GetTarget(Dictionary<string, TargetInfo> targets, out Pawn targetPawn, out string reason)
        {
            if (targets.TryGetValue(this.targetText,out TargetInfo target)) 
            {
                reason = null;
                if (target.Thing == null || !(target.Thing is Pawn)) 
                {
                    reason = "TargetIsntPawn".Translate();
                    targetPawn = null;
                    return false;
                }
                targetPawn = target.Thing as Pawn;
                return true;
            }
            else
            {
                reason = "TargetIsntPawn".Translate(); 
                targetPawn = null;
                return false;
            }
        }

        public override void ExposeData()
        {
            Scribe_Values.Look(ref this.targetText, "DialogCondition_Target_targetText");
        }

        public string targetText;
    }
    public class DialogCondition_Skill : DialogCondition_Target
    {
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("skill", this.skill.defName));
            result.Add(new XElement("level", this.level));
            result.Add(new XElement("needToBeGreater", this.needToBeGreater));
            return result;
        }
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
            Rect rect = new Rect(x, y, 150f, 25f);
            rect = new Rect(x, y, 150f, 25f);
            Widgets.Label(rect, "RequiredSkill".Translate() + this.skill?.label);
            rect.x = 160f;
            if (Widgets.ButtonText(rect, "Select".Translate()))
            {
                EditorTools.DrawFloatMenu(DefDatabase<SkillDef>.AllDefsListForReading, s => this.skill = s, s => s.label);
            }
            y += 30f;
            EditorTools.DrawLabelAndText_Line(y, "RequiredLevel".Translate(), ref this.level, ref this.buffer, x);
            y += 30f;
            Widgets.CheckboxLabeled(new Rect(x, y, 125f, 20f), "NeedToBeGreater".Translate(), ref this.needToBeGreater);
            y += 25f;
        }
        public override bool Satisfied(Dictionary<string, TargetInfo> targets, out string reason)
        {
            if (base.GetTarget(targets, out Pawn targetPawn, out reason))
            {
                if (targetPawn != null && targetPawn.skills is Pawn_SkillTracker skill)
                {
                    if (this.needToBeGreater ? skill.GetSkill(this.skill).Level > this.level : skill.GetSkill(this.skill).Level < this.level)
                    {
                        reason = null;
                        return true;
                    }
                    else
                    {
                        reason = "SkillIsntsatisfied".Translate(this.skill);
                        return false;
                    }
                }
                else
                {
                    reason = "TargetIsntLikeHumanOrTargetIsNull".Translate();
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref this.level, "DialogCondition_Target_level");
            Scribe_Values.Look(ref this.needToBeGreater, "DialogCondition_Target_needToBeGreater");
            Scribe_Defs.Look(ref this.skill, "DialogCondition_Target_skill");
        }

        public string buffer;
        public SkillDef skill;
        public int level;
        public bool needToBeGreater = true;
    }

    public class DialogCondition_Hediff : DialogCondition_Target
    {
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("hediff", this.hediff.defName));
            result.Add(new XElement("severity", this.severity));
            result.Add(new XElement("needToBeGreater", this.needToBeGreater));
            return result;
        }
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
            Rect rect = new Rect(x, y, 150f, 25f);
            rect = new Rect(x, y, 150f, 25f);
            Widgets.Label(rect, "RequiredHediff".Translate() + this.hediff?.label);
            rect.x = 160f;
            if (Widgets.ButtonText(rect, "Select".Translate()))
            {
                EditorTools.DrawFloatMenu(DefDatabase<HediffDef>.AllDefsListForReading, h => this.hediff = h, h => h.label);
            }
            y += 30f;
            EditorTools.DrawLabelAndText_Line<float>(y, "RequiredSeverity".Translate(), ref this.severity, ref this.buffer, x);
            y += 30f;
            Widgets.CheckboxLabeled(new Rect(x, y, 125f, 20f), "NeedToBeGreater".Translate(), ref this.needToBeGreater);
            y += 25f;
        }
        public override bool Satisfied(Dictionary<string, TargetInfo> targets, out string reason)
        {
            if (base.GetTarget(targets, out Pawn targetPawn, out reason))
            {
                if (targetPawn != null && targetPawn.health is Pawn_HealthTracker health)
                {
                    if (health.hediffSet.GetFirstHediffOfDef(this.hediff) is Hediff hediff)
                    {
                        if (this.needToBeGreater ? hediff.Severity > this.severity : hediff.Severity < this.severity)
                        {
                            reason = null;
                            return true;
                        }
                        else
                        {
                            reason = "HediffIsntsatisfied".Translate(this.hediff);
                            return false;
                        }
                    }
                    else
                    {
                        reason = "TargetHasntRequired".Translate(this.hediff);
                        return false;
                    }
                }
                else
                {
                    reason = "TargetIsntLikeHumanOrTargetIsNull".Translate();
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref this.severity, "DialogCondition_Hediff_severity");
            Scribe_Values.Look(ref this.needToBeGreater, "DialogCondition_Hediff_needToBeGreater");
            Scribe_Defs.Look(ref this.hediff, "DialogCondition_Hediff_hediff");
        }

        public string buffer;
        public HediffDef hediff;
        public float severity;
        public bool needToBeGreater = true;
    }

    public class DialogCondition_Trait : DialogCondition_Target
    {
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("trait", this.trait.defName));
            result.Add(new XElement("degree", this.degree));
            result.Add(new XElement("needToBeGreater", this.needToBeGreater));
            return result;
        }
        public override void Draw(ref float y, Rect inRect, float x)
        {
            base.Draw(ref y, inRect, x);
            Rect rect = new Rect(x, y, 150f, 25f);
            List<KeyValuePair<TraitDef, TraitDegreeData>> stagets = new List<KeyValuePair<TraitDef, TraitDegreeData>>();
            DefDatabase<TraitDef>.AllDefsListForReading.ForEach(t =>
            {
                t.degreeDatas.ForEach(s =>
                {
                    stagets.Add(new KeyValuePair<TraitDef, TraitDegreeData>(t, s));
                });
            });
            if (Widgets.ButtonText(rect, "RequiredTrait".Translate(this.trait?.degreeDatas.Count > this.degree ? this.trait?.degreeDatas[this.degree].label : ""),false))
            {
                Find.WindowStack.Add(new Dialog_Select<KeyValuePair<TraitDef, TraitDegreeData>>(stagets, null, t => t.Value.label, "Select".Translate(), t =>
                {
                    this.trait = t.Key;
                    this.degree = t.Key.degreeDatas.IndexOf(t.Value);
                }));
            }
            y += 30f;
            Widgets.CheckboxLabeled(new Rect(x, y, 125f, 20f), "NeedToBeGreater".Translate(), ref this.needToBeGreater);
            y += 25f;
        }
        public override bool Satisfied(Dictionary<string, TargetInfo> targets, out string reason)
        {
            if (base.GetTarget(targets, out Pawn targetPawn, out reason))
            {
                if (targetPawn != null && targetPawn.story is Pawn_StoryTracker story)
                {
                    if (story.traits?.GetTrait(this.trait) is Trait trait)
                    {
                        if (this.needToBeGreater ? trait.Degree >= this.degree : trait.Degree <= this.degree)
                        {
                            reason = null;
                            return true;
                        }
                        else
                        {
                            reason = "TraitIsntsatisfied".Translate(this.trait.DataAtDegree(this.degree)?.label);
                            return false;
                        }
                    }
                    else
                    {
                        reason = "TargetHasntRequiredTrait".Translate(this.trait.DataAtDegree(this.degree)?.label);
                        return false;
                    }
                }
                else
                {
                    reason = "TargetIsntLikeHumanOrTargetIsNull".Translate();
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref this.degree, "DialogCondition_Trait_severity");
            Scribe_Values.Look(ref this.needToBeGreater, "DialogCondition_Trait_needToBeGreater");
            Scribe_Defs.Look(ref this.trait, "DialogCondition_Trait_hediff");
        }

        public string buffer;
        public TraitDef trait;
        public int degree = 0;
        public bool needToBeGreater = true;
    }
}