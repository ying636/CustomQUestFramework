﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;
using RimWorld.Planet;
using RimWorld.QuestGen;

namespace QuestEditor_Library
{
    public class CustomSitePartParams : SitePartParams
    {
        public IntVec3 spot;
        public CustomMapDataDef mapData;
        public Quest quest;
        public string siteIconPath;
        public string expandingIconPath;
        public bool isDev = false;
        public bool isSubMap = false;
    }
}
