﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;
using RimWorld.Planet;

namespace QuestEditor_Library
{
    public class MapParent_Custom : MapParent
    {
        public virtual string MapName => this.mapDataDef?.label ?? this.def.label;
        public override bool ShouldRemoveMapNow(out bool alsoRemoveWorldObject)
        {
            bool result = this.parentMap == null || !this.parentMap.Parent.Spawned || this.parentMap.Parent.Destroyed;
            alsoRemoveWorldObject = result;
            return result;
        }
        public override IEnumerable<FloatMenuOption> GetFloatMenuOptions(Caravan caravan)
        {
            yield break;
        }
        public override IEnumerable<FloatMenuOption> GetTransportPodsFloatMenuOptions(IEnumerable<IThingHolder> pods, CompLaunchable representative)
        {
            yield break;
        }
        public override IEnumerable<FloatMenuOption> GetShuttleFloatMenuOptions(IEnumerable<IThingHolder> pods, Action<int, TransportPodsArrivalAction> launchAction)
        {
            yield break;
        }
        public override void PostMapGenerate()
        {
            base.PostMapGenerate();
            CellIndices cellIndices = this.Map.cellIndices;
            if (this.Map.fogGrid.fogGrid == null)
            {
                this.Map.fogGrid.fogGrid = new bool[cellIndices.NumGridCells];
            }
            foreach (IntVec3 c in this.Map.AllCells)
            {
                this.Map.fogGrid.fogGrid[cellIndices.CellToIndex(c)] = true;
            }
            if (Current.ProgramState == ProgramState.Playing)
            {
                this.Map.roofGrid.Drawer.SetDirty();
            }
            foreach (IntVec3 loc in this.Map.AllCells)
            {
                this.Map.mapDrawer.MapMeshDirty(loc, MapMeshFlag.FogOfWar);
            }
        }
        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Defs.Look(ref this.mapDataDef, "CQF_MapParent_mapDataDef");
            Scribe_Values.Look(ref this.level, "CQF_MapParent_level");
            Scribe_Values.Look(ref this.enterSpot, "CQF_MapParent_EnterSpot");
            Scribe_References.Look(ref this.entrance, "CQF_MapParent_entrance");
            Scribe_References.Look(ref this.exit, "CQF_MapParent_Exit");
            Scribe_References.Look(ref this.parentMap, "CQF_MapParent_parentMap");
            Scribe_References.Look(ref this.rootSite, "CQF_MapParent_rootSite");
        }

        public int level = 0;
        public IntVec3 enterSpot;
        public CustomMapEntrance entrance;
        public CustomMapExit exit;
        public CustomMapDataDef mapDataDef;
        public Map parentMap;
        public CustomSite rootSite;
    }
}
