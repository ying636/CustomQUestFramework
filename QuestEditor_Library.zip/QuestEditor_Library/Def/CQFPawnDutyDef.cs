﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Verse.AI;

namespace QuestEditor_Library
{
    public class CQFPawnDutyDef : DutyDef
    {
    }
}
