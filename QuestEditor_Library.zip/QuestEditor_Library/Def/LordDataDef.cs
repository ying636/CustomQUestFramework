﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;
using Verse.AI.Group;

namespace QuestEditor_Library
{
    public class LordData
    {
        public string lordName;
    }
}