﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI.Group;

namespace QuestEditor_Library
{
    public class CustomMapDataDef : Def,ISaveable
    {
        public CustomMapDataDef(){}
        public void GenerateByCore(IntVec3 center, Map map,string questId,bool load =false)
        {
            try
            {
                GenStep_CustomMap.SpawnCustomMap(map, new GenStepParams(), this, questId, load, center, true);
            }
            catch (Exception e)
            {
                Log.Error($"Generate map part error:Mappart={this.defName},Center={center.ToString()},{e.Message}");
            }
    //if (Prefs.DevMode) 
    //{
    //    StringBuilder test = new StringBuilder();
    //    test.AppendLine(this.defName);
    //    test.AppendLine(this.rot.ToStringHuman());
    //    this.thingDatas.ForEach(t => test.AppendLine(t.def.label + t.position));
    //    this.customThings.ForEach(t => test.AppendLine(t.def.label + t.position));
    //    Log.Message(test.ToString().Trim());
    //}
}
        public CellRect GetRect(IntVec3 pos) 
        {
            List<IntVec3> cells = this.GetAllPosition();
            int? minX = null;
            int? maxX = null;
            int? minZ = null;
            int? maxZ = null;
            cells.ToList().ForEach((c) =>
            {
                maxX = maxX != null && c.x < maxX ? maxX : c.x;
                minX = minX != null && c.x > minX ? minX : c.x;
                minZ = minZ != null && c.z > minZ ? minZ : c.z;
                maxZ = maxZ != null && c.z < maxZ ? maxZ : c.z;
            });
            CellRect result = new CellRect(pos.x + minX.Value,pos.z + minZ.Value,(maxX - minX).Value + 1,(maxZ - minZ).Value + 1);
            return result;
        }
        public List<IntVec3> GetAllPosition() 
        {
            List<IntVec3> result = new List<IntVec3>();
            Action<IntVec3> add = p => 
            {
                if (!result.Contains(p)) 
                {
                    result.Add(p);
                }
            };
            this.customThings.ForEach(t => add(t.position));
            this.thingDatas.ForEach(d => add(d.position));
            this.pawns.Keys.ToList().ForEach(p => add(p));
            this.specialSpawnPawns.Keys.ToList().ForEach(p => add(p));
            this.routes.Values.ToList().ForEach(p => p.ForEach(p2 => add(p2)));
            this.terrains.Values.ToList().ForEach(p => p.ForEach(p2 => add(p2)));
            this.roofs.Values.ToList().ForEach(p => p.ForEach(p2 => add(p2)));
            return result;
        }
        public CustomMapDataDef GetRotated(Rot4 rot) 
        {
            if (!rot.IsValid || !this.rot.IsValid)
            {
                Log.Message("Invalid rotation:" + this.ToString());
                return null;
            }
            if (rot == this.rot) 
            {
                return this;
            }
            if (this.extraDataByDirection.ContainsKey(rot)) 
            {
                return this.extraDataByDirection[rot];
            }
            CustomMapDataDef result = this.Copy(rot.ToStringWord());
            RotationDirection direction = Rot4.GetRelativeRotation(result.rot, rot);
            result.thingDatas.ForEach(d =>
            {
                if (d.def.rotatable)
                {
                    d.rotation.Rotate(direction);
                }
            });
            result.customThings.ForEach(t =>
            {
                if (t.def.rotatable)
                {
                    t.rotation.Rotate(direction);
                }
                if (t is CustomThingData_ZoneCore core && (direction != RotationDirection.Opposite || core.coreRotation == rot || core.coreRotation == rot.Opposite))
                {
                    //if (Prefs.DevMode)
                    //{
                    //    Log.Message($"核心方向：{core.coreRotation.ToStringHuman()}");
                    //}
                    core.coreRotation.Rotate(direction);
                    //if (Prefs.DevMode) 
                    //{
                    //    Log.Message($"转换至{core.coreRotation.ToStringHuman()}，源于{result.rot.ToStringHuman()}至{rot.ToStringHuman()}");
                    //}
                }
            });
            switch (direction) 
            {
                case RotationDirection.Opposite:result.OppositeRotate(result.rot);break;
                case RotationDirection.Counterclockwise: result.CounterclockwiseRotate(result.rot); break;
                case RotationDirection.Clockwise: result.ClockwiseRotate(result.rot); break;
                default:;break;
            }
            result.rot = rot;
            this.extraDataByDirection.Add(rot, result); 
            return result;
        }
        public void CounterclockwiseRotate(Rot4 rot)
        {
            this.ChangePosition(new IntVec3(-1, 1, 1), (v, p) => new IntVec3(-p.z, p.y, p.x));
            this.size = new IntVec3(this.size.z, 1, this.size.x);
        }
        public void ClockwiseRotate(Rot4 rot)
        {
            this.ChangePosition(new IntVec3(-1, 1, 1), (v, p) => new IntVec3(p.z, p.y, -p.x));
            this.size = new IntVec3(this.size.z, 1, this.size.x);
        }
        public void OppositeRotate(Rot4 rot)
        {
            if (rot.AsVector2.x != 0)
            {
                this.ChangePosition(new IntVec3(-1, 1, 1), (v, p) => new IntVec3(-p.x, p.y, p.z));
            }
            else
            {
                this.ChangePosition(new IntVec3(1, 1, -1), (v, p) => new IntVec3(p.x, p.y, -p.z));
            }
        }
        public CustomMapDataDef GetNewDataUseNewOrigih(IntVec3 posInMap,Rot4 rot)
        {
            if (this.extraDataByOrigin.ContainsKey(posInMap))
            {
                return this.extraDataByOrigin[posInMap];
            }
            CustomMapDataDef result = this.Copy(posInMap.ToString());
            result.customThings.Remove(result.customThings.Find(t => t is CustomThingData_ZoneCore && t.position == posInMap));
            result.ChangePosition(posInMap,(variable,position) => position - variable);
            result.rot = rot;
            this.extraDataByOrigin.Add(posInMap, result);
            return result;
        }
        private void ChangePosition(IntVec3 variable,Func<IntVec3,IntVec3,IntVec3> ChangingAction)
        {
            this.thingDatas.ForEach(d =>
            {
                d.position = ChangingAction(variable, d.position);
                List<IntVec3> cells = d.allPositions.ListFullCopy();
                d.allPositions.Clear();
                cells.ForEach(c => d.allPositions.Add(ChangingAction(variable, c)));
            });
            this.customThings.ForEach(t => t.position = ChangingAction(variable, t.position));
            foreach (KeyValuePair<string, List<IntVec3>> terrain in this.terrains.ToList().ListFullCopy())
            {
                List<IntVec3> poss = new List<IntVec3>();
                terrain.Value.ForEach(t => poss.Add(ChangingAction(variable, t)));
                this.terrains[terrain.Key] = poss;
            }
            foreach (KeyValuePair<RoofDef, List<IntVec3>> roof in this.roofs.ToList().ListFullCopy())
            {
                List<IntVec3> poss = new List<IntVec3>();
                roof.Value.ForEach(t => poss.Add(ChangingAction(variable, t)));
                this.roofs[roof.Key] = poss;
            }
            foreach (KeyValuePair<string, List<IntVec3>> route in this.routes.ToList().ListFullCopy())
            {
                List<IntVec3> poss = new List<IntVec3>();
                route.Value.ForEach(t => poss.Add(ChangingAction(variable, t)));
                this.routes[route.Key] = poss;
            }
            List<KeyValuePair<IntVec3, List<PawnSpawnData>>> pawns = this.pawns.ToList().ListFullCopy();
            this.pawns.Clear();
            foreach (KeyValuePair<IntVec3, List<PawnSpawnData>> pawn in pawns)
            {
                this.pawns.Add(ChangingAction(variable, pawn.Key), pawn.Value);
            }
            List<KeyValuePair<IntVec3, List<PawnSpawnData>>> specialSpawnPawns = this.specialSpawnPawns.ToList().ListFullCopy();
            this.specialSpawnPawns.Clear();
            foreach (KeyValuePair<IntVec3, List<PawnSpawnData>> pawn in specialSpawnPawns)
            {
                this.specialSpawnPawns.Add(ChangingAction(variable, pawn.Key), pawn.Value);
            }
         
        }
        public CustomMapDataDef Copy(string name) 
        {
            CustomMapDataDef result = new CustomMapDataDef();
            result.defName = this.defName + name;
            result.size = this.size;
            result.isPart = this.isPart;
            result.fogged = this.fogged;
            result.tags = this.tags.ListFullCopy();
            result.rot = this.rot;
            result.customThings.Clear();
            this.customThings.ListFullCopy().ForEach(t => result.customThings.Add(t.Copy()));
            this.thingDatas.ForEach(d => result.thingDatas.Add(d.Copy()));
            result.terrains = new Dictionary<string, List<IntVec3>>();
            this.terrains.ToList().ForEach(t => result.terrains.Add(t.Key,t.Value));
            result.roofs = new Dictionary<RoofDef, List<IntVec3>>();
            this.roofs.ToList().ForEach(t => result.roofs.Add(t.Key, t.Value));
            result.pawns = new Dictionary<IntVec3, List<PawnSpawnData>>();
            this.pawns.ToList().ForEach(t => result.pawns.Add(t.Key, t.Value));
            result.specialSpawnPawns = new Dictionary<IntVec3, List<PawnSpawnData>>();
            this.specialSpawnPawns.ToList().ForEach(t => result.specialSpawnPawns.Add(t.Key, t.Value));
            result.routes = new Dictionary<string, List<IntVec3>>();
            this.routes.ToList().ForEach(t => result.routes.Add(t.Key, t.Value));
            result.replaces = new Dictionary<ThingDef, List<ThingDef>>();
            this.replaces.ToList().ForEach(t => result.replaces.Add(t.Key, t.Value));
            return result;
        }
        public void LoadData(Map map)
        {
            IntVec3 centre = map.Center;
            this.size = map.Size;
            foreach (KeyValuePair<string, List<IntVec3>> route in EditorTools.route)
            {
                List<IntVec3> routePoss = new List<IntVec3>();
                foreach (IntVec3 pos in route.Value)
                {
                    routePoss.Add(pos - centre);
                }
                this.routes.Add(route.Key, routePoss);
            }
            this.SaveThings(centre, map.listerThings.AllThings);
            SavePoss(map,map.AllCells.ToList(), centre);
            map.designationManager.designationsByDef[QEDefOf.QE_Disgenerate].ForEach(d => this.disgenerate.Add(d.target.Cell - centre));
        }
        public void LoadData(Map map,List<IntVec3> poss,IntVec3 size)
        {
            int? minX = null;
            int? minZ = null;
            poss.ToList().ForEach((c) =>
            {
                minX = minX != null && c.x > minX ? minX : c.x;
                minZ = minZ != null && c.z > minZ ? minZ : c.z;
            });
            IntVec3 centre = new IntVec3(minX.Value,0,minZ.Value);
            this.size = size;
            foreach (KeyValuePair<string, List<IntVec3>> route in EditorTools.route)
            {
                List<IntVec3> routePoss = new List<IntVec3>();
                foreach (IntVec3 pos in route.Value)
                {
                    if (poss.Contains(pos))
                    {
                        routePoss.Add(pos - centre);
                    }
                }
                if (routePoss.Any())
                {
                    this.routes.Add(route.Key, routePoss);
                }
            }
            List<Thing> things = new List<Thing>();
            poss.ForEach(p =>
            {
                if (p.InBounds(map))
                {
                    p.GetThingList(map).ForEach(t =>
                    {
                        if (!things.Contains(t))
                        {
                            things.Add(t);
                        }
                    });
                }
            });
            this.SaveThings(centre, things);
            this.SavePoss(map, poss, centre);
        }
        private void SavePoss(Map map,List<IntVec3> poss,IntVec3 centre)
        {
            foreach (IntVec3 pos in poss)
            {
                IntVec3 savePos = pos - centre;
                if (map.roofGrid.Roofed(pos))
                {
                    RoofDef roofDef = map.roofGrid.RoofAt(pos);
                    if (this.roofs.TryGetValue(roofDef, out List<IntVec3> list))
                    {
                        list.Add(savePos);

                    }
                    else
                    {
                        this.roofs.Add(roofDef, new List<IntVec3>() { savePos });
                    }
                }
                if (pos.GetTerrain(map) is TerrainDef def && def.defName != "QE_Null")
                {
                    if (this.terrains.TryGetValue(def.defName, out List<IntVec3> list))
                    {
                        list.Add(savePos);
                    }
                    else
                    {
                        this.terrains.Add(def.defName, new List<IntVec3>() { savePos });
                    }
                }
            }
        }
        private void SaveThings(IntVec3 centre, List<Thing> things)
        {
            List<ThingData> datas = new List<ThingData>();
            foreach (Thing thing in things)
            {
                if (thing is Pawn || thing is Gas)
                {
                    continue;
                }
                IntVec3 savePos = thing.Position - centre;
                if (thing is LootBox lootBox)
                {
                    this.customThings.Add(new CustomThingData_LootBox(lootBox, savePos));
                    continue;
                }
                if (thing is InteractableThing it)
                {
                    this.customThings.Add(new CustomThingData_InteractableThing(it, savePos));
                    continue;
                }
                if (thing is CustomMapEntrance entrance)
                {
                    this.customThings.Add(new CustomThingData_CustomMapEntrance(entrance, savePos));
                    continue;
                }
                if (thing is CustomMapExit exit)
                {
                    this.customThings.Add(new CustomThingData_CustomMapExit(exit, savePos));
                    continue;
                }
                if (thing is ZoneCore core)
                {
                    this.customThings.Add(new CustomThingData_ZoneCore(core, savePos));
                    continue;
                }
                if (thing is CustomTrap trap)
                {
                    this.customThings.Add(new CustomThingData_CustomTrap(trap, savePos));
                    continue;
                }
                if (thing is Spawner spawner)
                {
                    List<PawnSpawnData> pawns = new List<PawnSpawnData>();
                    List<PawnSpawnData> specialPawns = new List<PawnSpawnData>();
                    foreach (PawnSpawnData pawnKinds in spawner.pawns)
                    {
                        if (!(pawnKinds.kind == null || pawnKinds.count.max < 1) || pawnKinds.GetType() != typeof(PawnSpawnData))
                        {
                            if (pawnKinds.spawnType == SpawnType.MapGeneration)
                            {
                                pawns.Add(pawnKinds);
                            }
                            else
                            {
                                specialPawns.Add(pawnKinds);
                            }
                        }
                    }
                    if (specialPawns.Any())
                    {
                        this.specialSpawnPawns.Add(savePos, specialPawns);
                    }
                    if (pawns.Any())
                    {
                        this.pawns.Add(savePos, pawns);
                    }
                    continue;
                }

                ThingData data = new ThingData(thing, savePos);
                if (datas.Find(d => d.Equals_Def(data)) is ThingData dataEqualed)
                {
                    dataEqualed.allPositions.Add(savePos);
                }
                else
                {
                    datas.Add(new ThingData(thing, savePos));
                }
            }
            datas.ForEach(d => 
            {
                if (d.allPositions.Any()) 
                {
                    d.allPositions.Add(d.position);
                    d.position = IntVec3.Zero;
                }
                this.thingDatas.Add(d);
            });
        }
        public XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            Log.Message(this.defName);
            result.Add(new XElement("defName", this.defName));
            result.Add(new XElement("label", this.label));
            result.Add(new XElement("fogged",this.fogged));
            result.Add(new XElement("size", this.size));
            result.Add(new XElement("isPart", this.isPart));
            if (this.replaces.Any()) 
            {
                result.Add(EditorTools.SaveDictionary_List(this.replaces, "replaces"));
            }
            if (this.customThings.Any())
            {
                result.Add(EditorTools.SaveList_Saveable(this.customThings, "customThings"));
            }
            if (this.specialSpawnPawns.Any())
            {
                result.Add(EditorTools.SaveDictionary_Saveable_List(this.specialSpawnPawns, "specialSpawnPawns"));
            }
            if (this.pawns.Any())
            {
                result.Add(EditorTools.SaveDictionary_Saveable_List(this.pawns, "pawns"));
            }
            if (this.routes.Any())
            {
                result.Add(EditorTools.SaveDictionary_List(this.routes, "routes"));
            }
            if (this.roofs.Any())
            {
                result.Add(EditorTools.SaveDictionary_List(this.roofs, "roofs"));
            }
            if (this.terrains.Any())
            {
                result.Add(EditorTools.SaveDictionary_List(this.terrains, "terrains"));
            }
            if (this.thingDatas.Any())
            {
                result.Add(EditorTools.SaveList_Saveable(this.thingDatas, "thingDatas"));
            }
            if (this.steps.Any())
            {
                result.Add(EditorTools.SaveList_Saveable(this.steps, "steps"));
            }
            if (this.tags.Any())
            {
                result.Add(EditorTools.SaveList(this.tags, "tags"));
            }
            if (this.disgenerate.Any())
            {
                result.Add(EditorTools.SaveList(this.disgenerate, "disgenerate"));
            }
            if (this.reserveThing != null) 
            {
                result.Add(this.reserveThing.SaveToXElement("reserveThing"));
            }
            return result;
        }
        public bool fogged = false;
        public IntVec3 size;  
        public bool isPart = false;
        public Dictionary<ThingDef, List<ThingDef>> replaces = new Dictionary<ThingDef, List<ThingDef>>();
        public List<CustomThingData> customThings = new List<CustomThingData>();
        public Dictionary<IntVec3, List<PawnSpawnData>> specialSpawnPawns = new Dictionary<IntVec3, List<PawnSpawnData>>();
        public Dictionary<IntVec3, List<PawnSpawnData>> pawns = new Dictionary<IntVec3, List<PawnSpawnData>>();
        public Dictionary<string, List<IntVec3>> routes = new Dictionary<string, List<IntVec3>>();
        public Dictionary<RoofDef, List<IntVec3>> roofs = new Dictionary<RoofDef, List<IntVec3>>();
        public Dictionary<string, List<IntVec3>> terrains = new Dictionary<string, List<IntVec3>>();
        public List<ThingData> thingDatas = new List<ThingData>();
        public List<CustomMapStep> steps = new List<CustomMapStep>();
        public List<string> tags = new List<string>();
        public ThingData reserveThing = null;
        public List<IntVec3> disgenerate = new List<IntVec3>();


        public Rot4 rot = Rot4.Invalid;
        public Dictionary<Rot4, CustomMapDataDef> extraDataByDirection = new Dictionary<Rot4, CustomMapDataDef>();
        public Dictionary<IntVec3, CustomMapDataDef> extraDataByOrigin = new Dictionary<IntVec3, CustomMapDataDef>();
    }

    public abstract class CustomMapStep : IDrawable , ISaveable
    {
        public abstract void Generate(Map map,CustomMapDataDef def, CustomSitePartParams param);
        public abstract void Draw(ref float y, Rect inRect, float x);
        public virtual XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            result.SetAttributeValue("Class", this.GetType().FullName);
            return result;
        }
    }
}
