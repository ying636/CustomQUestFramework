﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI.Group;

namespace QuestEditor_Library
{
    public class GameComponent_Editor : GameComponent
    {
        public GameComponent_Editor(Game game)
        {
        }
        public Dictionary<Thing, DialogManagerDef> Dialogs 
        {
            get 
            {
                if (this.dialogsWithTargets == null) 
                {
                    this.dialogsWithTargets = new Dictionary<Thing, DialogManagerDef>();
                }
                return this.dialogsWithTargets;
            }
        }

        public void AddDialog(Thing thing, DialogManagerDef def) 
        {
            if (!this.Dialogs.ContainsKey(thing)) 
            {
                this.dialogsWithTargets.Add(thing,def);
            }
        }
        public void RemoveDialog(Thing thing)
        {
            if (this.Dialogs.ContainsKey(thing))
            {
                this.dialogsWithTargets.Remove(thing);
            }
        }
        public override void StartedNewGame()
        {
            base.StartedNewGame(); 
            GameComponent_Editor.component = Current.Game.GetComponent<GameComponent_Editor>();
        }
        public override void LoadedGame()
        {
            base.LoadedGame();
            if (this.dialogsWithTargets == null) 
            {
                this.dialogsWithTargets = new Dictionary<Thing, DialogManagerDef>();
            }
            this.dialogsWithTargets.RemoveAll(d => !d.Key.Spawned || (d.Key is Pawn p && p.Dead)); 
            GameComponent_Editor.component = Current.Game.GetComponent<GameComponent_Editor>();
        }
        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref EditorTools.route, "QE_GameComponent_Editor_route",LookMode.Value,LookMode.Value);        
            Scribe_Collections.Look(ref this.dialogsWithTargets, "QE_GameComponent_Editor_dialogsWithTargets", LookMode.Reference, LookMode.Def,ref this.tmpdialogsThings,ref this.tmpdialogsDialogManagerDefs);
            Scribe_Collections.Look(ref this.lords, "QE_GameComponent_Editor_lords", LookMode.Value, LookMode.Reference,ref this.tmpNames,ref this.tmpLord);
            Scribe_Collections.Look(ref this.pawns, "QE_GameComponent_Editor_pawns", LookMode.Value, LookMode.Reference, ref this.tmpPawnIDs, ref this.tmpPawns);
        }

        public Dictionary<Thing, DialogManagerDef> dialogsWithTargets = new Dictionary<Thing, DialogManagerDef>();
        public List<Thing> tmpdialogsThings;
        public List<DialogManagerDef> tmpdialogsDialogManagerDefs;
        public Dictionary<string, DialogManagerDef> dialogs = new Dictionary<string, DialogManagerDef>();
        public Dictionary<int, QuestData> datas = new Dictionary<int, QuestData>();
        public Dictionary<string, Pawn> pawns = new Dictionary<string, Pawn>();
        public List<string> tmpPawnIDs;
        public List<Pawn> tmpPawns;
        public Dictionary<string, Lord> lords = new Dictionary<string, Lord>();   
        public List<string> tmpNames;
        public List<Lord> tmpLord;
        public static GameComponent_Editor component = null;
    }

    public class QuestData 
    {
        public Dictionary<string, int> values = new Dictionary<string, int>();
    }

}
