﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;
using Verse.AI;
using Verse.AI.Group;

namespace QuestEditor_Library
{
    public class JobDriver_Patrol : JobDriver
    {
        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return true;
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            if (this.pawn.GetLord().LordJob is LordJob_Custom lordJob && lordJob.pawnRouteDatas.TryGetValue(this.pawn,out RouteData data))
            {
                foreach (IntVec3 target in data.routue)
                {
                    if (this.pawn.CanReach(target, PathEndMode.OnCell, Danger.Deadly))
                    {
                        yield return Toils_Goto.GotoCell(target, PathEndMode.OnCell);
                    }
                } 
            }
            yield break;
        }
    }
}
