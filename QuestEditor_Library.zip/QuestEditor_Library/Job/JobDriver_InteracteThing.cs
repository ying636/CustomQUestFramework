﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;
using Verse.AI;

namespace QuestEditor_Library
{
    public class JobDriver_InteracteThing : JobDriver
    {
        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return this.pawn.Reserve(this.TargetThingA,this.job,1,-1,null,errorOnFailed);
        }
     
        protected override IEnumerable<Toil> MakeNewToils()
        {
            string text = this.GetReport();
            InteractableThing thing = (InteractableThing)this.TargetThingA;
            yield return Toils_Goto.Goto(TargetIndex.A,PathEndMode.Touch);
            Toil toil = Toils_General.WaitWith(TargetIndex.A, thing.GetCurOperation(text).tickToOperate, true);
            toil.AddPreTickAction(() => this.pawn.rotationTracker.FaceTarget(thing));
            yield return toil;
            yield return new Toil() {initAction = () => thing.ProduceResult(this.pawn,text),defaultCompleteMode = ToilCompleteMode.Delay};
            yield break;
        }
    }
}
