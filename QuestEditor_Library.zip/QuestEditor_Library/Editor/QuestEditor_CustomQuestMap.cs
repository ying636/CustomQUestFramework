﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using RimWorld.Planet;
using System.IO;
using System.Xml;

namespace QuestEditor_Library
{
    public class QuestEditor_CustomQuestMap : Page
    {
        public override string PageTitle => "SpawnNewCustomMap".Translate();
        public override Vector2 InitialSize => QuestEditor_CustomQuestMap.size;
        public override void DoWindowContents(Rect inRect)
        {
            base.DrawPageTitle(inRect);
            if (Widgets.CloseButtonFor(inRect))
            {
                this.Close();
            }
            float y = 50f;
            string text = "MapSize".Translate();
            Widgets.Label(new Rect((inRect.width - Text.CalcSize(text).x) / 2, y, 300f, 30f), text);
            y += 25f;
            Widgets.TextFieldNumeric<int>(new Rect((inRect.width / 2) - 75f, y, 70f, 20f), ref this.mapSize.x, ref this.buffer);
            Widgets.Label(new Rect((inRect.width / 2) - 5f, y, 10f, 20f), "x");
            Widgets.TextFieldNumeric<int>(new Rect((inRect.width / 2) + 5f, y, 70f, 20f), ref this.mapSize.z, ref this.bufferz);
            y += 35f;
            if (Widgets.ButtonText(new Rect(10f, y, 100f, 38f), "OK".Translate()))
            {
                GenerateMap(this.mapSize);
                this.Close();
            }
            if (Widgets.ButtonText(new Rect(inRect.width - 110f, y, 100f, 38f), "Load".Translate()))
            {
                Action<CustomMapDataDef> generateMap = (m) =>
                {
                    GenStep_SetTerrain.customMap = m;
                    GenerateMap(m.size, m);
                };
                List<FloatMenuOption> options = new List<FloatMenuOption>();
                DirectoryInfo ruleDir = new DirectoryInfo(Page_QuestEditor.Path + @"\Map\");
                foreach (FileInfo file in ruleDir.GetFiles("*.xml"))
                {
                    XmlDocument xml = new XmlDocument();
                    xml.Load(file.FullName);
                    foreach (XmlNode xmlNode in xml.SelectNodes("//QuestEditor_Library.CustomMapDataDef"))
                    {
                        FloatMenuOption option = new FloatMenuOption(xmlNode["defName"].InnerText, () =>
                        {
                            generateMap(DirectXmlToObject.ObjectFromXml<CustomMapDataDef>(xmlNode, false));
                            this.Close();
                        });
                        options.Add(option);
                    }
                }
                DefDatabase<CustomMapDataDef>.AllDefsListForReading.ForEach(x => options.Add(new FloatMenuOption(x.label, () =>
                {
                    generateMap(x);
                    this.Close();
                })));
                if (options.Any())
                {
                    Find.WindowStack.Add(new FloatMenu(options));
                }
            }
        }

        public static void GenerateMap(IntVec3 size,CustomMapDataDef def = null) 
        {
            if (Current.Game == null)
            {
                Messages.Message("NoGame".Translate(), MessageTypeDefOf.CautionInput);
                return;
            }
            if (size.z <= 0 || size.x <= 0)
            {
                Messages.Message("MapSizeCantBeZero".Translate(), MessageTypeDefOf.CautionInput);
                return;
            }
            MapGenerator.PlayerStartSpot = new IntVec3(size.x / 2, 1, size.z / 2);
            MapParent customMap = (MapParent)WorldObjectMaker.MakeWorldObject(DefDatabase<WorldObjectDef>.GetNamed("QE_CustomMap_Editor"));
            customMap.Tile = TileFinder.RandomSettlementTileFor(Faction.OfPlayer);
            customMap.SetFaction(Find.FactionManager.OfPlayer);
            Find.WorldObjects.Add(customMap);
            string seed = Find.World.info.seedString;
            Find.World.info.seedString = Find.TickManager.TicksGame.ToString();
            LongEventHandler.SetCurrentEventText("GeneratingMap".Translate());
            DeepProfiler.Start("Generate new map");
            LongEventHandler.QueueLongEvent(() =>
            {
                size.y = 1;
                Map map = MapGenerator.GenerateMap(size, customMap, customMap.MapGeneratorDef, def == null ? customMap.ExtraGenStepDefs :
                    Gen.YieldSingle(new GenStepWithParams(QEDefOf.QE_CustomSite_GenStep, new GenStepParams()
                    {
                        sitePart = new SitePart(null, QEDefOf.QE_CustomSite, new CustomSitePartParams()
                        {
                            mapData = def,
                            isDev = true
                        })
                    })));
                Current.Game.CurrentMap = map;
            }, "GeneratingMap".Translate(), true, (Exception x) => { Log.Message("GenerateMapError:" + x.ToString()); });
            Find.World.info.seedString = seed;
            DeepProfiler.End();
            Find.WindowStack.TryRemove(typeof(Page_QuestEditor));
        }

        public IntVec3 mapSize = IntVec3.Zero;
        public string buffer;
        public string bufferz;
        private static readonly Vector2 size = new Vector2(260f, 200f);
    }
}
