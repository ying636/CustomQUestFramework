﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace QuestEditor_Library
{
    public class Designator_CQFTools : Designator_Place
    {
        public Designator_CQFTools()
        {
            this.defaultLabel = Designator_CQFTools.thing.label.Colorize(ColorLibrary.SkyBlue);
            this.icon = Designator_CQFTools.thing.GetUIIconForStuff(null);
            this.defaultDesc = Designator_CQFTools.thing.description.Colorize(ColorLibrary.SkyBlue);
            this.useMouseIcon = true;
        }
        public override bool Visible => DebugSettings.godMode;
        public override int DraggableDimensions
        {
            get
            {
                return 2;
            }
        }
        public override BuildableDef PlacingDef => thing;

        public override ThingStyleDef ThingStyleDefForPreview => null;

        public override ThingDef StuffDef => stuff;
        public override Color IconDrawColor => this.PlacingDef.MadeFromStuff && this.StuffDef != null ? this.PlacingDef?.GetColorForStuff(this.StuffDef) ?? base.IconDrawColor : base.IconDrawColor;
        public static List<Type> ToolTypes => new List<Type>() { typeof(LootBox), typeof(Spawner), typeof(InteractableThing), typeof(CustomMapEntrance), typeof(CustomMapExit) ,typeof(ZoneCore) };
        public static bool IsCQFTool(ThingDef def) 
        {
            return ToolTypes.Exists(t => def.thingClass == t || def.thingClass.IsSubclassOf(t));
        }
        public override IEnumerable<FloatMenuOption> RightClickFloatMenuOptions
        {
            get
            {
                if (Designator_CQFTools.bespawnable.NullOrEmpty())
                {
                    foreach (ThingDef def in DefDatabase<ThingDef>.AllDefsListForReading)
                    {
                        if (Designator_CQFTools.IsCQFTool(def))
                        {
                            Designator_CQFTools.bespawnable.Add(def);
                        }
                    }
                }
                yield return new FloatMenuOption("Select".Translate(), () =>
                 {
                     Find.WindowStack.Add(new Dialog_Select<ThingDef>(Designator_CQFTools.bespawnable,
            x => x.uiIcon, x => Designator_CQFTools.IsCQFTool(x) ? x.label.Colorize(ColorLibrary.SkyBlue) : x.label, "Select".Translate(),
            x =>
            {
                Designator_CQFTools.thing = x;
                this.iconProportions = x.graphicData.drawSize.RotatedBy(x.defaultPlacingRot);
                string label = x.label;
                if (Designator_CQFTools.IsCQFTool(x))
                {
                    label = label.Colorize(ColorLibrary.SkyBlue);
                }
                this.defaultLabel = label;
                stuff = null;
                this.defaultDesc = x.description.Colorize(ColorLibrary.SkyBlue);
                if (x.graphicData.onGroundRandomRotateAngle > 0.01f)
                {
                    this.icon = ContentFinder<Texture2D>.Get(x.uiIconPath);
                }
                else
                {
                    this.icon = x.GetUIIconForStuff(this.StuffDef);
                }
                if (x.MadeFromStuff) 
                {
                    Find.WindowStack.Add(new Dialog_Select<ThingDef>(GenStuff.AllowedStuffsFor(x).ToList(),s => s.uiIcon,s => s.label,"SelectStuff".Translate(),s => 
                    {
                        stuff = s;
                        this.defaultLabel = s.LabelAsStuff.Colorize(ColorLibrary.SkyBlue) + this.defaultLabel;
                        if (x.graphicData.onGroundRandomRotateAngle > 0.01f)
                        {
                            this.icon = ContentFinder<Texture2D>.Get(x.uiIconPath);
                        }
                        else
                        {
                            this.icon = x.GetUIIconForStuff(s);
                        }
                    }, t => t.graphic?.Color ?? Color.white, (t, r) => Widgets.DefIcon(r, t, null)));
                }
            }, t => t.graphic?.Color ?? Color.white, (t, r) => Widgets.DefIcon(r, t, null)));
                 });
                yield break;
            }
        }

        public override void DesignateSingleCell(IntVec3 loc)
        {
            if (loc.InBounds(Find.CurrentMap))
            {
                ThingDef def = Designator_CQFTools.thing;
                if (loc.GetFirstThing(Find.CurrentMap, def) is Thing thing && thing.stackCount < thing.def.stackLimit)
                {
                    thing.stackCount++;
                    return;
                }
                Thing newThing = GenSpawn.Spawn(ThingMaker.MakeThing(def,def.MadeFromStuff ? this.StuffDef : null), loc, Find.CurrentMap, this.placingRot);
                if (newThing is Building building) 
                {
                    building.SetFaction(Faction.OfPlayer);
                }
            }
        }
        public override AcceptanceReport CanDesignateCell(IntVec3 loc)
        {
            return true;
        }

        public static ThingDef thing = QEDefOf.QE_Spawner_Editor;
        public static ThingDef stuff = ThingDefOf.WoodLog;
        public static List<ThingDef> bespawnable = new List<ThingDef>();
    }
}
