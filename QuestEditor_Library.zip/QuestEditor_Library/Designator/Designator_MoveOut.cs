﻿using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using Verse;

namespace QuestEditor_Library
{
    public class Designator_MoveOut : Designator_Cells
    {
        public Designator_MoveOut()
        {
            this.defaultLabel = "QE_Designator_MoveOut".Translate();
            this.icon = ContentFinder<Texture2D>.Get("UI/Icon_MoveOut", true);
            this.defaultDesc = "QE_Designator_MoveOutDesc".Translate();
            this.useMouseIcon = true;
        }
        public override bool Visible => true;
        public override int DraggableDimensions => 2;
        public override bool DragDrawMeasurements => true;
        public override void DesignateThing(Thing t)
        {
            this.DesignateSingleCell(t.Position);
        }
        public override AcceptanceReport CanDesignateThing(Thing t)
        {
            if (!t.def.alwaysHaulable)
            {
                return false;
            }
            if (base.Map.designationManager.DesignationAt(t.Position, this.Designation) != null)
            {
                return AcceptanceReport.WasRejected;
            }
            return true;
        }
        public override void DesignateSingleCell(IntVec3 loc)
        {
            if (!loc.InBounds(this.Map)) 
            {
                return;
            }
            Pawn targetPawn = loc.GetFirstPawn(this.Map);
            Thing target = targetPawn == null || targetPawn.Faction != Faction.OfPlayer || targetPawn.Downed ? loc.GetFirstItem(this.Map) : targetPawn;
            if (target != null && !this.Map.designationManager.HasMapDesignationOn(target))
            {
                if (target.Map.Parent is MapParent_Custom custom && custom.exit != null)
                {
                    this.Map.designationManager.AddDesignation(new Designation(target, QEDefOf.QE_MoveOut));
                }
                else
                {
                    Messages.Message("TargetIsntWithinSubMap".Translate(Designator_MoveIn.target.MapName), MessageTypeDefOf.NegativeEvent);
                }
            }
        }
        public override AcceptanceReport CanDesignateCell(IntVec3 loc)
        {
            return true;
        }
    }
}
