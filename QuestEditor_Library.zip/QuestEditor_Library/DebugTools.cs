﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using Verse;

namespace QuestEditor_Library
{
    public static class DebugTools
	{
		[DebugAction("QuestEditor", null, false, false, actionType = DebugActionType.Action, allowedGameStates = AllowedGameStates.Playing)]
		private static void AddDialog()
		{
			List<DebugMenuOption> options = new List<DebugMenuOption>();
			foreach (DialogManagerDef def in DefDatabase<DialogManagerDef>.AllDefsListForReading)
			{
				options.Add(new DebugMenuOption(def.defName, DebugMenuOptionMode.Tool, () =>
				{
					IntVec3 pos = UI.MouseCell();
					if (pos.InBounds(Find.CurrentMap) && pos.GetFirstPawn(Find.CurrentMap) is Pawn target)
					{
						Current.Game.GetComponent<GameComponent_Editor>().AddDialog(target,def);
					}
				}));
			}
			Find.WindowStack.Add(new Dialog_DebugOptionListLister(options));
		}
		[DebugAction("QuestEditor", null, false, false, actionType = DebugActionType.Action, allowedGameStates = AllowedGameStates.Playing)]
		private static void UnclearGenerationData()
		{
			DebugTools.clearGenerationData = !DebugTools.clearGenerationData;
			Log.Message(DebugTools.clearGenerationData.ToString());
		}
		[DebugAction("QuestEditor", null, false, false, actionType = DebugActionType.Action, allowedGameStates = AllowedGameStates.Playing)]
		private static void DisgenerateByCore()
		{
			EditorTools.disgenerateByCore = !EditorTools.disgenerateByCore;
			Log.Message(EditorTools.disgenerateByCore.ToString());
		}
		[DebugAction("QuestEditor", null, false, false, actionType = DebugActionType.Action, allowedGameStates = AllowedGameStates.Playing)]
		private static void GetMapInformation()
		{
			MapComponent_CustomMapData comonent = Find.CurrentMap.GetComponent<MapComponent_CustomMapData>();
			StringBuilder information = new StringBuilder();
			information.AppendLine("自定义地图：");
			information.AppendLine($"地图：{comonent.map.GetUniqueLoadID()},，入口：{(Find.CurrentMap.Parent as MapParent_Custom)?.entrance?.ThingID}，出口：{(Find.CurrentMap.Parent as MapParent_Custom)?.exit?.ThingID}");
			comonent.subMaps.ForEach(m => GetSubMapText(m,ref information));
			Log.Message(information.ToString().Trim());
		}

		public static void GetSubMapText(MapParent_Custom map,ref StringBuilder information) 
		{
			information.AppendLine($"地图：{map.GetUniqueLoadID()}，入口：{map.entrance?.ThingID}，出口：{map.exit?.ThingID}");
			foreach (MapParent_Custom m in map.Map.GetComponent<MapComponent_CustomMapData>().subMaps) 
			{
				GetSubMapText(m, ref information);
			}
		}

		[DebugAction("QuestEditor", null, false, false, actionType = DebugActionType.Action, allowedGameStates = AllowedGameStates.Playing)]
		private static void GetComponentInformation()
		{
			GameComponent_Editor component = Current.Game.GetComponent<GameComponent_Editor>();
			StringBuilder information = new StringBuilder("任务数据：");
			foreach (KeyValuePair<int,QuestData> data in component.datas) 
			{
				information.AppendLine("索引：" + data.Key + "，数据：" + data.Value.ToString());
			}
			information.AppendLine("对话：");
			foreach (KeyValuePair<Thing, DialogManagerDef> tree in component.Dialogs)
			{
				information.AppendLine("ID：" + tree.Key + "，对话树：" + tree.Value.ToString());
			}
			Log.Message(information.ToString().Trim());
		}
		[DebugAction("QuestEditor", null, false, false, actionType = DebugActionType.Action, allowedGameStates = AllowedGameStates.Playing)]
		private static void GenerateCustomMapData()
		{
			List<DebugMenuOption> options = new List<DebugMenuOption>();
			DefDatabase<CustomMapDataDef>.AllDefsListForReading.ForEach(d =>
			{
				options.Add(new DebugMenuOption(d.label, DebugMenuOptionMode.Action, () =>
				{
					List<DebugMenuOption> options2 = new List<DebugMenuOption>();
					options2.Add(new DebugMenuOption("Base", DebugMenuOptionMode.Tool, () =>
					{
						d.GenerateByCore(UI.MouseCell(), Find.CurrentMap,"0",true);
					}));
					d.extraDataByOrigin.ToList().ForEach(d3 =>
					{
						options2.Add(new DebugMenuOption(d3.Key.ToString() + d3.Value.rot.ToStringHuman(), DebugMenuOptionMode.Tool, () =>
						{
							d3.Value.GenerateByCore(UI.MouseCell(), Find.CurrentMap, "0", true);
						}));	
						d3.Value.extraDataByDirection.ToList().ForEach(d2 =>
					{
						options2.Add(new DebugMenuOption(d3.Key.ToString() + d2.Key.ToStringHuman(), DebugMenuOptionMode.Tool, () =>
						{
							d2.Value.GenerateByCore(UI.MouseCell(), Find.CurrentMap, "0", true);
						}));
					});
					});
					Find.WindowStack.Add(new Dialog_DebugOptionListLister(options2));

				}));
			});
			Find.WindowStack.Add(new Dialog_DebugOptionListLister(options));
		}

		public static bool clearGenerationData = true;
	}
}
