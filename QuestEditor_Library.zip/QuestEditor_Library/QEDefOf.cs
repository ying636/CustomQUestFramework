﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;
using Verse.AI;

namespace QuestEditor_Library
{
    [DefOf]
    class QEDefOf
    {
        static QEDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(JobDef));
        }

        public static DesignationDef QE_Disgenerate;
        public static DesignationDef QE_MoveIn;
        public static DesignationDef QE_MoveOut;

        public static SitePartDef QE_CustomSite;
        public static ThingDef QE_Spawner_Editor;

        public static JobDef QE_EnterOrExitSubMap;
        public static JobDef QE_StartDialog;
        public static JobDef QE_Patrol;
        public static JobDef QE_Open;
        public static JobDef QE_InteractingWithTarget;
        public static JobDef QE_MoveInTargetToSubMap;
        public static JobDef QE_MoveTargetOutOfSubMap;

        public static DutyDef QE_Duty_Guard;
        public static DutyDef QE_Duty_Waiter;
        public static WorldObjectDef QE_CustomMap_SubMap; 
        public static WorldObjectDef CQF_CustomSite;
        public static GenStepDef QE_CustomSite_GenStep;
    }
}
