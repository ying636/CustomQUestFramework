﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using RimWorld;
using Verse;

namespace QuestEditor_Library
{
    public class CustomThingData_CustomTrap : CustomThingData
    {
        public CustomThingData_CustomTrap() { }
        public CustomThingData_CustomTrap(CustomTrap thing, IntVec3 pos) : base(thing, pos) 
        {
            this.mode = thing.mode;
            this.inSignal = thing.inSignal;
            this.trapName = thing.trapName;
            this.actions = thing.actions;
            this.signalIsOnlyValidInPart = thing.signalIsOnlyValidInPart;
        }
        public override XElement SaveToXElement(string nodeName) 
        {
            XElement result = base.SaveToXElement(nodeName);
            XElement actions = new XElement("actions");
            this.actions.ForEach((x) => actions.Add(x.SaveToXElement("li")));
            result.Add(actions); 
            result.Add(new XElement("mode",this.mode));
            result.Add(new XElement("trapName", this.trapName));
            if(this.mode == ActionTriggerMode.Signal)
            {
                result.Add(new XElement("inSignal", this.inSignal));
                result.Add(new XElement("signalIsOnlyValidInPart", this.signalIsOnlyValidInPart));
            }
            return result;
        }

        public override Thing SpawnThing(Map map, string questId, GenStepParams parms, IntVec3? centre = null, bool load = false, CustomMapDataDef def = null, Func<ThingDef, ThingDef> getStuff = null)
        {
            CustomTrap customTrap = (CustomTrap)base.SpawnThing(map, questId, parms, centre, load, def, getStuff);
            if (customTrap == null)
            {
                return null;
            }
            customTrap.mode = this.mode;
            List<string> signalParts = new List<string>()
                        {
                         "Quest",
                         questId,
                              ".",
                         this.inSignal
                        };
            if (this.signalIsOnlyValidInPart)
            {
                signalParts.Add(def.defName + GenStep_CustomMap.generatedCount[def].ToString());
            }
            customTrap.inSignal = string.Concat(signalParts);
            this.actions.ForEach(a => customTrap.actions.Add(a.Copy()));
            customTrap.actions.ForEach(a =>
            {
                if (a is CQFAction_SentSignal signal)
                {
                    List<string> signalParts2 = new List<string>()
                    {
                        "Quest",
                        questId,
                             ".",
                        signal.signal
                    };
                    if (signal.signalIsOnlyValidInPart)
                    {
                        if (GenStep_CustomMap.generatedCount.ContainsKey(def))
                        {
                            signalParts2.Add(def.defName + GenStep_CustomMap.generatedCount[def].ToString());
                        }
                    }
                    signal.signal = string.Concat(signalParts2);
                }
            });
            return customTrap;
        }

        public string trapName = "undefined";
        public string inSignal = null;
        public bool signalIsOnlyValidInPart = false;
        public ActionTriggerMode mode = ActionTriggerMode.None;
        public List<CQFAction> actions = new List<CQFAction>();
    }
}
