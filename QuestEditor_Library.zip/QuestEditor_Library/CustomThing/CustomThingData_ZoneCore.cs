﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using RimWorld;
using Verse;

namespace QuestEditor_Library
{
    public class CustomThingData_ZoneCore : CustomThingData
    {
        public CustomThingData_ZoneCore() { }
        public CustomThingData_ZoneCore(ZoneCore thing, IntVec3 pos) : base(thing, pos) 
        {
            this.coreRotation = thing.coreRotation;
            this.conditions = thing.conditions;
            this.isCenter = thing.isCenter;
            this.reserveThing = thing.reserveThing;
            this.coreTags = thing.coreTags;
        }
        public override XElement SaveToXElement(string nodeName) 
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("coreRotation", this.coreRotation));
            result.Add(new XElement("isCenter", this.isCenter));
            if (this.reserveThing != null) 
            {
                result.Add(this.reserveThing.SaveToXElement("reserveThing"));
            }
            if (this.conditions != null && this.conditions.Any())
            {
                result.Add(EditorTools.SaveList_Saveable(this.conditions, "conditions"));
            }
            if (this.coreTags != null && this.coreTags.Any())
            {
                result.Add(EditorTools.SaveList(this.coreTags, "coreTags"));
            }
            return result;
        }

        public override Thing SpawnThing(Map map, string questId, GenStepParams parms, IntVec3? centre = null, bool load = false, CustomMapDataDef def = null, Func<ThingDef, ThingDef> getStuff = null)
        {
            ZoneCore core = (ZoneCore)base.SpawnThing(map, questId, parms, centre, load,def,getStuff);
            core.coreRotation = this.coreRotation;
            core.conditions = this.conditions;
            core.isCenter = this.isCenter;
            core.reserveThing = this.reserveThing;
            core.coreTags = this.coreTags;
            if (!load && !EditorTools.disgenerateByCore)
            {
                core.GenerateZone(getStuff, questId);
            }            
            return null;
        }
        public override string ToString()
        {
            return $"方向：{this.coreRotation.ToStringHuman()},位置：{this.position}";
        }

        public bool isCenter = false;
        public Rot4 coreRotation = Rot4.Invalid;
        public ThingData reserveThing = null;
        public List<ZoneCondition> conditions = new List<ZoneCondition>();
        public List<string> coreTags = new List<string>();
    }
}
