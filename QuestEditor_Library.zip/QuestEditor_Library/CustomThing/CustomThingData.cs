﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using RimWorld;
using Verse;

namespace QuestEditor_Library
{
    public class CustomThingData : ISaveable
    {
        public CustomThingData() { }
        public CustomThingData(Thing thing,IntVec3 pos) 
        {
            this.def = thing.def;
            this.stuff = thing.Stuff;
            this.style = thing.StyleDef;
            this.position = pos;
            this.count = thing.stackCount;
            this.rotation = thing.Rotation;
            if (thing.def.CanHaveFaction)
            {
                this.faction = thing.Faction?.def;
            }
            if (thing.TryGetComp<CompPowerBattery>() is CompPowerBattery compB)
            {
                this.storedEnergy = compB.StoredEnergy;
            }
            if (thing.TryGetComp<CompActionWorker>() is CompActionWorker comp && comp.comps != null) 
            {
                this.comps = comp.comps;
            }
            if (thing.TryGetComp<CompCustomText>() is CompCustomText compText)
            {
                if (compText.useCustomName)
                {
                     this.customName = compText.customName.Translate();
                }
                if (compText.useCustomDescription)
                {
                    this.customDescription = compText.customDescription;
                }
            }
        }
        public virtual CustomThingData Copy()
        {
            XElement x = this.SaveToXElement("CustomThingData");
            XmlNode node = new XmlDocument().ReadNode(x.CreateReader()) as XmlNode;
            CustomThingData result = DirectXmlToObject.ObjectFromXml<CustomThingData>(node, false);
            DirectXmlCrossRefLoader.ResolveAllWantedCrossReferences(FailMode.LogErrors);
            return result;
        }
        public virtual Thing SpawnThing(Map map, string questId, GenStepParams parms, IntVec3? centre = null, bool load = false, CustomMapDataDef def = null, Func<ThingDef, ThingDef> getStuff = null)
        {
            IntVec3 pos = this.position + centre ?? map.Center;
            if (!pos.InBounds(map))
            {
                Log.Error("Spawn CustomThing Error:" + this.ToString());
                return null;
            }
            Thing result = GenSpawn.Spawn(ThingMaker.MakeThing(this.def,getStuff == null ? this.stuff : getStuff(this.stuff)), pos, map, this.rotation);
            result.StyleDef = this.style;
            if (this.faction != null) 
            {
                result.SetFaction(Find.FactionManager.FirstFactionOfDef(this.faction));
            }
            if (result.TryGetComp<CompPowerBattery>() is CompPowerBattery compB)
            {
                compB.SetStoredEnergyPct(0f);
                compB.AddEnergy(this.storedEnergy);
            }
            if (result.TryGetComp<CompActionWorker>() is CompActionWorker comp)
            {
                this.comps.ForEach(c => comp.comps.Add(c.Copy()));
                comp.comps.ForEach(c =>
                {
                    if (c.mode == ActionTriggerMode.Signal)
                    {
                        List<string> signalParts = new List<string>()
                        {
                         "Quest",
                         questId,
                         ".",
                         c.signal
                        };
                        if (c.signalIsOnlyValidInPart)
                        {
                            if (GenStep_CustomMap.generatedCount.ContainsKey(def)) 
                            {
                                signalParts.Add(def.defName + GenStep_CustomMap.generatedCount.TryGetValue(def).ToString());
                            }
                        }
                        c.signal = string.Concat(signalParts);
                    }
                    c.actions.ForEach(a => 
                    {
                        if (a is CQFAction_SentSignal signal) 
                        {
                            List<string> signalParts = new List<string>()
                        {
                         "Quest",
                         questId,
                              ".",
                         signal.signal
                        };
                            if (c.signalIsOnlyValidInPart)
                            {
                                signalParts.Add(def.defName + GenStep_CustomMap.generatedCount[def].ToString());
                            }
                            signal.signal = string.Concat(signalParts);
                        }
                    });
                    if (result.TryGetComp<CompCustomText>() is CompCustomText compText)
                    {
                        if (this.customName != null)
                        {
                            compText.useCustomName = true;

                            compText.customName = load ? this.customName : this.customName.Translate().ToString();
                        }
                        if (this.customDescription != null)
                        {
                            compText.useCustomDescription = true;

                            compText.customDescription = load ? this.customDescription : this.customDescription.Translate().ToString();

                        }
                    }
                    if (questId != null)
                    {
                        List<string> signalParts = new List<string>()
                        {
                "Quest",
               questId,
                ""
                        };
                        result.questTags = new List<string>() { string.Concat(signalParts) };
                        if (GenStep_CustomMap.generatedCount.ContainsKey(def))
                        {
                            result.questTags.Add(def.defName + GenStep_CustomMap.generatedCount[def].ToString());
                        }
                    };
                });
                comp.comps?.ForEach(s =>
                {
                    if (s.mode == ActionTriggerMode.MapGeneration)
                    {
                        s.actions.ForEach(a => a.Work(comp.GetTargetThis()));
                    }
                });
            }   
            return result;
        }
        public virtual XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            result.SetAttributeValue("Class", this.GetType().FullName);
            result.Add(new XElement("def", this.def.defName));
            if (this.rotation != Rot4.North)
            {
                result.Add(new XElement("rotation", this.rotation));
            }
            if (this.count != 1)
            {
                result.Add(new XElement("count", this.count));
            }
            if (this.storedEnergy != 0)
            {
                result.Add(new XElement("storedEnergy", this.storedEnergy));
            }
            if (this.stuff != null)
            {
                result.Add(new XElement("stuff", this.stuff.defName));
            }
            if (this.faction != null)
            {
                result.Add(new XElement("faction", this.faction.defName));
            }
            if (this.style != null)
            {
                result.Add(new XElement("style", this.style.defName));
            }
            if (this.customName != null)
            {
                result.Add(new XElement("v", this.customName));
            }
            if (this.customDescription != null)
            {
                result.Add(new XElement("customDescription", this.customDescription));
            }
            XElement pos = new XElement("position",$"({this.position.x},{this.position.y},{this.position.z})");
            if (!this.comps.NullOrEmpty()) 
            {
                XElement comps = new XElement("comps");
                this.comps.ForEach(c => comps.Add(c.SaveToXElement("li")));
                result.Add(comps);
            }
            result.Add(pos);
            return result;
        }

        public ThingDef def;
        public ThingStyleDef style = null;
        public ThingDef stuff = null;
        public FactionDef faction = null;
        public IntVec3 position;
        public Rot4 rotation = Rot4.North;
        public int count = 1;
        public float storedEnergy = 0;

        public string customName = null;
        public string customDescription = null;
        public List<ActionComp> comps = new List<ActionComp>();
    }
}
