﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI.Group;
using Verse.AI;
using System.Xml.Linq;

namespace QuestEditor_Library
{
    public class LootBox : Building , IDrawTabable, IPastableData, ICopiableData
    {
        public override string Label => this.TextComp == null || !this.textComp.useCustomName ? base.Label : this.textComp.customName;
        public override string DescriptionFlavor => this.TextComp == null || !this.textComp.useCustomDescription ? base.DescriptionFlavor : this.textComp.customDescription;
        public CompCustomText TextComp
        {
            get
            {
                if (this.textComp == null)
                {
                    this.textComp = this.TryGetComp<CompCustomText>();
                }
                return this.textComp;
            }
        }
        public override Graphic Graphic 
        {
            get 
            {
                if (!this.opened) 
                {
                    return base.Graphic;
                }
                if (this.openedGraphic == null) 
                {
                    Graphic baseGraphic = base.Graphic;
                    if (this.def.GetModExtension<ModExtension_CustomThing>() is ModExtension_CustomThing me && me.openedGraphicdata !=null) 
                    {
                        this.openedGraphic = me.openedGraphicdata.Graphic; 
                        return this.openedGraphic;
                    }
                    this.openedGraphic = GraphicDatabase.Get(this.def.graphicData.graphicClass,this.def.graphicData.texPath + "_opened", baseGraphic.Shader, baseGraphic.drawSize, baseGraphic.color, baseGraphic.colorTwo, baseGraphic.maskPath == null ? null : baseGraphic.maskPath + "_opened");
                }
                return this.openedGraphic;
            }
        }

        public override string GetInspectString()
        {
            if (!Prefs.DevMode) 
            {
                return base.GetInspectString();
            }
            string result = base.GetInspectString() + "LootDatas".Translate();
            this.loots.ForEach(x => result += " " + x.dataName);
            return result.Trim();
        }
        public void DrawTab() 
        {
            Widgets.BeginScrollView(new Rect(7f, 25f, 475f, 590f), ref this.scrollPos, new Rect(7f, 10f, 475f, this.height));
            float y = 10f;
            EditorTools.DrawLabelAndText_Line(y,"LootBoxName".Translate(),ref this.lootBoxName,16f,250f);
            Rect rectCP = new Rect(380f,y,25f,25f);
            if (Widgets.ButtonImage(rectCP, TexButton.Copy))
            {
                this.CopyData();
            }
            TooltipHandler.TipRegion(rectCP, "Copy".Translate());
            rectCP.x += 30f;
            if (Widgets.ButtonImage(rectCP, TexButton.Paste))
            {
                PasteData();
            }
            TooltipHandler.TipRegion(rectCP, "Paste".Translate());
            y += 30f;
            Rect rect = new Rect(10f, y, 25f, 25f);
            if (this.useLootDef)
            {
                if (Widgets.ButtonText(new Rect(16f,y,400f,25f), "LootDef".Translate(this.lootDef?.defName),false))
                {
                    EditorTools.DrawFloatMenu(DefDatabase<LootDataDef>.AllDefsListForReading,d => this.lootDef = d,d => d.defName);
                }
                y += 30f;
            }
            else
            {
                if (Widgets.ButtonImage(rect, ContentFinder<Texture2D>.Get("UI/Icon_MoveOut", true)))
                {
                    LongEventHandler.QueueLongEvent(() =>
                    {
                        LootDataDef def = new LootDataDef();
                        def.defName = this.lootBoxName;
                        def.loots = this.loots;
                        DefDatabase<LootDataDef>.Add(def);
                        string path = Page_QuestEditor.Path + @"\Data\" + this.lootBoxName + ".xml";
                        XElement defs = new XElement("Defs");
                        XElement defXml = new XElement("QuestEditor_Library.LootDataDef");
                        XElement lootsXml = new XElement("loots");
                        this.loots.ForEach(l => lootsXml.Add(l.SaveToXElement("li")));
                        defXml.Add(new XElement("defName",this.lootBoxName)); 
                        defXml.Add(lootsXml);
                        defs.Add(defXml);
                        defs.Save(path);
                        Messages.Message("SaveSucceed".Translate(path), MessageTypeDefOf.PositiveEvent);
                    },"SavingAsDef".Translate(),true,e => Log.Message(e.Message));
                }
                TooltipHandler.TipRegion(rect, "SaveAsDef".Translate());
                y += 30f;
                float initY = y;
                Rect rectData = new Rect(17f,y + 3f,600f,25f);
                foreach (LootData data in this.loots)
                {
                    if (Widgets.ButtonText(rectData,data.dataName + "  " + data.chance * 100f + "%",false)) 
                    {
                        Find.WindowStack.Add(new Dialog_EditIDrawable(data));
                    }
                    y += 30f;
                    rectData.y += 30f;
                }
                Widgets.DrawBox(new Rect(10f,initY,400f,y - initY),1,QuestEditor_Dialog.blueTex);
                y += 10f;
                if (Widgets.ButtonText(new Rect(10f, y, 100f, 38f), "AddNewLootData".Translate()))
                {
                    this.loots.Add(new LootData());
                }
                if (Widgets.ButtonText(new Rect(150f, y, 100f, 38f), "Paste".Translate()) && EditorTools.lootData != null)
                {
                    this.loots.Add(EditorTools.lootData.Copy());
                }
                if (Widgets.ButtonText(new Rect(300f, y, 100f, 38f), "DeleteLootData".Translate()) && this.loots.Any())
                {
                    EditorTools.DrawFloatMenu(this.loots, (x) => this.loots.Remove(x), (x) => x.dataName);
                }
                y += 45f;
            }
            EditorTools.DrawLabelAndText_Line(y, "JobReport".Translate(), ref this.openReport, 16f,180f);
            y += 30f;
            EditorTools.DrawLabelAndText_Line(y, "TickToOpenLoot".Translate(), ref this.tickToOpen, ref this.buffer, 16f,180f);
            y += 30f;
            Widgets.CheckboxLabeled(new Rect(16f,y,350f,25f),"DestroyAfterOpening".Translate(), ref this.destroyAfterOpening);
            y += 30f;
            Widgets.CheckboxLabeled(new Rect(16f, y, 350f, 25f), "UseLootDef".Translate(), ref this.useLootDef);
            y += 30f;
            this.height = y + 15f;
            Widgets.EndScrollView();
        }

        public void PasteData()
        {
            this.lootBoxName = EditorTools.lootBoxName;
            this.tickToOpen = EditorTools.tickToOpen;
            this.destroyAfterOpening = EditorTools.destroyAfterOpening;
            this.openReport = EditorTools.openReport;
            this.loots = EditorTools.loots.ListFullCopy();
            this.buffer = EditorTools.buffer;
            this.useLootDef = EditorTools.useLootDef;
            this.lootDef = EditorTools.lootDef;
        }

        public void CopyData()
        {
            EditorTools.lootBoxName = this.lootBoxName;
            EditorTools.tickToOpen = this.tickToOpen;
            EditorTools.destroyAfterOpening = this.destroyAfterOpening;
            EditorTools.openReport = this.openReport;
            EditorTools.buffer = this.buffer;
            EditorTools.loots = this.loots.ListFullCopy();
            EditorTools.useLootDef = this.useLootDef;
            EditorTools.lootDef = this.lootDef;
        }

        public virtual void Open() 
        {
            if (!this.opened) 
            {
                List<LootData> datas = new List<LootData>();
                datas.AddRange(this.loots);
                if (this.lootDef != null) 
                {
                    datas.AddRange(this.lootDef.loots);
                }
                LootData data = GenCollection.RandomElementByWeight(datas, (x) => x.chance);
                data.SpawnLoots(this.Map, this.Position, this.GetLord(),this);
                this.opened = true;
                if (this.destroyAfterOpening) 
                {
                    this.Destroy();
                }
                QuestUtility.SendQuestTargetSignals(this.questTags, "Opened", this.Named("SUBJECT"));
            }
        }
        public override IEnumerable<FloatMenuOption> GetFloatMenuOptions(Pawn selPawn)
        {
            foreach (FloatMenuOption option in base.GetFloatMenuOptions(selPawn))
            {
                yield return option;
            }
            if (!this.opened)
            {
                if (selPawn.CanReserveAndReach(this, PathEndMode.Touch, Danger.Deadly))
                {
                    Job job = JobMaker.MakeJob(QEDefOf.QE_Open, this);
                    job.reportStringOverride = this.openReport.Translate();
                    yield return new FloatMenuOption(this.openReport.Translate(), () => selPawn.jobs.StartJob(job));
                }
                else
                {
                    yield return new FloatMenuOption("CantReseverveOrReachLootBox".Translate(), null);
                } 
            }
            yield break;
        }
        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref this.loots, "QE_LootBox_loots",LookMode.Deep);
            Scribe_Defs.Look(ref this.lootDef, "QE_LootBox_lootDef");
            Scribe_Values.Look(ref this.lootBoxName, "QE_LootBox_lootBoxName");
            Scribe_Values.Look(ref this.openReport, "QE_LootBox_openReport");
            Scribe_Values.Look(ref this.opened, "QE_LootBox_opened");
            Scribe_Values.Look(ref this.destroyAfterOpening, "QE_LootBox_destroyAfterOpening");
            Scribe_Values.Look(ref this.tickToOpen, "QE_LootBox_tickToOpen");
            Scribe_Values.Look(ref this.buffer, "QE_LootBox_buffer");
            Scribe_Values.Look(ref this.useLootDef, "QE_LootBox_useLootDef");
        }

        public string lootBoxName = "Undefined";
        public float height = 0f; 
        public int tickToOpen = 100;
        public bool opened = false;
        public bool destroyAfterOpening = false;
        public bool useLootDef = false;
        public string openReport = "CQF_Open";
        public string buffer;
        public Vector2 scrollPos;
        public Graphic openedGraphic = null;
        public List<LootData> loots = new List<LootData>();
        public LootDataDef lootDef;
        private CompCustomText textComp = null;
    }
    public class LootData : IExposable ,ISaveable,IDrawable
    {
        public LootData() 
        {
            this.dataName = "Unnamed";
        }
        public LootData Copy() 
        {
            LootData result = new LootData();
            result.dataName = this.dataName;
            result.chance = this.chance;
            result.message = this.message;
            result.pawnDatas = this.pawnDatas.ListFullCopy();
            result.things = this.things.ListFullCopy();
            result.categorys = this.categorys.ListFullCopy();
            return result;
        }
        public void Draw(ref float y, Rect inRect, float x)
        {
            Text.Font = GameFont.Medium;
            Widgets.Label(new Rect(10f, y + 7f, 1020f, 45f), this.dataName.Colorize(ColorLibrary.SkyBlue));
            Text.Font = GameFont.Small;
            y += 50f;      
            Rect rect = new Rect(340f + x, y, 30f, 30f);
            if (Widgets.ButtonImage(rect, TexButton.Copy))
            {
                EditorTools.lootData = this.Copy();
            }
            TooltipHandler.TipRegion(rect, "Copy".Translate());
            if (Widgets.ButtonText(new Rect(x, y, 150f, 25f), "Rename".Translate()))
            {
                Find.WindowStack.Add(new Dialog_RenameForQE((name) => this.dataName = name));
            }
            y += 30f;
            EditorTools.DrawFieldAndText(ref y,"MessageAfterOpening".Translate(),ref this.message,x,400f);
            y += 35f;
            Widgets.Label(new Rect(x,y, 150f, 25f), "LootThings".Translate());
            y += 30f;
            float initY = y;
            foreach (CQFThingDefCount thing in this.things)
            {
                y += 5f;
                thing.Draw(ref y,inRect,x - 3f); 
                y += 5f;
            }
            Widgets.DrawBox(new Rect(x, initY,inRect.width - 40f - (2*x),y - initY),1,QuestEditor_Dialog.blueTex);
            y += 20f;
            EditorTools.DrawButtonForList<CQFThingDefCount>(ref y,this.things,t => t.thing.label + "x" + t.count,() => Find.WindowStack.Add(new Dialog_Select<ThingDef>(DefDatabase<ThingDef>.AllDefsListForReading.FindAll((t2) => t2.category == ThingCategory.Item && !t2.IsCorpse),
                d => d.uiIcon, d => d.label, "SelectLootThing".Translate(), d => this.things.Add(new CQFThingDefCount { thing = d }))),x);
            y += 5f;
            Widgets.Label(new Rect(x, y, 150f, 25f), "LootCategorys".Translate());
            y += 30f;
            initY = y;
            foreach (CQFThingCategoryCount cetegory in this.categorys)
            {
                y += 5f;
                cetegory.Draw(ref y, inRect, x - 3f);
                y += 5f;
            }
            Widgets.DrawBox(new Rect(x, initY, inRect.width - 40f - (2 * x), y - initY), 1, QuestEditor_Dialog.blueTex); 
            y += 20f;
            EditorTools.DrawButtonForList<CQFThingCategoryCount>(ref y, this.categorys, t2 => t2.category.label + "x" + t2.count,
            () => EditorTools.DrawFloatMenu<ThingCategoryDef>(DefDatabase<ThingCategoryDef>.AllDefsListForReading.FindAll((t2) => t2.defName != "Corpses" && 
            !t2.Parents.Contains(ThingCategoryDefOf.Corpses) && t2 != ThingCategoryDefOf.Animals), t2 => this.categorys.Add(new CQFThingCategoryCount() {category = t2}),t2 => t2.label),x);
            y += 5f;          
            Widgets.Label(new Rect(x, y, 150f, 25f), "LootPawn".Translate());
            y += 30f;
            initY = y;
            foreach (PawnSpawnData pawnData in this.pawnDatas)
            {
                Rect rectData = new Rect(17f, y + 3f, 600f, 25f);
                if (Widgets.ButtonText(rectData, pawnData.dataName, false))
                {
                    Find.WindowStack.Add(new Dialog_EditIDrawable(pawnData));
                }
                y += 30f;
            }
            Widgets.DrawBox(new Rect(x, initY, inRect.width - 40f - (2 * x), y - initY), 1, QuestEditor_Dialog.blueTex);
            y += 20f;
            EditorTools.DrawButtonForPawnData(y, this.pawnDatas,x);
            y += 45f;
            EditorTools.DrawLabelAndText_Line(y, "LootChance".Translate(), ref this.chance, ref this.buffer, 16f + x);
            y += 30f;
        }
        public List<Thing> SpawnLoots(Map map,IntVec3 pos,Lord lord,Thing box) 
        {
            List<Thing> result = new List<Thing>();
            string text = null;
            if (this.pawnDatas != null)
            {
                foreach (PawnSpawnData data in this.pawnDatas)
                {
                    data.Spawn(pos, map, lord,box.questTags != null && box.questTags.Any() ? box.questTags.First() : "Null");
                }
            }
            foreach (CQFThingDefCount thingCount in this.things)
            {
                Thing thing = ThingMaker.MakeThing(thingCount.thing, thingCount.thing.MadeFromStuff ? (thingCount.stuff ?? GenStuff.RandomStuffFor(thingCount.thing)) : null);
                thing.stackCount = thingCount.count.RandomInRange;
                GenPlace.TryPlaceThing(thing, pos, map, ThingPlaceMode.Near);
                result.Add(thing);
                if (text == null)
                {
                    text = thing.Label;
                }
                else
                {
                    text += "," + thing.Label;
                }
            }
            foreach (CQFThingCategoryCount categorys in this.categorys)
            {
                ThingDef def = categorys.category.DescendantThingDefs.RandomElement();
                Thing thing = ThingMaker.MakeThing(def, def.MadeFromStuff ? (categorys.stuff ?? GenStuff.RandomStuffFor(def)) : null);
                thing.stackCount = categorys.count.RandomInRange;
                GenPlace.TryPlaceThing(thing, pos, map, ThingPlaceMode.Near);
                result.Add(thing);
                if (text == null)
                {
                    text = thing.Label;
                }
                else
                {
                    text += "," + thing.Label;
                }
            }
            QuestUtility.SendQuestTargetSignals(box.questTags,this.dataName, box.Named("SUBJECT"));
            Messages.Message(this.message.Translate(text),new LookTargets(pos,map),MessageTypeDefOf.NeutralEvent);
            return result;
        }
        public XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            result.Add(new XElement("dataName", this.dataName));
            result.Add(new XElement("chance", this.chance));
            if (this.message != null && this.message != "") 
            {
                result.Add(new XElement("message", this.message));
            }
            if (this.pawnDatas.Any())
            {
                XElement pawnData = new XElement("pawnDatas");
                this.pawnDatas.ForEach((x) => pawnData.Add(x.SaveToXElement("li")));
                result.Add(pawnData);
            }
            if (this.things.Any())
            {
                XElement thingData = new XElement("things");
                this.things.ForEach((x) => thingData.Add(x.SaveToXElement("li")));
                result.Add(thingData);
            }
            if (this.categorys.Any())
            {
                XElement categoryData = new XElement("categorys");
                this.categorys.ForEach((x) => categoryData.Add(x.SaveToXElement("li")));
                result.Add(categoryData);
            }
            return result;
        }
        public void ExposeData()
        {
            Scribe_Values.Look(ref this.dataName, "QE_LootData_dataName");
            Scribe_Values.Look(ref this.chance, "QE_LootData_chance");
            Scribe_Values.Look(ref this.buffer, "QE_LootData_buffer");
            Scribe_Values.Look(ref this.message, "QE_LootData_message");
            Scribe_Collections.Look(ref this.things, "QE_LootData_things",LookMode.Deep);
            Scribe_Collections.Look(ref this.categorys, "QE_LootData_categorys", LookMode.Deep);
            Scribe_Collections.Look(ref this.pawnDatas, "QE_LootData_pawnDatas", LookMode.Deep);
        }

        public string dataName;
        public float chance = 1f;
        public string buffer;
        public string message = null;
        public List<PawnSpawnData> pawnDatas = new List<PawnSpawnData>();
        public List<CQFThingDefCount> things = new List<CQFThingDefCount>();
        public List<CQFThingCategoryCount> categorys = new List<CQFThingCategoryCount>();
    }

    public abstract class LootThingData : IExposable , ISaveable,IDrawable
    {
        public static void OpenSelectWindow(Type type, Action<LootThingData> action)
        {
            if (type == typeof(CQFThingDefCount)) 
            {
                Find.WindowStack.Add(new Dialog_Select<ThingDef>(DefDatabase<ThingDef>.AllDefsListForReading.FindAll((t2) => t2.category == ThingCategory.Item && !t2.IsCorpse),
                d => d.uiIcon, d => d.label, "SelectLootThing".Translate(), d => action(new CQFThingDefCount { thing = d }), null, (t, r) => Widgets.DefIcon(r, t, null)));
            }
            if (type == typeof(CQFThingCategoryCount))
            {
                Find.WindowStack.Add(new Dialog_Select<ThingCategoryDef>(DefDatabase<ThingCategoryDef>.AllDefsListForReading.FindAll((t2) => t2.defName != "Corpses" && !t2.Parents.Contains(ThingCategoryDefOf.Corpses) && t2 != ThingCategoryDefOf.Animals),
null,d => d.label, "Select".Translate(), d => action(new CQFThingCategoryCount { category = d }), null, (t, r) => Widgets.DefIcon(r, t, null)));
            }
        }
        public abstract ThingRequest GetRequest();
        public void Draw(ref float y, Rect inRect, float x)
        {
            this.DrawIcon(ref y);
            Widgets.Label(new Rect(60f +x, y + 5f, 35f, 35f), "x");
            int min = this.count.min;
            int max = this.count.max;
            Widgets.TextFieldNumeric<int>(new Rect(75f +x, y, 35f, 35f), ref min, ref this.bufferMin);
            Widgets.Label(new Rect(113f +x, y + 5f, 35f, 35f), "~");
            Widgets.TextFieldNumeric<int>(new Rect(125f + x, y, 35f, 35f), ref max, ref this.bufferMax);
            this.count = new IntRange(min, max);
            y += 45f;
            if (this.stuff != null)
            {
                string text = "LootThingStuff".Translate();
                Widgets.Label(new Rect(20f + x, y, 50f, 35f), text);
                Widgets.DefIcon(new Rect(Text.CalcSize(text).x + x + 25f, y, 35f, 35f),this.stuff);
                y += 40f;
            }
            Rect rect = new Rect(20f + x, y, 150f, 25f);
            if (Widgets.ButtonText(rect, "SelectStuff".Translate())) 
            {
                EditorTools.DrawFloatMenu<ThingDef>(DefDatabase<ThingDef>.AllDefsListForReading.FindAll((t) => t.IsStuff), (t) => this.stuff= t, (t) => t.label,new List<FloatMenuOption>()
                {new FloatMenuOption("Null".Translate(),() => this.stuff = null)});
            }
            TooltipHandler.TipRegion(rect,"CQFStuffTip".Translate());
            y += 30f;
        }
        public void DrawWithSingleCount(ref float y, Rect inRect, float x)
        {
            this.DrawIcon(ref y);
            Widgets.Label(new Rect(60f + x, y + 5f, 35f, 35f), "x");
            int min = this.count.min;
            Widgets.TextFieldNumeric<int>(new Rect(75f + x, y, 35f, 35f), ref min, ref this.bufferMin);
            this.count = new IntRange(min, min);
            y += 45f;
            if (this.stuff != null)
            {
                string text = "LootThingStuff".Translate();
                Widgets.Label(new Rect(20f + x, y, 50f, 35f), text);
                Widgets.DefIcon(new Rect(Text.CalcSize(text).x + x + 25f, y, 35f, 35f), this.stuff);
                y += 40f;
            }
            Rect rect = new Rect(20f + x, y, 150f, 25f);
            if (Widgets.ButtonText(rect, "SelectStuff".Translate()))
            {
                EditorTools.DrawFloatMenu<ThingDef>(DefDatabase<ThingDef>.AllDefsListForReading.FindAll((t) => t.IsStuff), (t) => this.stuff = t, (t) => t.label, new List<FloatMenuOption>()
                {new FloatMenuOption("Null".Translate(),() => this.stuff = null)});
            }
            TooltipHandler.TipRegion(rect, "CQFStuffTip".Translate());
            y += 30f;
        }
        public abstract void DrawIcon(ref float y);
        public virtual XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            result.SetAttributeValue("Class", this.GetType().FullName);
            if (this.stuff != null)
            {
                result.Add(new XElement("stuff", this.stuff.defName));
            }
            result.Add(new XElement("count", this.count.ToString()));
            return result;
        }
        public virtual void ExposeData()
        {
            Scribe_Values.Look(ref this.count, "QE_ThingDefCountRangeWithBuffer_count");   
            Scribe_Defs.Look(ref this.stuff, "QE_ThingDefCountRangeWithBuffer_stuff");
            Scribe_Values.Look(ref this.bufferMin, "QE_ThingDefCountRangeWithBuffer_bufferMin");
            Scribe_Values.Look(ref this.bufferMax, "QE_ThingDefCountRangeWithBuffer_bufferMax");
        }

        public string bufferMin;
        public string bufferMax;       
        public ThingDef stuff = null;   
        public IntRange count = new IntRange(1,1);
    }
    public class CQFThingDefCount : LootThingData
    {
        public override ThingRequest GetRequest()
        {
            return ThingRequest.ForDef(this.thing);
        }
        public override void DrawIcon(ref float y)
        {
            Rect rect = new Rect(20f, y, 35f, 35f);
            Widgets.DefIcon(rect, this.thing, this.stuff);
            if (Mouse.IsOver(rect))
            {
                Vector3 mouse = Input.mousePosition;
                Widgets.DrawBox(new Rect(mouse.x, mouse.y, 70f, 40f));
                Widgets.Label(rect, this.thing.label);
            }
        }
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("thing", this.thing.defName));
            return result;
        }
        public override string ToString()
        {
            return this.stuff?.label + " " + this.thing?.label + this.count.ToString();
        }
        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Defs.Look(ref this.thing, "QE_ThingDefCountRangeWithBuffer_thing");
        }

        public ThingDef thing;
    }
    public class CQFThingCategoryCount : LootThingData , ISaveable
    {
        public override ThingRequest GetRequest()
        {
            return new ThingRequest();
        }
        public override void DrawIcon(ref float y)
        {
            Rect rect = new Rect(20f, y, 35f, 35f);
            Widgets.DrawTextureFitted(new Rect(20f, y, 35f, 35f), this.category.icon, 1f);      
            if (Mouse.IsOver(rect))
            {
                Vector3 mouse = Input.mousePosition;
                Widgets.DrawBox(new Rect(mouse.x, mouse.y, 70f, 40f));
                Widgets.Label(rect, this.category.label);
            }
        }

        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("category", this.category.defName));
            return result;
        }
        public override string ToString()
        {
            return this.stuff?.label + " " + this.category?.label + this.count.ToString();
        }
        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Defs.Look(ref this.category, "QE_ThingCategoryCount_category");
        }

        public ThingCategoryDef category;
    }
}
