﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using Verse;
using Verse.AI;

namespace QuestEditor_Library
{
    public class CustomMapExit : Building, IDrawTabable
    {
        public override string Label => this.TextComp == null || !this.textComp.useCustomName ? base.Label : this.textComp.customName;
        public override string DescriptionFlavor => this.TextComp == null || !this.textComp.useCustomDescription ? base.DescriptionFlavor : this.textComp.customDescription;
        public CompCustomText TextComp
        {
            get
            {
                if (this.textComp == null)
                {
                    this.textComp = this.TryGetComp<CompCustomText>();
                }
                return this.textComp;
            }
        }
        public virtual string GetExitText => "Exit".Translate();
        public virtual void Exit(Thing thing)
        {
            if (thing == null || this.entrance == null || this.entrance.Position == null || this.entrance.Map == null)
            {
                return;
            }
            if (thing.Spawned)
            {
                this.thereIsPawnIsEntering = true;
                thing.DeSpawn();
            }
            GenSpawn.Spawn(thing, this.entrance.Position, this.entrance.Map);
            this.thereIsPawnIsEntering = false;
        }
        public void DrawTab()
        {
            float y = 20f;
            Text.Font = GameFont.Medium;
            Widgets.Label(new Rect(15f, y, 900f, 38f), "CustomMapExit".Translate().Colorize(ColorLibrary.SkyBlue));
            Text.Font = GameFont.Small;
            y += 40f;
            EditorTools.DrawLabelAndText_Line(y, "ExitName".Translate(), ref this.exitName, 15f, 150f);
        }
        public override IEnumerable<FloatMenuOption> GetFloatMenuOptions(Pawn selPawn)
        {
            yield return new FloatMenuOption(this.GetExitText, delegate
            {
                Job job = JobMaker.MakeJob(QEDefOf.QE_EnterOrExitSubMap, this);
                job.reportStringOverride = "Exiting".Translate();
                selPawn.jobs.TryTakeOrderedJob(job);
            });
            yield break;
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref this.thereIsPawnIsEntering, "thereIsPawnIsEntering");
            Scribe_Values.Look(ref this.exitName, "CQF_CustomMapExit_exitName");
            Scribe_References.Look(ref this.entrance, "CQF_CustomMapExit_entrance");
        }

        [NoTranslate]
        public string exitName = "undefined";
        public CustomMapEntrance entrance;
        private CompCustomText textComp = null;

        public bool thereIsPawnIsEntering = false;
    }
}
