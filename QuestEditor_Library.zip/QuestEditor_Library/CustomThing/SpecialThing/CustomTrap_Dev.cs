﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using Verse;
using Verse.AI;

namespace QuestEditor_Library
{
    public class CustomTrap_Dev : CustomTrap
    {
        public override string Label => DebugSettings.godMode ? base.Label : "";
        public override void Draw()
        {
            if (DebugSettings.godMode)
            {
                base.Draw();
            } 
        }
    }
}
