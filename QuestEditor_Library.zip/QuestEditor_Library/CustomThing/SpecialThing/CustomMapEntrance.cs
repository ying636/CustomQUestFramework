﻿using RimWorld;
using RimWorld.Planet;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using UnityEngine;
using Verse;
using Verse.AI.Group;

namespace QuestEditor_Library
{
    public class CustomMapEntrance : Building, IDrawTabable
    {
        public override string Label => this.TextComp == null || !this.textComp.useCustomName ? base.Label : this.textComp.customName;
        public override string DescriptionFlavor => this.TextComp == null || !this.textComp.useCustomDescription ? base.DescriptionFlavor : this.textComp.customDescription;
        public CompCustomText TextComp 
        {
            get 
            {
                if (this.textComp == null) 
                {
                    this.textComp = this.TryGetComp<CompCustomText>();
                }
                return this.textComp;
            }
        }
        public string MapName 
        {
            get 
            {  
                if (this.CustomMap != null && this.CustomMap.Parent is MapParent_Custom custom)
                {
                  return custom.MapName;
                }
                else if (this.mapDef != null)
                {
                    return this.mapDef.label;
                }
                return "submap";
            }
        }
        public virtual string GetEnterText => "EnterNextMap".Translate(this.mapDef?.label);
        public virtual bool GenerateMapWhenSpawn => true;
        public virtual Map CustomMap
        {
            get
            {
                return this.customMap;
            }
        }
        public virtual CustomMapDataDef MapDef => this.mapDef;
        public virtual void SetMapDef(CustomMapDataDef mapDef) 
        {
            this.mapDef = mapDef;
        }
        public virtual void TryEnter(Thing thing)
        {
            if (this.CustomMap == null)
            {
                if (this.MapDef != null)
                {
                    this.GenerateCustomMap(this.Map,thing);
                    return;
                }
                else
                {
                    Messages.Message("EntranceIsBlocked".Translate(), MessageTypeDefOf.RejectInput);
                    return;
                }
            }
            Enter(thing);
        }

        private void Enter(Thing thing)
        {
            if (thing == null || this.exit == null || this.exit.Position == null || this.exit.Map == null)
            {
                return;
            }  
            this.thereIsPawnIsEntering = true;
            if (thing.Spawned)
            {
                thing.DeSpawn();
            }
            GenSpawn.Spawn(thing, this.exit.Position, this.exit.Map);
            this.thereIsPawnIsEntering = false;
            if (this.exit.Position.Fogged(this.exit.Map))
            {
                FloodFillerFog.FloodUnfog(this.exit.Position, this.exit.Map);
            }
        }

        public override string GetInspectString()
        {
            string result = base.GetInspectString();
            if (this.mapDef != null)
            {
                result +="EntranceToSubMap".Translate(this.mapDef.label);
            } else if (this.CustomMap != null && this.CustomMap.Parent is MapParent_Custom custom) 
            {
                result += "EntranceToSubMap".Translate(custom.MapName);
            }
            return result.Trim();
        }
        public virtual void DrawTab()
        {
            Widgets.BeginScrollView(new Rect(7f, 25f, 475f, 590f), ref this.scrollPos, new Rect(7f, 10f, 475f, this.height));
            Widgets.DrawBox(new Rect(8f, 10f, 470f, this.height), 1, QuestEditor_Dialog.blueTex);
            float y = 20f;
            Text.Font = GameFont.Medium;
            Widgets.Label(new Rect(15f, y, 900f, 38f), "CustomMap".Translate().Colorize(ColorLibrary.SkyBlue));
            Text.Font = GameFont.Small;
            y += 40f;
            Rect rect = new Rect(15f, y, 430f, 30f);
            if (Widgets.ButtonText(rect,"CurCustomMap".Translate(this.mapDef?.label),false))
            {
                List<CustomMapDataDef> list = new List<CustomMapDataDef>();
                list.AddRange(DefDatabase<CustomMapDataDef>.AllDefsListForReading.ToList());
                DirectoryInfo mapDir = new DirectoryInfo(Page_QuestEditor.Path + @"\Map\");
                foreach (FileInfo file in mapDir.GetFiles("*.xml"))
                {
                    XmlDocument xml = new XmlDocument();
                    xml.Load(file.FullName);
                    foreach (XmlNode xmlNode in xml.SelectNodes("//QuestEditor_Library.CustomMapDataDef"))
                    {
                        list.Add(DirectXmlToObject.ObjectFromXml<CustomMapDataDef>(xmlNode, false));
                    }
                }
                EditorTools.DrawFloatMenu<CustomMapDataDef>(list, (x) => this.mapDef = x, (x) => x.label);
            }
            y += 35f;
            EditorTools.DrawLabelAndText_Line(y,"ExitName".Translate(),ref this.exitName,15f,150f);
            y += 30f;
            this.height = y + 5f;
            Widgets.EndScrollView();
        }
        public override void Destroy(DestroyMode mode = DestroyMode.Vanish)
        {
            base.Destroy(mode);
            this.customMap?.Parent.Destroy();
        }

        public override IEnumerable<FloatMenuOption> GetFloatMenuOptions(Pawn selPawn)
        {
            if (this.mapDef == null && this.CustomMap == null)
            {
                yield return new FloatMenuOption("EntranceIsBlocked".Translate(), null);
            }
            else
            {
                yield return new FloatMenuOption(this.GetEnterText, delegate
                {
                selPawn.jobs.TryTakeOrderedJob(JobMaker.MakeJob(QEDefOf.QE_EnterOrExitSubMap, this));
                });
            }
            yield break;
        }
        public override IEnumerable<Gizmo> GetGizmos()
        {
            foreach (Gizmo g in base.GetGizmos())
            {
                yield return g;
            }
            if (Prefs.DevMode)
            {
                yield return new Command_Action()
                {
                    defaultLabel = "GenerateCustomMap".Translate(),
                    action = () =>
                    {
                        this.GenerateCustomMap(this.Map,null);
                    }
                };
            }
            yield break;
        }

        public virtual void GenerateCustomMap(Map map, Thing thing)
        {
            MapGenerator.PlayerStartSpot = this.Position;
            MapParent_Custom custom = (MapParent_Custom)WorldObjectMaker.MakeWorldObject(QEDefOf.QE_CustomMap_SubMap);
            custom.level = 1;
            if (map.Parent is MapParent_Custom parent)
            {
                custom.level += parent.level;
                custom.rootSite = parent.rootSite;
            }
            custom.Tile = map.Tile;
            custom.SetFaction(Find.FactionManager.OfPlayer);
            custom.entrance = this;
            custom.parentMap = map;
            if (map.Parent is CustomSite site) 
            {
                custom.rootSite = site;
            }
            if (custom.rootSite != null) 
            {
                custom.rootSite.allSubMaps.Add(custom);
            }
            map.GetComponent<MapComponent_CustomMapData>().AddSubMap(custom);
            Find.WorldObjects.Add(custom);      
            string seed = Find.World.info.seedString;
            Find.World.info.seedString = Find.TickManager.TicksGame.ToString();
            LongEventHandler.SetCurrentEventText("GenerateSubMap".Translate());
            DeepProfiler.Start("Generate map");
            LongEventHandler.QueueLongEvent(() =>
            {
                this.customMap = MapGenerator.GenerateMap(this.MapDef.size, custom, custom.MapGeneratorDef, this.GetSteps());
                QuestUtility.AddQuestTag(ref this.customMap.Parent.questTags, "Quest" + this.questID + "." + this.MapDef.defName);
                QuestUtility.AddQuestTag(ref this.customMap.Parent.questTags, "Quest" + this.questID + "." + custom.level);
                ((Pawn)thing).jobs.StopAll();
                ((Pawn)thing).jobs.StartJob(JobMaker.MakeJob(QEDefOf.QE_EnterOrExitSubMap,this));
            }, "GeneratingMap".Translate(), true, (Exception x) => { Log.Message("Generatem Map Error:" + x.ToString()); });
            Find.World.info.seedString = seed;
            DeepProfiler.End();
        }
        public IEnumerable<GenStepWithParams> GetSteps()
        {
            yield return new GenStepWithParams(QEDefOf.QE_CustomSite_GenStep, new GenStepParams()
            {
                sitePart = new SitePart(null, QEDefOf.QE_CustomSite, new CustomSitePartParams
                {
                    mapData = this.MapDef,
                    quest = this.questID != null ? Find.QuestManager.QuestsListForReading.Find(q => q.id.ToString() == this.questID) : null,
                    spot = this.Position,
                    isSubMap = true
                })
            });
           // yield return new GenStepWithParams(DefDatabase<GenStepDef>.GetNamed("Fog"), new GenStepParams());
            yield break;
        }
        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref this.thereIsPawnIsEntering, "thereIsPawnIsEntering");
            Scribe_Values.Look(ref this.exitName, "CQF_CustomMapEntrance_exitName");
            Scribe_Values.Look(ref this.questID, "CQF_CustomMapEntrance_questID");
            Scribe_Defs.Look(ref this.mapDef, "CQF_CustomMapEntrance_mapDef");
            Scribe_References.Look(ref this.exit, "CQF_CustomMapEntrance_exit");
            Scribe_References.Look(ref this.customMap, "CQF_CustomMapEntrance_customMap");
        }


        public float height = 0f;
        public Vector2 scrollPos;
        [NoTranslate]
        public string exitName;
        public CustomMapExit exit;    
        protected Map customMap;
        protected CustomMapDataDef mapDef;
        public string questID = null;
        private CompCustomText textComp = null;

        public bool thereIsPawnIsEntering = false;
    }
}
