﻿using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using Verse;

namespace QuestEditor_Library
{
    public class CustomTrap : ThingWithComps,IDrawable
    {
        public override string Label => this.TextComp == null || !this.textComp.useCustomName ? base.Label : this.textComp.customName;
        public override string DescriptionFlavor => this.TextComp == null || !this.textComp.useCustomDescription ? base.DescriptionFlavor : this.textComp.customDescription;
        public CompCustomText TextComp
        {
            get
            {
                if (this.textComp == null)
                {
                    this.textComp = this.TryGetComp<CompCustomText>();
                }
                return this.textComp;
            }
        }
        public Dictionary<string, TargetInfo> GetTargetThis()
        {
            Dictionary<string, TargetInfo> result = new Dictionary<string, TargetInfo>();
            result.Add("CustomThing", this);
            return result;
        }
        public void Draw(ref float y, Rect inRect, float x)
        {
            Text.Font = GameFont.Small;
            EditorTools.DrawLabelAndText_Line(y, "TrapName".Translate(), ref this.trapName, x, 350f);
            y += 30f;
            if (Widgets.ButtonText(new Rect(x,y,325f,25f),"CustomTrapMode".Translate(("ActionTriggerMode_" + this.mode.ToString()).Translate()),false)) 
            {
                EditorTools.DrawFloatMenu(new List<ActionTriggerMode>() { ActionTriggerMode.Signal, ActionTriggerMode.StepOn, ActionTriggerMode.Tick},m => this.mode = m,m => ("ActionTriggerMode_" + m.ToString()).Translate());
            }
            y += 30f;
            Widgets.CheckboxLabeled(new Rect(x,y,250f,25f), "TriggerWhenDamaged".Translate(), ref this.triggerWhenDamaged);
            y += 30f;
            if (this.mode == ActionTriggerMode.Signal) 
            {
                EditorTools.DrawLabelAndText_Line(y, "TrapInSignal".Translate(), ref this.inSignal, x, 400f);
                y += 30f;
                Rect rect = new Rect(x, y, 150f, 25f);
                Widgets.CheckboxLabeled(rect, "SignalOnlyIsValidInPart".Translate(), ref this.signalIsOnlyValidInPart);
                TooltipHandler.TipRegion(rect, "SignalOnlyIsValidInPartTip".Translate());
                y += 30f;
            }
            if (this.mode == ActionTriggerMode.Tick)
            {
                EditorTools.DrawLabelAndText_Line(y, "TickToTrigger".Translate(), ref this.tick,ref this.buffer, x);
                TooltipHandler.TipRegion(new Rect(x, y, 150f, 25f), "TickToTriggerTip".Translate());
                y += 30f;
            }
            TooltipHandler.TipRegion(new Rect(x, y, 125f,30f), "CustomTrapTip".Translate());
            EditorTools.DrawIDrawList(ref y,x,this.actions,inRect,"TrapActions".Translate());
        }
        public void Trigger(Pawn pawn = null) 
        {
            this.actions.ForEach(a =>
            {
                if (pawn == null) 
                {
                    a.Work(this.GetTargetThis());
                    return;
                }
                Dictionary<string, TargetInfo> targets = this.GetTargetThis();
                targets.Add("Trigger",pawn);
                a.Work(targets);
            });
        }
        public override void Tick()
        {
            base.Tick();
            if (this.mode == ActionTriggerMode.StepOn && this.Map != null && this.IsHashIntervalTick(25))
            {
                if (this.Position.GetFirstPawn(this.Map) is Pawn pawn)
                {
                    this.Trigger(pawn);
                }
            }
            if (this.mode == ActionTriggerMode.Tick && this.Map != null && this.tick != 0 && this.IsHashIntervalTick(this.tick))
            {
                this.actions.ForEach(a => a.Work(this.GetTargetThis()));
            }
        }
        public override void Notify_SignalReceived(Signal signal)
        {
            base.Notify_SignalReceived(signal);
            if (signal.tag == this.inSignal) 
            {
                this.Trigger();
            }
        }

        public override void PostApplyDamage(DamageInfo dinfo, float totalDamageDealt)
        {
            base.PostApplyDamage(dinfo, totalDamageDealt);
            if (this.triggerWhenDamaged) 
            {
                this.Trigger();
            }
        }
        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref this.trapName, "CustomTrap_trapName");
            Scribe_Values.Look(ref this.inSignal, "CustomTrap_inSignal"); 
            Scribe_Values.Look(ref this.mode, "CustomTrap_mode");
            Scribe_Values.Look(ref this.triggerWhenDamaged, "triggerWhenDamaged"); 
            Scribe_Values.Look(ref this.tick, "CustomTrap_tick");
            Scribe_Values.Look(ref this.signalIsOnlyValidInPart, "signalIsOnlyValidInPart");
            Scribe_Collections.Look(ref this.actions, "CustomTrap_actions",LookMode.Deep);
        }

        public bool triggerWhenDamaged = true;
        public string buffer;
        public string trapName = "undefined";
        public string inSignal = null;
        public int tick = 0;
        public ActionTriggerMode mode = ActionTriggerMode.None;
        public bool signalIsOnlyValidInPart = false;
        public List<CQFAction> actions = new List<CQFAction>();
        private CompCustomText textComp = null;
    }
}
