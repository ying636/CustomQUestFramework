﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI.Group;
using Verse.AI;
using System.Xml.Linq;
using System.Xml;

namespace QuestEditor_Library
{
    public class InteractableThing : Building, IDrawTabable,IPastableData
    {
        public override string Label => this.TextComp == null || !this.textComp.useCustomName ? base.Label : this.textComp.customName;
        public override string DescriptionFlavor => this.TextComp == null || !this.textComp.useCustomDescription ? base.DescriptionFlavor : this.textComp.customDescription;
        public override Graphic Graphic
        {
            get
            {
                if (!this.disable)
                {
                    return base.Graphic;
                }
                if (this.disabledGraphic == null)
                {
                    Graphic baseGraphic = base.Graphic;
                    if (this.def.GetModExtension<ModExtension_CustomThing>() is ModExtension_CustomThing me && me.openedGraphicdata != null)
                    {
                        this.disabledGraphic = me.openedGraphicdata.Graphic;
                        return this.disabledGraphic;
                    }
                    this.disabledGraphic = GraphicDatabase.Get(this.def.graphicData.graphicClass, this.def.graphicData.texPath + "_disabled", baseGraphic.Shader, baseGraphic.drawSize, baseGraphic.color, baseGraphic.colorTwo, baseGraphic.maskPath == null ? null : baseGraphic.maskPath + "_opened");
                }
                return this.disabledGraphic;
            }
        }
        public CompCustomText TextComp
        {
            get
            {
                if (this.textComp == null)
                {
                    this.textComp = this.TryGetComp<CompCustomText>();
                }
                return this.textComp;
            }
        }
        public List<InteractionOperation> AllInteraction 
        {
            get 
            {
                List<InteractionOperation> result = new List<InteractionOperation>();
                result.AddRange(this.operations);
                return result;
            }
        }
        public override string GetInspectString()
        {
            string result = base.GetInspectString();
            this.AllInteraction.ForEach(x => result += " " + x.interactionText);
            return result.Trim();
        }
        public InteractionOperation GetCurOperation(string operationText) 
        {
            if (this.AllInteraction.Find(x => x.interactionText.Translate() == operationText) is InteractionOperation operation) 
            {
                return operation;
            }
            return null;
        }
        public void DrawTab()
        {
            Widgets.BeginScrollView(new Rect(7f, 25f, 475f, 590f), ref this.scrollPos, new Rect(7f, 10f, 475f, this.height));
            Widgets.DrawBox(new Rect(8f, 10f, 470f, this.height), 1, QuestEditor_Dialog.blueTex);
            float y = 20f;
            Text.Font = GameFont.Medium;
            Widgets.Label(new Rect(15f, y, 900f, 38f), "InteractionOperations".Translate().Colorize(ColorLibrary.SkyBlue));
            Text.Font = GameFont.Small;
            if (Widgets.ButtonImage(new Rect(450f, y, 25f, 25f), TexButton.Copy))
            {
                this.operations.ForEach(o => EditorTools.operations.Add(o.Copy()));
                this.operationDefs.ForEach(o => EditorTools.operationDefs.Add(o));
            }
            TooltipHandler.TipRegion(new Rect(450f, y, 25f, 25f), "Copy".Translate());
            y += 40f;
            Rect rect = new Rect(15f, y, 400f, 30f);
            for(int i = 0; i<this.operations.Count; i++)
            {
                InteractionOperation o = this.operations[i];
                rect.y = y;
                if (Widgets.ButtonText(rect, o.interactionText, false))
                {
                    Find.WindowStack.Add(new Dialog_InteractionOption(o));
                }
                if (Widgets.ButtonImage(new Rect(450f, y, 25f, 25f), TexButton.Copy))
                {
                    EditorTools.operation = o;
                }
                TooltipHandler.TipRegion(new Rect(450f, y, 25f, 25f), "Copy".Translate());
                Rect save = new Rect(420f,y,25f,25f);
                if (Widgets.ButtonImage(save, ContentFinder<Texture2D>.Get("UI/Icon_MoveOut", true)))
                {
                    Find.WindowStack.Add(new Dialog_RenameForQE(name =>
                    {
                        LongEventHandler.QueueLongEvent(() =>
                    {
                        InteractionDataDef def = new InteractionDataDef();
                        def.defName = name;
                        def.label = o.interactionText;
                        def.interactions = new List<InteractionOperation>() { o };
                        DefDatabase<InteractionDataDef>.Add(def);
                        string path = Page_QuestEditor.Path + @"\Data\" + o.interactionText + ".xml";
                        XElement defs = new XElement("Defs");
                        XElement defXml = new XElement("QuestEditor_Library.InteractionDataDef");
                        XElement interactionDataDefXml = new XElement("interactions");
                        interactionDataDefXml.Add(o.SaveToXElement("li"));
                        defXml.Add(new XElement("defName", name));
                        defXml.Add(new XElement("label", o.interactionText));
                        defXml.Add(interactionDataDefXml);
                        defs.Add(defXml);
                        defs.Save(path);
                        Messages.Message("SaveSucceed".Translate(path), MessageTypeDefOf.PositiveEvent);
                    }, "SavingAsDef".Translate(), true, e => Log.Message(e.Message));
                    })
                    {optionalTitle = "SetDefname".Translate()});
                }
                TooltipHandler.TipRegion(save, "SaveAsDef".Translate());
                y += 35f;
            };
            y += 5f;       
            if (Widgets.ButtonImage(new Rect(212.5f, y, 25f, 25f), TexButton.Paste) && EditorTools.operation != null)
            {
                this.operations.Add(EditorTools.operation);
            }
            TooltipHandler.TipRegion(new Rect(212.5f, y, 25f, 25f), "Paste".Translate());
            EditorTools.DrawButtonForList(ref y, this.operations, x => x.interactionText,10f);
            y += 5f;
            EditorTools.DrawEditableList(this.operationDefs,ref y,(r,o) => Widgets.Label(r,o.label),o => o.label,() => 
            EditorTools.DrawFloatMenu(DefDatabase<InteractionDataDef>.AllDefsListForReading,d => this.operationDefs.Add(d),d => d.label),"InteractionDataDefs".Translate(),null,true,15f,320f);
            this.height = y + 5f;
            Widgets.EndScrollView();
        }
        public void ProduceResult(Pawn operatorPawn, string operationText)
        {
            if (this.GetCurOperation(operationText) is InteractionOperation op && op != null) 
            {
                op.ProduceResult(operatorPawn, this);
            } 
        }
        public override IEnumerable<FloatMenuOption> GetFloatMenuOptions(Pawn selPawn)
        {
            foreach (FloatMenuOption option in base.GetFloatMenuOptions(selPawn))
            {
                yield return option;
            }
            if (!this.disable)
            {
                if (selPawn.CanReserveAndReach(this, PathEndMode.Touch, Danger.Deadly))
                {
                    foreach (InteractionOperation operation in this.AllInteraction)
                    {
                        string failReason = "Unkown";
                        string text = operation.interactionText.Translate();
                        if (operation.Satisfied(selPawn, this, out failReason))
                        {
                            Job job = JobMaker.MakeJob(QEDefOf.QE_InteractingWithTarget, this);
                            job.reportStringOverride = text;
                            yield return new FloatMenuOption(text, () => selPawn.jobs.StartJob(job));
                        }
                        else
                        {
                            yield return new FloatMenuOption($"{text}({failReason})", null);
                        }
                    }
                }
                else
                {
                    yield return new FloatMenuOption("CantReseverveOrReachLootBox".Translate(), null);
                }
            }
            yield break;
        }
        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref this.disable, "InteractableThing_disable");
            Scribe_Collections.Look(ref this.operations, "InteractableThing_operations",LookMode.Deep);
            Scribe_Collections.Look(ref this.operationDefs, "operationDefs", LookMode.Def);
        }

        public void PasteData()
        {
            this.operations.AddRange(EditorTools.operations.ListFullCopy());
            this.operationDefs.AddRange(EditorTools.operationDefs.ListFullCopy());
        }

        public float height = 0f;
        public Vector2 scrollPos;
        public bool disable = false;
        public Graphic disabledGraphic = null;
        public List<InteractionOperation> operations = new List<InteractionOperation>();
        public List<InteractionDataDef> operationDefs = new List<InteractionDataDef>();
        private CompCustomText textComp = null;
    }

    public class InteractionOperation : ISaveable , IExposable
    {
        public InteractionOperation Copy() 
        {
            XElement x = this.SaveToXElement("InteractionOperation");
            XmlNode node = new XmlDocument().ReadNode(x.CreateReader()) as XmlNode;
            InteractionOperation result = DirectXmlToObject.ObjectFromXml<InteractionOperation>(node, false);
            DirectXmlCrossRefLoader.ResolveAllWantedCrossReferences(FailMode.LogErrors);
            return result;
        }
        public void ProduceResult(Pawn interacter, Thing thing)
        {
            this.results.ForEach(r => 
            {
                if (r.Satisfied(interacter,thing)) 
                {
                    r.DoResult(interacter,thing);
                }
            });
            Dictionary<ThingCategoryDef, int> categoryAndCount = new Dictionary<ThingCategoryDef, int>();
            foreach (LootThingData data in this.requiredThings)
            {
                if (data is CQFThingDefCount tData)
                {
                    interacter.inventory.innerContainer.Take(interacter.inventory.innerContainer.ToList().Find(i => i.def == tData.thing),tData.count.min).Destroy();
                }
                if (data is CQFThingCategoryCount cData)
                {
                    categoryAndCount.Add(cData.category,cData.count.min);
                }
            }
            //target.inventory.innerContainer.InnerListForReading.ListFullCopy().ForEach(t => 
            //{
            //    categoryAndCount.ToList().ListFullCopy().ForEach(c => 
            //    {
            //        if (t.HasThingCategory(c.Key)) 
            //        {
            //            int count = t.stackCount;
            //            t.SplitOff(Math.Max(c.Value, count)).Destroy();
            //            categoryAndCount.SetOrAdd(c.Key,Math.Max(0,c.Value - count));
            //            if (categoryAndCount[c.Key] <= 0) 
            //            {
            //                categoryAndCount.Remove(c.Key);
            //            }

            //        }
            //    });
            //});
            QuestUtility.SendQuestTargetSignals(thing.questTags, this.interactionText,thing.Named("SUBJECT"));
        }
        public bool Satisfied(Pawn target,Thing thing,out string reason)
        {
            foreach (DialogCondition condition in this.conditions)
            {
                Dictionary<string, TargetInfo> targets = new Dictionary<string, TargetInfo>();
                targets.Add("Trigger", target);
                targets.Add("CustomThing", thing);
                if (!condition.Satisfied(targets, out reason)) 
                {
                    return false;
                }
            }
            foreach (LootThingData data in this.requiredThings) 
            {
                if (data is CQFThingDefCount tData && target.inventory.Count(tData.thing) < tData.count.min) 
                {
                    reason = "NoRequiredThing".Translate(tData.thing.label,tData.count.min.ToString());
                    return false;
                }
                if (data is CQFThingCategoryCount cData)
                {
                    //int count = 0;
                    //target.inventory.innerContainer.ToList().ForEach(t =>
                    //{
                    //    if (t.HasThingCategory(cData.category))
                    //    {
                    //        count += t.stackCount;
                    //    }
                    //});
                    //if (count < cData.count.min)
                    //{
                    //    reason = "NoRequiredThingCategory".Translate(cData.category.label, cData.count.ToString());
                    //    return false;
                    //} 
                }
            }
            reason = null;
            return true;
        }
        public void ExposeData()
        {
            Scribe_Values.Look(ref this.tickToOperate, "InteractionOperation_tickToOperate");
            Scribe_Values.Look(ref this.interactionText, "InteractionOperation_interactionText");
            Scribe_Collections.Look(ref this.requiredThings, "requiredThings", LookMode.Deep);
            Scribe_Collections.Look(ref this.conditions, "InteractionOperation_conditions", LookMode.Deep);
            Scribe_Collections.Look(ref this.results, "InteractionOperation_results", LookMode.Deep); 
        }

        public XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            result.Add(new XElement("interactionText", this.interactionText));
            result.Add(new XElement("tickToOperate", this.tickToOperate));
            if (this.results.Any())
            {
                XElement results = new XElement("results");
                this.results.ForEach(x =>
                {
                    results.Add(x.SaveToXElement("li"));
                });
                result.Add(results);
            }
            if (this.requiredThings.Any())
            {
                XElement results = EditorTools.SaveList_Saveable(this.requiredThings, "requiredThings");
                result.Add(results);
            }
            if (this.conditions.Any())
            {
                XElement conditions = new XElement("conditions");
                this.conditions.ForEach(x =>
                {
                    conditions.Add(x.SaveToXElement("li"));
                });
                result.Add(conditions);
            }
            return result;
        }

        public string interactionText = "DefaultInteractionText";
        public int tickToOperate = 100;
        public List<DialogCondition>  conditions = new List<DialogCondition>();
        public List<InteractionResult>  results = new List<InteractionResult>();
        public List<LootThingData>  requiredThings = new List<LootThingData>();
    }

    public class InteractionResult : ISaveable, IExposable 
    {
        public void Draw(ref float y,Rect inRect,float x = 0f)
        {
            Text.Font = GameFont.Medium;
            Widgets.Label(new Rect(5f + x, y, 150f, 35f),this.resultName.Colorize(ColorLibrary.SkyBlue));   
            Text.Font = GameFont.Small;
            y += 40f;
            if (Widgets.ButtonText(new Rect(5f + x, y, 150f, 25f), "Rename".Translate()))
            {
                Find.WindowStack.Add(new Dialog_RenameForQE((name) => this.resultName = name));
            }
            y += 30f;
            float initY = y;
            Widgets.Label(new Rect(5f + x,y,150f, 25f), "If".Translate().Colorize(ColorLibrary.PaleBlue));
            y += 30f;
            foreach (DialogCondition c in this.conditions) 
            {
                c.Draw(ref y, inRect, x + 5f);
            }
            y += 5f;
            EditorTools.DrawButtonForList(ref y, this.conditions, c => c.GetType().Name.Translate(), () => EditorTools.DrawFloatMenu(typeof(DialogCondition).AllSubclassesNonAbstract(), c =>
    this.conditions.Add((DialogCondition)Activator.CreateInstance(c)), c => c.Name.Translate()),10,150f);
            y += 5f;
            Widgets.DrawBox(new Rect(x, initY, inRect.width - 40f - (2 * x), y - initY), 1, QuestEditor_Dialog.blueTex);
            y += 10f;
            initY = y;
            y += 5f;
            Widgets.Label(new Rect(5f + x, y, 150f, 25f), "InteractionActions".Translate().Colorize(ColorLibrary.PaleBlue));
            y += 30f;
            foreach (CQFAction c in this.actions)
            {
                c.Draw(ref y, inRect, x + 5f);
                y += 5f;
            }
            y += 5f;
            EditorTools.DrawButtonForList(ref y, this.actions, a => a.GetType().Name.Translate(), () => EditorTools.DrawFloatMenu(typeof(CQFAction).AllSubclassesNonAbstract(), a =>
this.actions.Add((CQFAction)Activator.CreateInstance(a)), a => a.Name.Translate()), 10, 150f);
            y += 5f;
            Widgets.DrawBox(new Rect(x, initY, inRect.width - 40f - (2 * x), y - initY), 1, QuestEditor_Dialog.blueTex);
            y += 15f;
        }
        public void DoResult(Pawn target, Thing thing) 
        {
            Dictionary<string, TargetInfo> targets = new Dictionary<string, TargetInfo>();
            targets.Add("Trigger", target);
            targets.Add("CustomThing", thing);
            this.actions.ForEach(x => x.Work(targets));
        }
        public bool Satisfied(Pawn target, Thing thing) 
        {
            Dictionary<string, TargetInfo> targets = new Dictionary<string, TargetInfo>();
            targets.Add("Trigger", target);
            targets.Add("CustomThing", thing);
            foreach (DialogCondition condition in this.conditions)
            {
                if (!condition.Satisfied(targets, out string reason))
                {
                    return false;
                }
            }
            return true;
        }
        public void ExposeData()
        {
            Scribe_Values.Look(ref this.resultName, "InteractionResult_resultName");
            Scribe_Collections.Look(ref this.conditions, "InteractionResult_conditions", LookMode.Deep);
            Scribe_Collections.Look(ref this.actions, "InteractionResult_actions", LookMode.Deep);
        }

        public XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            XElement conditions = new XElement("conditions");
            this.conditions.ForEach(x =>
            {
                conditions.Add(x.SaveToXElement("li"));
            });
            XElement actions = new XElement("actions");
            this.actions.ForEach(x =>
            {
                actions.Add(x.SaveToXElement("li"));
            });
            result.Add(new XElement("resultName", this.resultName));
            result.Add(actions);
            result.Add(conditions);
            return result;
        }

        public string resultName = "DefaultName";
        public List<DialogCondition> conditions = new List<DialogCondition>();
        public List<CQFAction> actions = new List<CQFAction>();
    }
}