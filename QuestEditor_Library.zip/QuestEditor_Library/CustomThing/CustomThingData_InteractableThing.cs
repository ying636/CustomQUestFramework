﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using RimWorld;
using Verse;

namespace QuestEditor_Library
{
    public class CustomThingData_InteractableThing : CustomThingData
    {
        public CustomThingData_InteractableThing() { }
        public CustomThingData_InteractableThing(InteractableThing thing, IntVec3 pos) : base(thing, pos) 
        {
            this.operations = thing.operations;
            this.operationDefs = thing.operationDefs;
        }
        public override XElement SaveToXElement(string nodeName) 
        {
            XElement result = base.SaveToXElement(nodeName); 
            if (this.operations.Any())
            {
                XElement operations = new XElement("operations");
                this.operations.ForEach((x) => operations.Add(x.SaveToXElement("li")));
                result.Add(operations);
            }
            if (this.operationDefs.Any())
            {
                XElement operations = new XElement("operationDefs");
                this.operationDefs.ForEach((x) => operations.Add(new XElement("li",x.defName)));
                result.Add(operations);
            }
            return result;
        }

        public override Thing SpawnThing(Map map, string questId, GenStepParams parms, IntVec3? centre = null, bool load = false, CustomMapDataDef def = null, Func<ThingDef, ThingDef> getStuff = null)
        {
            InteractableThing interactableThing = (InteractableThing)base.SpawnThing(map, questId, parms, centre, load, def, getStuff);
            if (interactableThing == null)
            {
                return null;
            }
            this.operations.ForEach(c => interactableThing.operations.Add(c.Copy()));
            this.operationDefs.ForEach(d => d.interactions.ForEach(c => interactableThing.operations.Add(c.Copy())));
            interactableThing.operations.ForEach(op => 
            {
                op.results.ForEach(r => 
                {
                    r.actions.ForEach(a =>
                    {
                        if (a is CQFAction_SentSignal signal)
                        {
                            List<string> signalParts2 = new List<string>()
                    {
                        "Quest",
                        questId,
                        signal.signal
                    };
                            if (signal.signalIsOnlyValidInPart)
                            {
                                signalParts2.Add(def.defName + GenStep_CustomMap.generatedCount[def].ToString());
                            }
                            signal.signal = string.Concat(signalParts2);
                        }
                    });
                });
            });
            return interactableThing;
        }

        public List<InteractionOperation> operations = new List<InteractionOperation>();
        public List<InteractionDataDef> operationDefs = new List<InteractionDataDef>();
    }
}
