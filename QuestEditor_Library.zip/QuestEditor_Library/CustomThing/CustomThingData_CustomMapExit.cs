﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using RimWorld;
using Verse;

namespace QuestEditor_Library
{
    public class CustomThingData_CustomMapExit : CustomThingData
    {
        public CustomThingData_CustomMapExit() { }
        public CustomThingData_CustomMapExit(CustomMapExit thing, IntVec3 pos) : base(thing, pos) 
        {
            this.exitName = thing.exitName;
        }
        public override XElement SaveToXElement(string nodeName) 
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("exitName", this.exitName));
            return result;
        }
        public override Thing SpawnThing(Map map, string questId, GenStepParams parms, IntVec3? centre = null, bool load = false, CustomMapDataDef def = null, Func<ThingDef, ThingDef> getStuff = null)
        {
            CustomMapExit customMapExit = (CustomMapExit)base.SpawnThing(map, questId, parms, centre, load,def, getStuff);
            if (customMapExit == null)
            {
                return null;
            }
            customMapExit.exitName = this.exitName;
            if (map.Parent is MapParent_Custom parent && parent.entrance is CustomMapEntrance entrance && entrance.exitName == this.exitName)
            {
                entrance.exit = customMapExit;
                customMapExit.entrance = entrance;
                parent.exit = customMapExit;
                parent.enterSpot = this.position + map.Center;
            }
            return customMapExit;
        }

        public string exitName;
    }
}
