﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using RimWorld;
using Verse;

namespace QuestEditor_Library
{
    public class CustomThingData_CustomMapEntrance : CustomThingData
    {
        public CustomThingData_CustomMapEntrance() { }
        public CustomThingData_CustomMapEntrance(CustomMapEntrance thing, IntVec3 pos) : base(thing, pos) 
        {
            this.data = thing.MapDef;
            this.exitName = thing.exitName;
            if (thing is CustomMapEntrance_Chance entrance)
            {
                this.tagWithChance = entrance.tagWithChance;
                this.mapDefWithChance = entrance.mapDefWithChance;
            }
        }
        public override CustomThingData Copy()
        {
            CustomThingData_CustomMapEntrance result = (CustomThingData_CustomMapEntrance)base.Copy();
            result.data = this.data;
            result.exitName = this.exitName;
            result.tagWithChance = this.tagWithChance;
            result.mapDefWithChance = this.mapDefWithChance;
            return result;
        }
        public override XElement SaveToXElement(string nodeName) 
        {
            XElement result = base.SaveToXElement(nodeName);
            result.Add(new XElement("data",this.data));
            result.Add(new XElement("exitName", this.exitName));
            if(this.tagWithChance.Any())
            {
                XElement tagWithChance = new XElement("tagWithChance");
                this.tagWithChance.ForEach(t =>
                {
                    XElement li = new XElement("li");
                    li.Add(new XElement("tag", t.tag));
                    li.Add(new XElement("chance", t.chance));
                    tagWithChance.Add(li);
                });
                result.Add(tagWithChance);
            }
            if (this.mapDefWithChance.Any())
            {
                XElement mapDefWithChance = new XElement("mapDefWithChance");
                this.mapDefWithChance.ForEach(t =>
                {
                    XElement li = new XElement("li");
                    li.Add(new XElement("def", t.def.defName));
                    li.Add(new XElement("chance", t.chance));
                    mapDefWithChance.Add(li);
                });
                result.Add(mapDefWithChance);
            }

            return result;
        }

        public override Thing SpawnThing(Map map, string questId, GenStepParams parms, IntVec3? centre = null, bool load = false, CustomMapDataDef def = null, Func<ThingDef, ThingDef> getStuff = null)
        {
            CustomMapEntrance customMapEntrance = (CustomMapEntrance)base.SpawnThing(map, questId, parms, centre, load,def, getStuff);
            if (customMapEntrance == null)
            {
                return null;
            }
            if (customMapEntrance is CustomMapEntrance_Chance entrance) 
            {
                entrance.mapDefWithChance = this.mapDefWithChance;
                entrance.tagWithChance = this.tagWithChance;
            }
            customMapEntrance.SetMapDef(this.data);
            customMapEntrance.exitName = this.exitName;
            customMapEntrance.questID = questId;
            return customMapEntrance;
        }

        public string exitName;
        public CustomMapDataDef data;
        public List<TagWithChance> tagWithChance = new List<TagWithChance>();
        public List<MapDefWithChance> mapDefWithChance = new List<MapDefWithChance>();
    }
}
