﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using RimWorld;
using Verse;

namespace QuestEditor_Library
{
    public class CustomThingData_LootBox : CustomThingData
    {
        public CustomThingData_LootBox() { }
        public CustomThingData_LootBox(LootBox lootBox, IntVec3 pos) : base(lootBox, pos) 
        {
            this.loots = lootBox.loots;
            this.tickToOpen = lootBox.tickToOpen;
            this.openReport = lootBox.openReport;
            this.destroyAfterOpening = lootBox.destroyAfterOpening;
            this.lootBoxName = lootBox.lootBoxName;
            this.lootDef = lootBox.lootDef;
        }
        public override XElement SaveToXElement(string nodeName) 
        {
            XElement result = base.SaveToXElement(nodeName);
            if (this.lootDef != null) 
            {
                result.Add(new XElement("lootDef", this.lootDef.defName));
            }
            result.Add(new XElement("lootBoxName", this.lootBoxName));
            result.Add(new XElement("tickToOpen", this.tickToOpen));
            result.Add(new XElement("openReport", this.openReport));
            result.Add(new XElement("destroyAfterOpening", this.destroyAfterOpening));
            if (this.loots.Any()) 
            {
                XElement loots = new XElement("loots");
                this.loots.ForEach((x) => loots.Add(x.SaveToXElement("li")));
                result.Add(loots);
            }
            return result;
        }

        public override Thing SpawnThing(Map map, string questId, GenStepParams parms, IntVec3? centre = null, bool load = false, CustomMapDataDef def = null, Func<ThingDef, ThingDef> getStuff = null)
        {
            LootBox lootBox = (LootBox)base.SpawnThing(map, questId, parms,centre,load,def, getStuff);
            if (lootBox == null) 
            {
                return null;
            }
            lootBox.loots.AddRange(this.loots);      
            if (this.lootDef != null)
            {
                lootBox.loots.AddRange(this.lootDef.loots);
            }
            lootBox.tickToOpen = this.tickToOpen;
            lootBox.openReport = this.openReport;
            lootBox.destroyAfterOpening = this.destroyAfterOpening;
            lootBox.lootBoxName = this.lootBoxName;
            return lootBox;
        }

        public string lootBoxName;
        public int tickToOpen = 100;
        public string openReport = "OpenLoot";
        public bool destroyAfterOpening = false;
        public List<LootData> loots = new List<LootData>();
        public LootDataDef lootDef;
    }
}
