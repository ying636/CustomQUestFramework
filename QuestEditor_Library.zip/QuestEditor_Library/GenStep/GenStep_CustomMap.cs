﻿using System;
using System.Collections.Generic;
using RimWorld.Planet;
using RimWorld;
using Verse;
using Verse.AI.Group;
using System.Linq;

namespace QuestEditor_Library
{
    public class GenStep_CustomMap : GenStep
    {
        public override int SeedPart => 1114561;

        public override void Generate(Map map, GenStepParams parms)
        {
            if (parms.sitePart.parms is CustomSitePartParams customParams && customParams.mapData is CustomMapDataDef def)
            {
                GenStep_CustomMap.SpawnCustomMap(map, parms, def,customParams.quest?.id.ToString(),customParams.isDev,null,false,customParams.isSubMap);
                def.steps.ForEach(s => s.Generate(map,def,customParams));
            }
        }

        public static void SpawnCustomMap(Map map, GenStepParams parms, CustomMapDataDef def, string questId, bool load = false, IntVec3? centerP = null, bool isGenerateByCore = false,bool isSubMap = false)
        {
            try
            {
                generatedCount.SetOrAdd(def, generatedCount.ContainsKey(def) ? generatedCount[def] + 1 : 1);
                IntVec3 center = centerP == null ? map.Center : centerP.Value;
                if (def.disgenerate.Any())
                {
                    def.disgenerate.ForEach(d => disgenerate.Add(d + center));
                }
                if (!load)
                {
                    GenStep_CustomMap.DestroyThings(map, def, center, isGenerateByCore);
                }
                GenStep_CustomMap.SetRoofAndTerrain(map, def, center);
                if (!load)
                {
                    GenStep_CustomMap.SpawnPawns(map, def, center, questId);
                }
                else
                {
                    GenStep_CustomMap.SpawnSpawners(map, def, center);
                }
                GenStep_CustomMap.SpawnThings(map, parms, def, center, load);
                GenStep_CustomMap.AddPawnDataToLord(map, def, center);
                GenStep_CustomMap.SpawnCustomThing(map, def, questId, parms, center, load);
                map.GetComponent<MapComponent_CustomMapData>().questTag = "Quest" + questId;
                if (!isGenerateByCore)
                {
                    if (def.reserveThing is ThingData data)
                    {
                        map.AllCells.ToList().ForEach(c =>
                        {
                            if (!disgenerate.Contains(c) && c.GetFirstBuilding(map) == null)
                            {
                                data.Spawn(map, c, t => GetDef(t, def));
                            }
                        });
                    }
                    replaceDic.Clear();
                    if (DebugTools.clearGenerationData)
                    {
                        disgenerate.Clear();
                        generatedCount.Clear();
                    }
                }
                if (!load && def.fogged && !isGenerateByCore)
                {
                    GenStep_CustomMap.Fog(map, def, center, isGenerateByCore, isSubMap);
                }
            }
            catch(Exception e) 
            {
                Log.Error("Generate Custom map error:" + def?.label + "," + e.Message);
            }
        }

        public static void SpawnCustomThing(Map map, CustomMapDataDef def,string questId, GenStepParams parms,IntVec3 centre,bool load = false)
        {
            foreach (CustomThingData data in def.customThings)
            {
                data.SpawnThing(map, questId, parms,centre, load,def, d =>
                {
                    return load ? d : GenStep_CustomMap.GetDef(d, def);
                });
            }
        }

        private static void AddPawnDataToLord(Map map, CustomMapDataDef def, IntVec3 center)
        {
            foreach (KeyValuePair<IntVec3, List<PawnSpawnData>> content in def.specialSpawnPawns)
            {
                IntVec3 intVec3 = center + content.Key;
                MapComponent_CustomMapData component = map.GetComponent<MapComponent_CustomMapData>();
                List<PawnSpawnData> specialDatas = new List<PawnSpawnData>();
                if (content.Value.Any())
                {
                    foreach (PawnSpawnData data in content.Value)
                    {
                        if (data.spawnType != SpawnType.BuildingTick)
                        {
                            specialDatas.Add(data);
                        }
                        else
                        {
                            component.pawnSpawnDatas_Tick.Add(new PawnDataWithPosAndTime() { data = data, position = intVec3 });
                        }
                    }
                }
                if (specialDatas.Any() && intVec3.GetFirstBuilding(map) is Building building)
                {
                    component.pawnSpawnDatas_Building.Add(building, specialDatas);
                }
            }
        }
        private static void SpawnSpawners(Map map, CustomMapDataDef def, IntVec3 center) 
        {
            foreach (KeyValuePair<IntVec3, List<PawnSpawnData>> content in def.pawns)
            {
                ((Spawner)GenSpawn.Spawn(QEDefOf.QE_Spawner_Editor,center + content.Key,map)).pawns = content.Value;
            }
        }
        private static void SpawnPawns(Map map, CustomMapDataDef def, IntVec3 center,string questId)
        {
            Dictionary<Faction, Lord> lords = new Dictionary<Faction, Lord>();
            foreach (KeyValuePair<IntVec3, List<PawnSpawnData>> content in def.pawns)
            {
                Faction faction = null;
                foreach (PawnSpawnData data in content.Value)
                {
                    Lord lord = null;
                    List<Pawn> pawns = new List<Pawn>();
                    IntVec3 pos = center + content.Key;
                    if (faction == null && data.faction != null && data.faction != "" && Find.FactionManager.FirstFactionOfDef(FactionDef.Named(data.faction)) != null)
                    {
                        faction = Find.FactionManager.FirstFactionOfDef(FactionDef.Named(data.faction));
                    }
                    if (faction != null && data.enableLord)
                    {
                        if (lords.ContainsKey(faction))
                        {
                            lord = lords[faction];
                        }
                        else 
                        {
                            lord = LordMaker.MakeNewLord(faction, new LordJob_Custom(), map);
                            QuestUtility.AddQuestTag(ref lord.questTags,"Quest" + questId);
                            lords.Add(faction,lord);
                        }
                    }         
                    if (lord != null)
                    {
                        pawns.AddRange(data.Spawn(pos,map, lord,"Quest" + questId));
                    }
                    else 
                    {
                        pawns.AddRange(data.Spawn(pos, map,"Quest" + questId));
                    }
                    if (lord != null && lord.LordJob is LordJob_Custom lordJob)
                    {
                        if (data.duty == QEDefOf.QE_Duty_Guard)
                        {
                            if (def.routes.TryGetValue(data.routeName, out List<IntVec3> route))
                            {
                                List<IntVec3> route2 = new List<IntVec3>();
                                route.ForEach((x) => route2.Add(x + center));
                                pawns.ForEach((x) =>
                                {
                                    lordJob.pawnRouteDatas.SetOrAdd(x,new RouteData(route2));
                                });
                            }
                            else
                            {
                                Log.Error("null route");
                            }
                        }
                        if (data.duty == QEDefOf.QE_Duty_Waiter || data.duty == DutyDefOf.Defend) 
                        {
                            pawns.ForEach((x) =>
                            {
                                lordJob.pawnRouteDatas.SetOrAdd(x,new RouteData(new List<IntVec3>() { pos }));
                            });
                        }
                        pawns.ForEach((x) =>
                        {
                            lordJob.pawnDutyDatas.SetOrAdd(x, data.duty);
                        });
                    }
                }
            }
        }

        public static void SpawnThings(Map map, GenStepParams parms, CustomMapDataDef def, IntVec3 center, bool load = false)
        {
            foreach (ThingData content in def.thingDatas)
            {
                List<IntVec3> poss = new List<IntVec3>();
                if (content.allPositions.Any())
                {
                    poss.AddRange(content.allPositions);
                }
                else
                {
                    poss.Add(content.position);
                }
                poss.ForEach(p =>
                {
                    IntVec3 intVec3 = center + p;
                    content.Spawn(map, intVec3, d =>
                      {
                          return load ? d : GenStep_CustomMap.GetDef(d, def);
                      }
                      );
                });
            }
        }
        private static ThingDef GetDef(ThingDef def,CustomMapDataDef map) 
        {
            if (def == null || map ==null) 
            {
                return def;
            }
            if (replaceDic.TryGetValue(def, out ThingDef newDef))
            {
                return newDef;
            }
            if (map.replaces.TryGetValue(def,out List<ThingDef> defs)) 
            {
                replaceDic.Add(def, defs.RandomElement());
                return replaceDic[def];
            }
            return def;
        }
        public static void SetRoofAndTerrain(Map map, CustomMapDataDef def, IntVec3 center)
        {
            foreach (KeyValuePair<string, List<IntVec3>> content in def.terrains)
            {
                content.Value.ForEach(x =>
                {
                    if ((x + center).InBounds(map))
                    {
                        map.terrainGrid.SetTerrain(x + center, TerrainDef.Named(content.Key));
                    }
                });
            }
            foreach (KeyValuePair<RoofDef, List<IntVec3>> content in def.roofs)
            {
                content.Value.ForEach(x =>
                {
                    if ((x + center).InBounds(map))
                    {
                        map.roofGrid.SetRoof(x + center, content.Key);
                    }
                });
            }
        }

        private static void DestroyThings(Map map, CustomMapDataDef def, IntVec3 center, bool isGenerateByCore)
        {
            CellRect rect = isGenerateByCore ? def.GetRect(center) : new CellRect(center.x - ((int)((def.size.x / 2) + 0.5f)), center.z - ((int)((def.size.z / 2) + 0.5f)), def.size.x, def.size.z);
            List<IntVec3> poss = rect.Cells.ToList();
            List<Thing> things = new List<Thing>();
            if (map.fogGrid == null) 
            {
                map.ConstructComponents();
            }
            poss.ForEach(x =>
            {
                if (x.InBounds(map)) 
                {
                    map.roofGrid.SetRoof(x, null);
                    things.AddRange(x.GetThingList(map).ListFullCopy());
                    if (!rect.EdgeCells.Contains(x))
                    {
                        if (isGenerateByCore)
                        {
                            disgenerate.Add(x);
                        }
                    }
                }
            });
            if (!isGenerateByCore)
            {
                while (things.Count != 0)
                {
                    Thing thing = things[0];
                    if (thing.def.destroyable && !thing.Destroyed)
                    {
                        thing.Destroy();
                    }
                    if (things.Contains(thing))
                    {
                        things.Remove(thing);
                    }
                }
            }
        }

        private static void Fog(Map map, CustomMapDataDef def, IntVec3 center, bool isGenerateByCore,bool isSubMap = false)
        {
            CellIndices cellIndices = map.cellIndices;
            if (map.fogGrid.fogGrid == null)
            {
                map.fogGrid.fogGrid = new bool[cellIndices.NumGridCells];
            }
            foreach (IntVec3 c in map.AllCells)
            {
                map.fogGrid.fogGrid[cellIndices.CellToIndex(c)] = true;
            }
            if (Current.ProgramState == ProgramState.Playing)
            {
                map.roofGrid.Drawer.SetDirty();
            }
            if (!isSubMap)
            {
                FloodFillerFog.FloodUnfog(CellFinderLoose.TryFindCentralCell(map, 7, 10, (IntVec3 x) => !x.Roofed(map)), map);
            }
        }

        public static List<IntVec3> disgenerate = new List<IntVec3>();
        public static Dictionary<ThingDef, ThingDef> replaceDic = new Dictionary<ThingDef, ThingDef>();
        public static Dictionary<CustomMapDataDef, int> generatedCount = new Dictionary<CustomMapDataDef, int>();
    }
}
