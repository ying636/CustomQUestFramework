﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;

namespace QuestEditor_Library
{
    public class GenStep_SetFog : GenStep
    {
        public override int SeedPart => 546516544;

        public override void Generate(Map map, GenStepParams parms)
        {
			CellIndices cellIndices = map.cellIndices;
			if (map.fogGrid.fogGrid == null)
			{
				map.fogGrid.fogGrid = new bool[cellIndices.NumGridCells];
			}
			FogGrid fogGrid = map.fogGrid;
			foreach (IntVec3 c in map.AllCells)
			{
				fogGrid.fogGrid[cellIndices.CellToIndex(c)] = false;
			}
			if (Current.ProgramState == ProgramState.Playing)
			{
				map.roofGrid.Drawer.SetDirty();
			}
		}
    }
}
