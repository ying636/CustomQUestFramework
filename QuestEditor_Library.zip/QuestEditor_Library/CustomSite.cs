﻿using RimWorld;
using RimWorld.Planet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Verse;

namespace QuestEditor_Library
{
    public class CustomSite : Site
    {
        public override void Notify_MyMapRemoved(Map map)
        {
            map.GetComponent<MapComponent_CustomMapData>().subMaps.ForEach(m => m.Destroy());
        }
        public override bool ShouldRemoveMapNow(out bool alsoRemoveWorldObject)
        {
            bool result = base.ShouldRemoveMapNow(out alsoRemoveWorldObject);
            return result && this.ShouldRemoveMapBySubmap(ref alsoRemoveWorldObject);
        }

        private bool ShouldRemoveMapBySubmap(ref bool alsoRemoveWorldObject)
        {
            foreach (MapParent_Custom parent in allSubMaps)
            {
                if ((parent.Map?.mapPawns?.AnyPawnBlockingMapRemoval) ?? false || ((parent.exit?.thereIsPawnIsEntering) ?? false) || ((parent.entrance?.thereIsPawnIsEntering) ?? false))
                {
                    alsoRemoveWorldObject = false;
                    return false;
                }
            }
            alsoRemoveWorldObject = true;
            return true;
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref this.allSubMaps, "allSubMaps",LookMode.Reference);
        }

        public List<MapParent_Custom> allSubMaps = new List<MapParent_Custom>();
    }
}
