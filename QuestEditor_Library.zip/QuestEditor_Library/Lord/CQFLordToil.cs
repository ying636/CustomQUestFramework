﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Verse.AI.Group;

namespace QuestEditor_Library
{
    public abstract class CQFLordToil : LordToil
    {
        public override void UpdateAllDuties()
        {
            int level = 0;
            if (this.Map.Parent is MapParent_Custom custom)
            {
                level = custom.level;
            }
            this.UpdateAllDutiesBasedLevel(level);
        }

        public abstract void UpdateAllDutiesBasedLevel(int level);
    }
}
