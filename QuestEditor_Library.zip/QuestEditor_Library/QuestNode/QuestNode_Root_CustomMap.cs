﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using RimWorld.QuestGen;
using Verse;
using RimWorld.Planet;
using Verse.Grammar;
using UnityEngine;
using System.Xml;
using System.IO;

namespace QuestEditor_Library
{
    public abstract class QuestNode_Root_CustomMap : QuestNode , IDrawable
	{
		public abstract CustomMapDataDef GetMap();
        protected override void RunInt()
        {
			Quest quest = QuestGen.quest;
			Slate slate = QuestGen.slate;
			Faction faction = Find.FactionManager.FirstFactionOfDef(FactionDef.Named(this.faction));
			int tile;
			if (TileFinder.TryFindPassableTileWithTraversalDistance(Find.AnyPlayerHomeMap.Tile, this.distance.min, this.distance.max, out tile, (x) => this.blacklist == null || !this.blacklist.Contains(Find.World.grid[x].biome)))
			{
                CustomSitePartParams parms = new CustomSitePartParams
                {
                    mapData = this.GetMap(),
                    quest = quest,
                    siteIconPath = this.siteIconPath,
                    expandingIconPath = this.expandingIconPath
				};
				CustomSite site = QuestNode_Root_CustomMap.GenerateCustomSite(Gen.YieldSingle<SitePartDefWithParams>(new SitePartDefWithParams(DefDatabase<SitePartDef>.GetNamed("QE_CustomSite"), parms)), tile, faction, false, null);
				site.customLabel = parms.mapData.label;
				quest.SpawnWorldObject(site, null, null);
				slate.Set<Site>(this.storeAs.GetValue(slate), site);
			}
			else 
			{
				quest.End(QuestEndOutcome.Fail);
			}
		}
        protected override bool TestRunInt(Slate slate)
        {
            return true;
        }

        public virtual void Draw(ref float y, Rect inRect,float x)
        {
            y += 50f;
            Widgets.Label(new Rect(x + 270f, y, 350f, 20f), "MapFaction".Translate(this.faction));
            if (Widgets.ButtonText(new Rect(400f, y + 25f, 135f, 38f), "SelectFaction".Translate()))
            {
                EditorTools.DrawFloatMenu<FactionDef>(DefDatabase<FactionDef>.AllDefs.ToList().FindAll((f) => !f.isPlayer), (f) => this.faction = f.defName, (f) => f.label);
            }
            EditorTools.DrawLabelAndText_Line(y, "SiteIconPath".Translate(), ref this.siteIconPath, x + 7f, 150f);
            y += 30f;
            EditorTools.DrawLabelAndText_Line(y, "ExpandingIconPath".Translate(), ref this.expandingIconPath, x + 7f, 150f);
            y += 30f;
            Widgets.Label(new Rect(x + 7f, y, 150f, 20f), "StoreAsText".Translate());
            y += 25f;
            this.storeAs = Widgets.TextField(new Rect(x + 7f, y, 50f, 20f), this.storeAs.ToString());
            y += 50f;
            Widgets.Label(new Rect(x + 170f, y, 300f, 20f), "MapDistance".Translate());
            y += 25f;
            Widgets.TextFieldNumeric<int>(new Rect(x + 170f, y, 50f, 20f), ref this.distance.min, ref this.buffer);
            Widgets.Label(new Rect(x + 220f, y, 100f, 20f), "~");
            Widgets.TextFieldNumeric<int>(new Rect(x + 230f, y, 50f, 20f), ref this.distance.max, ref this.bufferMin);
            if (Widgets.ButtonText(new Rect(x + 315f, y, 150f, 35f), "Add".Translate()))
            {
                EditorTools.DrawFloatMenu<BiomeDef>(DefDatabase<BiomeDef>.AllDefs.ToList().FindAll(b => !this.blacklist.Contains(b)), (b) => this.blacklist.Add(b), (b) => b.label);
            }
            if (Widgets.ButtonText(new Rect(x + 485f, y, 150f, 35f), "Delete".Translate()))
            {
                EditorTools.DrawFloatMenu<BiomeDef>(this.blacklist, (b) => this.blacklist.Remove(b), (b) => b.label);
            }
            y += 40f;
            string listText = "";
            this.blacklist.ForEach(b => listText = b.label + "," + listText);
            Widgets.Label(new Rect(x + 315f, y, 300f, 60f), "BiomesBlackList".Translate() + listText);
        }

		public static CustomSite GenerateCustomSite(IEnumerable<SitePartDefWithParams> sitePartsParams, int tile, Faction faction, bool hiddenSitePartsPossible = false, RulePack singleSitePartRules = null)
		{
			Slate slate = QuestGen.slate;
			bool flag = false;
			using (IEnumerator<SitePartDefWithParams> enumerator = sitePartsParams.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.def.defaultHidden)
					{
						flag = true;
						break;
					}
				}
			}
			if (flag || hiddenSitePartsPossible)
			{
				SitePartParams parms = SitePartDefOf.PossibleUnknownThreatMarker.Worker.GenerateDefaultParams(0f, tile, faction);
				SitePartDefWithParams val = new SitePartDefWithParams(SitePartDefOf.PossibleUnknownThreatMarker, parms);
				sitePartsParams = sitePartsParams.Concat(Gen.YieldSingle<SitePartDefWithParams>(val));
			}
			CustomSite site = QuestNode_Root_CustomMap.MakeCustomSite(sitePartsParams, tile, faction, true);
			List<Rule> list = new List<Rule>();
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			List<string> list2 = new List<string>();
			int num = 0;
			for (int i = 0; i < site.parts.Count; i++)
			{
				List<Rule> list3 = new List<Rule>();
				Dictionary<string, string> dictionary2 = new Dictionary<string, string>();
				site.parts[i].def.Worker.Notify_GeneratedByQuestGen(site.parts[i], QuestGen.slate, list3, dictionary2);
				if (!site.parts[i].hidden)
				{
					if (singleSitePartRules != null)
					{
						List<Rule> list4 = new List<Rule>();
						list4.AddRange(list3);
						list4.AddRange(singleSitePartRules.Rules);
						string text = QuestGenUtility.ResolveLocalText(list4, dictionary2, "root", false);
						list.Add(new Rule_String("sitePart" + num + "_description", text));
						if (!text.NullOrEmpty())
						{
							list2.Add(text);
						}
					}
					for (int j = 0; j < list3.Count; j++)
					{
						Rule rule = list3[j].DeepCopy();
						Rule_String rule_String = rule as Rule_String;
						if (rule_String != null && num != 0)
						{
							rule_String.keyword = string.Concat(new object[]
							{
								"sitePart",
								num,
								"_",
								rule_String.keyword
							});
						}
						list.Add(rule);
					}
					foreach (KeyValuePair<string, string> keyValuePair in dictionary2)
					{
						string text2 = keyValuePair.Key;
						if (num != 0)
						{
							text2 = string.Concat(new object[]
							{
								"sitePart",
								num,
								"_",
								text2
							});
						}
						if (!dictionary.ContainsKey(text2))
						{
							dictionary.Add(text2, keyValuePair.Value);
						}
					}
					num++;
				}
			}
			if (!list2.Any<string>())
			{
				list.Add(new Rule_String("allSitePartsDescriptions", "HiddenOrNoSitePartDescription".Translate()));
				list.Add(new Rule_String("allSitePartsDescriptionsExceptFirst", "HiddenOrNoSitePartDescription".Translate()));
			}
			else
			{
				list.Add(new Rule_String("allSitePartsDescriptions", list2.ToClauseSequence().Resolve()));
				if (list2.Count >= 2)
				{
					list.Add(new Rule_String("allSitePartsDescriptionsExceptFirst", list2.Skip(1).ToList<string>().ToClauseSequence().Resolve()));
				}
				else
				{
					list.Add(new Rule_String("allSitePartsDescriptionsExceptFirst", "HiddenOrNoSitePartDescription".Translate()));
				}
			}
			QuestGen.AddQuestDescriptionRules(list);
			QuestGen.AddQuestNameRules(list);
			QuestGen.AddQuestDescriptionConstants(dictionary);
			QuestGen.AddQuestNameConstants(dictionary);
			QuestGen.AddQuestNameRules(new List<Rule>
			{
				new Rule_String("site_label", site.Label)
			});
			return site;
		}

		public static CustomSite MakeCustomSite(IEnumerable<SitePartDefWithParams> siteParts, int tile, Faction faction, bool ifHostileThenMustRemainHostile = true)
		{
			CustomSite site = (CustomSite)WorldObjectMaker.MakeWorldObject(QEDefOf.CQF_CustomSite);
			site.Tile = tile;
			site.SetFaction(faction);
			if (ifHostileThenMustRemainHostile && faction != null && faction.HostileTo(Faction.OfPlayer))
			{
				site.factionMustRemainHostile = true;
			}
			if (siteParts != null)
			{
				foreach (SitePartDefWithParams sitePartDefWithParams in siteParts)
				{
					site.AddPart(new SitePart(site, sitePartDefWithParams.def, sitePartDefWithParams.parms));
				}
			}
			site.desiredThreatPoints = site.ActualThreatPoints;
			return site;
		}

		public string buffer;
        public string bufferMin;
        public string siteIconPath;
        public string expandingIconPath;
        [NoTranslate]
        public SlateRef<string> storeAs;
		public string faction;
		public IntRange distance = new IntRange(10,20);
		public List<BiomeDef> blacklist = new List<BiomeDef>();
    }
}
