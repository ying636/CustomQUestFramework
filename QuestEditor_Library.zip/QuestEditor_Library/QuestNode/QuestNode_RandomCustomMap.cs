﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using RimWorld;
using UnityEngine;
using Verse;
using System.Text;

namespace QuestEditor_Library
{
    public class QuestNode_RandomCustomMap : QuestNode_Root_CustomMap
    {
        public override CustomMapDataDef GetMap()
        {
            List<string> defs = new List<string>();
            this.datas.Keys.ToList().ForEach(x => defs.Add(x));
            return DefDatabase<CustomMapDataDef>.GetNamed(GenCollection.RandomElementByWeight<string>(defs, (x) => this.datas[x]));
        }

        public override void Draw(ref float y, Rect inRect,float x)
        {
            base.Draw(ref y, inRect,x); 
            y += 10f;
            if (Widgets.ButtonText(new Rect(x + 5f, y, 150f, 35f), "AddMapData".Translate())) 
            {
                Find.WindowStack.Add(new QuestEditor_AddMapWithChance() {action = (data,chance) => this.datas.Add(data,chance)});
            }
            if (Widgets.ButtonText(new Rect(x + 155f, y, 150f, 35f), "DeleteMapData".Translate()))
            {
                List<FloatMenuOption> options = new List<FloatMenuOption>();
                foreach (KeyValuePair<string, float> data in this.datas)
                {
                    options.Add(new FloatMenuOption(data.Key,() => this.datas.Remove(data.Key)));
                }
                Find.WindowStack.Add(new FloatMenu(options));
            }
            y += 40f;
            StringBuilder datas = new StringBuilder();
            foreach (KeyValuePair<string, float> data in this.datas)
            {
                datas.AppendLine(data.Key + "，" +"Chance".Translate() + data.Value * 100f + "%");
            }
            Widgets.Label(new Rect(x + 7f, y, 350f, 500f), "MapDatas".Translate(datas.ToString()));
            y += 180f;
        }

        public Dictionary<string,float> datas = new Dictionary<string, float>();
    }

}
