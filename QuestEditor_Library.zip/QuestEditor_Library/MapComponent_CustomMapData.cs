﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;

namespace QuestEditor_Library
{
    public class MapComponent_CustomMapData : MapComponent
    {
        public MapComponent_CustomMapData(Map map) : base(map)
        {

        }
        public Dictionary<Building, List<PawnSpawnData>> PawnSpawnDatas_Building
        {
            get 
            {
                if (this.pawnSpawnDatas_Building == null) 
                {
                    this.pawnSpawnDatas_Building = new Dictionary<Building, List<PawnSpawnData>>();
                }
                return this.pawnSpawnDatas_Building;
            }
        }
        public string QuestTag => this.questTag.NullOrEmpty() ? null : this.questTag;
        public override void MapComponentTick()
        {
            base.MapComponentTick();
            if (!this.init)
            {
                this.init = true;
                this.map?.spawnedThings?.ToList().ListFullCopy().ForEach(t =>
                {
                    if (t is CustomMapEntrance entrance && entrance.CustomMap?.Parent is MapParent_Custom parent)
                    {
                        this.AddSubMap(parent);
                    }
                });
            }
            this.pawnSpawnDatas_Tick?.ForEach(data =>
            {
                data.time++;
                if (data.time > data.data.timeToSpawn)
                {
                    data.time = 0;
                    int count = data.data.count.RandomInRange;
                    for (int i = 0; i < count; i++)
                    {
                        data.data.Spawn(data.position, this.map, QuestTag);
                    }
                }
            });
        }
        public void AddSubMap(MapParent_Custom sub)
        {
            if (!this.subMaps.Contains(sub)) 
            {
                this.subMaps.Add(sub);
            }
        }
        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref this.questTag,"questTag");
            Scribe_Collections.Look(ref this.subMaps, "QE_MapComponent_CustomMapData_subMaps",LookMode.Reference);
            Scribe_Collections.Look(ref this.designatedAndMap, "CQF_MapComponent_designatedAndMap", LookMode.Reference, LookMode.Reference);

            Scribe_Collections.Look(ref this.pawnSpawnDatas_Building, "QE_LordJob_DefendAndPatrol_pawnSpawnDatas_Building", LookMode.Reference, LookMode.Deep, ref this.tmpBuildings, ref this.tmpPawnDatas);
            Scribe_Collections.Look(ref this.pawnSpawnDatas_Tick, "QE_LordJob_DefendAndPatrol_pawnSpawnDatas_Tick", LookMode.Deep);
        }

        public bool init = false;
        public List<MapParent_Custom> subMaps = new List<MapParent_Custom>();
        public Dictionary<Thing, Thing> designatedAndMap = new Dictionary<Thing, Thing>();

        public Dictionary<Building, List<PawnSpawnData>> pawnSpawnDatas_Building = new Dictionary<Building, List<PawnSpawnData>>();
        public List<Building> tmpBuildings = new List<Building>();
        public List<List<PawnSpawnData>> tmpPawnDatas = new List<List<PawnSpawnData>>();
        public List<PawnDataWithPosAndTime> pawnSpawnDatas_Tick = new List<PawnDataWithPosAndTime>();

        public string questTag = "";
    }
}
