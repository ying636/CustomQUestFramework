﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace QuestEditor_Library
{
    public class Dialog_RenameForQE : Dialog_Rename
    {
        public Dialog_RenameForQE()
        {
        }
        public Dialog_RenameForQE(Action<string> rename) 
        {
            this.rename = rename;
        }
        public override Vector2 InitialSize
        {
            get
            {
                return new Vector2(280f, 205f);
            }
        }
        protected override void SetName(string name)
        {
            this.rename(name);
        }
        public Action<string> rename;
    }
}
