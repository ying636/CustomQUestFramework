﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace QuestEditor_Library
{
    public class Dialog_Select<T> : Window
    {
        public Dialog_Select(List<T> ts, Func<T, Texture2D> getTexture, Func<T, string> getText,string title,Action<T> acceptAction,Func<T, Color> getColor = null,Action<T,Rect> drawAction = null)
        {
            this.ts = ts;
            this.getTexture = getTexture;
            this.getText = getText;
            this.acceptAction = acceptAction;
            this.title = title;
            this.getColor = getColor;
            this.drawAction = drawAction;
            this.forceCatchAcceptAndCancelEventEvenIfUnfocused = true;
            this.closeOnAccept = false;
            this.closeOnCancel = false; 
            this.forcePause = true;
            this.absorbInputAroundWindow = true;
            this.closeOnClickedOutside = false;
            this.doCloseX = true;
        }

        public override void DoWindowContents(Rect inRect)
        {         
            List<T> items = new List<T>();
            if (this.terms == "")
            {
                items = this.ts;
            }
            else 
            {
                foreach (T t in this.ts) 
                {
                    string text = this.getText(t);
                    if (text.Contains(this.terms)) 
                    {
                        items.Add(t);
                    }
                }
            }
            float height = 40f + (this.getTexture == null ? items.Count * 30f : (items.Count * 40f / 500f) * 30f);
            Widgets.BeginScrollView(new Rect(0f,0f,this.InitialSize.x,this.InitialSize.y), ref this.pos,new Rect(0f,0f,this.InitialSize.x,this.InitialSize.y > height ? this.InitialSize.y : height));
            Text.Font = GameFont.Medium;
            Widgets.Label(new Rect(0f, 0f,this.InitialSize.x,35f), this.title);
            Text.Font = GameFont.Small;
            this.terms = Widgets.TextField(new Rect(0f, this.Margin + 17f,300f, 25f),this.terms);
            float y = this.Margin + 43f;
            float x = 0f;
            Rect rect;
            foreach (T t in items) 
            {
                rect = new Rect(x, y,this.getTexture != null ? 30f : 150f, 25f);
                if (this.getTexture != null)
                {
                    if (this.getColor != null && this.getColor(t) is Color color) 
                    {
                        GUI.color = color;
                    }
                    if (this.drawAction != null)
                    {
                        this.drawAction(t,rect);
                        if (Widgets.ButtonInvisible(rect)) 
                        {
                            this.acceptAction(t);
                            this.Close();
                        }
                    }
                    else
                    {
                        if (Widgets.ButtonImage(rect, this.getTexture(t)))
                        {
                            this.acceptAction(t);
                            this.Close();
                        }
                    }
                    GUI.color = Color.white;
                    x += 35f;
                    if (x + 70f > this.InitialSize.x)
                    {
                        x = 0f;
                        y += 30f;
                    }
                }
                else 
                {
                    if (Widgets.ButtonText(rect,this.getText(t),false))
                    {
                        this.acceptAction(t);
                        this.Close();
                    }
                    y += 30f;
                }
                if (Mouse.IsOver(rect))
                {
                    TooltipHandler.TipRegion(rect, this.getText(t));
                }
            }
            Widgets.EndScrollView();
        }

        public string title;
        public string terms = "";
        public List<T> ts;
        public Action<T> acceptAction;
        public Func<T, Texture2D> getTexture;
        public Func<T, Color> getColor;
        public Func<T, string> getText;
        public Action<T, Rect> drawAction;
        public Vector2 pos = Vector2.zero;
    }
}
