﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace QuestEditor_Library
{
    public class Dialog_EditDialogResult : Window
    {
        public Dialog_EditDialogResult(QuestEditor_Dialog parent,DialogResult result, DialogOption option, DialogNode node) 
        {
            this.parent = parent;
            this.node = node;
            this.option = option;
            this.result = result;
            this.doCloseX = true;
            this.closeOnClickedOutside = false;
            this.draggable = true;
            this.forcePause = true;
            this.absorbInputAroundWindow = true;
            this.onlyOneOfTypeAllowed = false;
            this.forceCatchAcceptAndCancelEventEvenIfUnfocused = true;
            this.closeOnAccept = false;
            this.closeOnCancel = false;
        }
        public override void Notify_ClickOutsideWindow()
        {
        }
        public override void DoWindowContents(Rect inRect)
        {
            DialogTreeDef tree = this.parent.CurTree;
            Widgets.BeginScrollView(inRect, ref this.scrollPosition, new Rect(0f, 0f, inRect.width - 20f, this.height));
            EditorTools.DrawLabelAndText_Line(0f, "ResultName".Translate(), ref this.result.resultName, 0f, 150f);
            float y = 30f;
            string nextNodeText = "Null".Translate();
            if (this.result.nextIndex != null && tree.nodeMoulds.TryGetValue(this.result.nextIndex.Value, out DialogNode node))
            {
                nextNodeText = node.text;
            }
            Rect nextRect = new Rect(0f, y, 150f, 20f);
            if (Widgets.ButtonText(nextRect, "NextNode".Translate(nextNodeText), false) && this.result.nextIndex != null)
            {
                this.Close();
                if (Find.WindowStack.Windows.ToList().Find(x => x.GetType() == typeof(QuestEditor_EditDialogNode)) is Window window)
                {
                    window.Close();
                }
                Find.WindowStack.Add(new QuestEditor_EditDialogNode(tree.nodeMoulds[this.result.nextIndex.Value], this.parent));
            }
            TooltipHandler.TipRegion(nextRect, "NextNodeTip".Translate());
            nextRect.x = inRect.width - 160f;
            if (Widgets.ButtonText(nextRect, "SelectNode".Translate()))
            {
                EditorTools.DrawFloatMenu(tree.nodeMoulds, (i, n) =>
                {
                    tree.ChangeNextNodeToOtherNode(this.node, n, this.result);
                    this.parent.InitCurTree();
                }, (i, n) => n.text, new List<FloatMenuOption>()
                {
                    new FloatMenuOption("AddNewNode".Translate(),() =>
                {
                    tree.ChangeNextNodeToOtherNode(this.node,tree.CreateNewNode(this.node),this.result,true);
                    this.parent.InitCurTree();
                })
                ,
                    new FloatMenuOption("Null".Translate(), () =>
                {
                    tree.ChangeNextNodeToOtherNode(this.node, null, this.result);
                    this.parent.InitCurTree();
                })
                }, (i, n) => n.index != this.result.nextIndex);
            }
            y += 30f;
            Widgets.Label(new Rect(0f, y, 150f, 25f), "CQFActions".Translate().Colorize(ColorLibrary.SkyBlue));
            y += 30f;
            foreach (CQFAction action in this.result.actions)
            {
                action.Draw(ref y, inRect, 0);
            }
            y += 10f;
            EditorTools.DrawButtonForList<CQFAction>(ref y,this.result.actions,a => a.GetType().Name.Translate(), () => EditorTools.DrawFloatMenu(typeof(CQFAction).AllSubclassesNonAbstract(), a =>
 this.result.actions.Add((CQFAction)Activator.CreateInstance(a)), a => a.Name.Translate()));
            y += 30f;
            EditorTools.DrawIDrawList(ref y,0f,this.result.conditions,inRect, "DialogConditions".Translate().Colorize(ColorLibrary.SkyBlue));
            Widgets.EndScrollView();
            this.height = y;
        }

        public float height = 0f;
        public DialogOption option;
        public DialogNode node;
        public QuestEditor_Dialog parent;
        public DialogResult result;
        private Vector2 scrollPosition;
    }
}
