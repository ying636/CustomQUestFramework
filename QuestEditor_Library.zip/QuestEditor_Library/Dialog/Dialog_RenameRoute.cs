﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using Verse;

namespace QuestEditor_Library
{
    public class Dialog_RenameRoute : Dialog_Rename
    {
        public Dialog_RenameRoute(string old, Dialog_ManageRoute dialog) 
        {
            this.old = old;
            this.dialog = dialog;
        }
        protected override void SetName(string name)
        {
            this.dialog.rename.Add(old,name);
        }

        public string old;
        public Dialog_ManageRoute dialog;
    }
}
