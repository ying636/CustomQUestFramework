﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace QuestEditor_Library
{
    public class Dialog_EditDialogOption : Window
    {
        public Dialog_EditDialogOption(QuestEditor_Dialog parent,DialogOption option,DialogNode node) 
        {
            this.parent = parent;
            this.node = node;
            this.option = option;
            this.doCloseX = true;
            this.closeOnClickedOutside = false;
            this.draggable = true;
            this.forcePause = true;
            this.absorbInputAroundWindow = true;
            this.onlyOneOfTypeAllowed = false;
            this.forceCatchAcceptAndCancelEventEvenIfUnfocused = true;
            this.closeOnAccept = false;
            this.closeOnCancel = false;
        }
        public override void Notify_ClickOutsideWindow()
        {
        }
        public override void DoWindowContents(Rect inRect)
        {
            DialogTreeDef tree = this.parent.CurTree;
            Widgets.BeginScrollView(inRect, ref this.scrollPosition, new Rect(0f, 0f, inRect.width - 20f, this.height));
            EditorTools.DrawLabelAndText_Line(0f, "OptionText".Translate(), ref this.option.text, 0f, 150f);
            float y = 30f;
            Widgets.CheckboxLabeled(new Rect(0f,y,150f,25f),"HideWhenDisable".Translate(),ref this.option.hideWhenDisabled);
            y += 30f;
            List<Type> thingDatas = typeof(LootThingData).AllSubclassesNonAbstract().ListFullCopy();
            thingDatas.Remove(typeof(CQFThingCategoryCount));
            EditorTools.DrawIDrawList(ref y, 0f, this.option.requiredThings, inRect, "InteractionOption_RequiredThing".Translate(), () =>
            EditorTools.DrawFloatMenu(thingDatas, t =>
            {
                LootThingData.OpenSelectWindow(t, d => this.option.requiredThings.Add(d));
            }, t => t.Name.Translate()), t => t.ToString(),(t,y2,rect,x) => 
            {
                t.DrawWithSingleCount(ref y2,rect,x);
                return y2;
            });
            y += 30f;
            Widgets.Label(new Rect(0f, y, 150f, 25f), "DialogConditions".Translate().Colorize(ColorLibrary.SkyBlue));
            y += 30f;
            foreach (DialogCondition condition in this.option.conditions)
            {
                condition.Draw(ref y,inRect,0f);
            }
            Rect nextRect = new Rect(0f, y, 150f, 20f);
            nextRect.width = 100f;
            nextRect.y = y;
            nextRect.x = 10f;
            if (Widgets.ButtonText(nextRect, "AddDialogCondition".Translate()))
            {
                EditorTools.DrawFloatMenu(typeof(DialogCondition).AllSubclassesNonAbstract(), x => this.option.conditions.Add((DialogCondition)Activator.CreateInstance(x)), x => x.Name.Translate());
            }
            nextRect.x = inRect.width - 160f;
            if (Widgets.ButtonText(nextRect, "Delete".Translate()))
            {
                EditorTools.DrawFloatMenu(this.option.conditions, x => this.option.conditions.Remove(x), x => x.GetType().Name.Translate());
            }
            y += 30f; 
            float x2 = 0f;
            Widgets.Label(new Rect(x2, y, 255f, 25f), "DialogResults".Translate().Colorize(ColorLibrary.SkyBlue));
            y += 30f;
            Vector2 start = new Vector2(x2, y);
            Vector2 end = new Vector2(inRect.width - (x2 * 2) - 10f, y);
            Widgets.DrawLine(start, end, ColorLibrary.SkyBlue, 1f);
            foreach (DialogResult d in this.option.results)
            {
                y += 5f;
                if (Widgets.ButtonText(new Rect(x2,y,500f,25f),d.resultName,false)) 
                {
                    if (Find.WindowStack.Windows.ToList().Find(x => x.GetType() == typeof(Dialog_EditDialogResult)) is Window window)
                    {
                        window.Close();
                    }
                    Find.WindowStack.Add(new Dialog_EditDialogResult(this.parent,d,this.option,this.node));
                }
                y += 30f;
                start.y = y;
                end.y = y;
                Widgets.DrawLine(start, end, ColorLibrary.SkyBlue, 1f);
            }
            y += 25f;
            EditorTools.DrawButtonForList(ref y, this.option.results, d => d.GetType().Name.Translate(), () => this.option.results.Add(new DialogResult()));
            Widgets.EndScrollView();
            this.height = y;
        }

        public float height = 0f;
        public DialogOption option;
        public DialogNode node;
        public QuestEditor_Dialog parent;
        private Vector2 scrollPosition;
    }
}
