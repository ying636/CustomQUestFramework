﻿using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace QuestEditor_Library
{
    public class Dialog_InteractionOption : Window
    {
        public Dialog_InteractionOption(InteractionOperation operation)
        {
            this.operation = operation;
            this.forceCatchAcceptAndCancelEventEvenIfUnfocused = true;
            this.closeOnAccept = false;
            this.closeOnCancel = false; 
            this.forcePause = true;
            this.absorbInputAroundWindow = true;
            this.closeOnClickedOutside = false;
            this.doCloseX = true;
        }
        public override void DoWindowContents(Rect inRect)
        {
            float x = 8f;
            Widgets.BeginScrollView(new Rect(0f,0f,inRect.width,inRect.height), ref this.pos,new Rect(0f,0f,inRect.width,this.height + 10f));
            Widgets.DrawBox(new Rect(0f,3f,inRect.width - 20f, this.height), 1, QuestEditor_Dialog.blueTex);
            float curX = 10f;
            Text.Font = GameFont.Medium;
            Widgets.Label(new Rect(curX,5f,inRect.width,35f), this.operation.interactionText.Colorize(ColorLibrary.SkyBlue));    
            float y = 45f; 
            Text.Font = GameFont.Small;
            if (Widgets.ButtonText(new Rect(curX, y, 150f, 25f), "Rename".Translate()))
            {
                Find.WindowStack.Add(new Dialog_RenameForQE((name) => this.operation.interactionText = name));
            }
            y += 30f;
            EditorTools.DrawLabelAndText_Line(y,"TickToOperate".Translate(),ref this.operation.tickToOperate,ref this.buffer,curX);
            y += 30f;
            List<Type> thingDatas = typeof(LootThingData).AllSubclassesNonAbstract().ListFullCopy();
            thingDatas.Remove(typeof(CQFThingCategoryCount));
            EditorTools.DrawIDrawList(ref y, x, this.operation.requiredThings, inRect, "InteractionOption_RequiredThing".Translate(), () =>
            EditorTools.DrawFloatMenu(thingDatas, t =>
            {
                LootThingData.OpenSelectWindow(t,d => this.operation.requiredThings.Add(d));
            },t => t.Name.Translate()), t => t.ToString(), (t, y2, rect, x2) =>
            {
                t.DrawWithSingleCount(ref y2, rect, x2);
                return y2;
            });
            float initY = y;
            y += 15f;
            Widgets.Label(new Rect(curX + 5f, y,inRect.width, 30f), "InteractionConditions".Translate().Colorize(ColorLibrary.PaleBlue));
            y += 25f;
            this.operation.conditions.ForEach(c => 
            {
                c.Draw(ref y,inRect, curX);
            });
            y += 10f;
            EditorTools.DrawButtonForList(ref y,this.operation.conditions,c => c.GetType().Name.Translate(),() => EditorTools.DrawFloatMenu(typeof(DialogCondition).AllSubclassesNonAbstract(),c =>
            this.operation.conditions.Add((DialogCondition)Activator.CreateInstance(c)),c => c.Name.Translate()), 10, 150f);
            y += 5f; 
            Widgets.DrawBox(new Rect(x, initY, inRect.width - 40f - (2 * x), y - initY), 1, QuestEditor_Dialog.blueTex);
            y += 5f;
            initY = y;
            y += 5f;
            Widgets.Label(new Rect(curX + 5f, y,inRect.width, 30f), "InteractionResults".Translate().Colorize(ColorLibrary.PaleBlue));
            y += 35f;
            this.operation.results.ForEach(c =>
            {    
                y += 3f;
                c.Draw(ref y,inRect,curX + 5f);
                y += 3f;
            });
            y += 10f;
            EditorTools.DrawButtonForList<InteractionResult>(ref y, this.operation.results, c => c.resultName,10,150f);
            y += 5f;
            Widgets.DrawBox(new Rect(x, initY, inRect.width - 40f - (2 * x), y - initY), 1, QuestEditor_Dialog.blueTex);
            y += 5f;
            Widgets.EndScrollView();
            this.height = y + 5f;
        }

        public string buffer;
        public float height;
        public InteractionOperation operation;
        public Vector2 pos = Vector2.zero;
    }
}
