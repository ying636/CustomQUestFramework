﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI.Group;

namespace QuestEditor_Library
{
    public class DialogManagerDef : Def, ISaveable, IExposable
    {
        public void Draw(ref float y)
        {
            float last = 80f;
            Dictionary<int, DialogTreeAndConditions> replaces = new Dictionary<int, DialogTreeAndConditions>();
            foreach (DialogTreeAndConditions tree in this.trees)
            {
                int index = this.trees.IndexOf(tree);
                Rect rect = new Rect(10f, y, 350f, 40f);
                Widgets.DrawBox(new Rect(5f, y - 5f, 350f, this.heights.ContainsKey(index) ? this.heights[index] - 40f : 0f), 1, QuestEditor_Dialog.blueTex);
                y += 10f;
                rect.height = 30f;
                if (Widgets.ButtonText(rect, "DialogTree".Translate(tree.tree?.defName), false))
                {
                    List<DialogTreeDef> trees = new List<DialogTreeDef>();
                    trees.AddRange(DefDatabase<DialogTreeDef>.AllDefsListForReading);
                    trees.AddRange(EditorTools.GetObject<DialogTreeDef>(Page_QuestEditor.Path + @"\DialogTree\", "//QuestEditor_Library.DialogTreeDef"));
                    EditorTools.DrawFloatMenu<DialogTreeDef>(trees, (x) =>
                    {
                        replaces.Add(index, new DialogTreeAndConditions(x, tree.conditions));
                    }, (x) => x.defName);
                }
                y += 30;
                Text.Font = GameFont.Medium;
                Widgets.Label(new Rect(10f, y, 100f, 30f), "Conditions".Translate().Colorize(ColorLibrary.SkyBlue));
                Text.Font = GameFont.Small;
                y += 40f;
                foreach (DialogTreeCondition condition in tree.conditions)
                {
                    condition.Draw(ref y);
                }
                y += 5f;
                Rect button = new Rect(10f, y, 100f, 30f);
                if (Widgets.ButtonText(button, "Add".Translate()))
                {
                    EditorTools.DrawFloatMenu<Type>(typeof(DialogTreeCondition).AllSubclassesNonAbstract(), (x) =>
                    {
                        DialogTreeCondition c = (DialogTreeCondition)Activator.CreateInstance(x);
                        tree.conditions.Add(c);
                    }, x => x.Name.Translate());
                }
                button.x += 110f;
                if (Widgets.ButtonText(button, "Delete".Translate()) && tree.conditions.Any())
                {
                    EditorTools.DrawFloatMenu<DialogTreeCondition>(tree.conditions, (x) =>
                    {
                        tree.conditions.Remove(x);
                    }, x => x.GetType().Name.Translate());
                }
                y += 90f;
                this.heights.SetOrAdd(index, y - last);
                last = y;
            }
            foreach (KeyValuePair<int, DialogTreeAndConditions> replace in replaces)
            {
                this.trees[replace.Key] = replace.Value;
            }
        }
        public DialogTreeDef GetTree(Thing interviewer, Thing target)
        {
            foreach (DialogTreeAndConditions tree in this.trees)
            {
                if (tree.conditions == null || !tree.conditions.Any() || !tree.conditions.Exists(c => !c.Satisfied(interviewer, target)))
                {
                    if (tree.tree != null)
                    {
                        return tree.tree;
                    }
                }
            }
            return null;
        }
        public XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            result.Add(new XElement("defName", this.defName));
            XElement nodes = new XElement("trees");
            this.trees.ForEach(t => nodes.Add(t.SaveToXElement("li")));
            result.Add(nodes);
            return result;
        }

        public void ExposeData()
        {
            Scribe_Collections.Look(ref this.trees, "DialogManager_trees", LookMode.Deep);
        }

        public Dictionary<int, float> heights = new Dictionary<int, float>();
        public List<DialogTreeAndConditions> trees = new List<DialogTreeAndConditions>();
    }

    public class DialogTreeAndConditions : ISaveable, IExposable
    {
        public DialogTreeAndConditions()
        {
        }
        public DialogTreeAndConditions(DialogTreeDef tree, List<DialogTreeCondition> conditions)
        {
            this.tree = tree;
            this.conditions = conditions;
        }
        public XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            XElement nodes = new XElement("tree", this.tree.defName);
            XElement conditions = new XElement("conditions");
            this.conditions.ForEach(c => conditions.Add(c.SaveToXElement("li")));
            result.Add(nodes);
            result.Add(conditions);
            return result;
        }

        public void ExposeData()
        {
            Scribe_Defs.Look(ref this.tree, "DialogTreeAndConditions_tree");
            Scribe_Collections.Look(ref this.conditions, "DialogManager_conditions", LookMode.Deep);
        }

        public DialogTreeDef tree;
        public List<DialogTreeCondition> conditions;
    }

    public abstract class DialogTreeCondition : ISaveable, IExposable
    {
        public virtual void Draw(ref float y)
        {
            Widgets.Label(new Rect(10f, y, 150f, 25f), this.GetType().Name.Translate().Colorize(ColorLibrary.SkyBlue));
            y += 30f;
        }
        public abstract void ExposeData();
        public abstract bool Satisfied(Thing interviewer, Thing target);
        public abstract XElement SaveToXElement(string nodeName);
    }

    public class DialogTreeCondition_Faction : DialogTreeCondition
    {
        public override XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            result.Add(new XElement("faction", this.faction.defName));
            return result;
        }
        public override void Draw(ref float y)
        {
            base.Draw(ref y);
            Rect rect = new Rect(10f, y, 150f, 25f);
            Widgets.Label(rect, "Faction".Translate() + ":" + this.faction?.label);
            rect.x = 160f;
            if (Widgets.ButtonText(rect, "Select".Translate()))
            {
                EditorTools.DrawFloatMenu(DefDatabase<FactionDef>.AllDefsListForReading, x => this.faction = x, x => x.label);
            }
            y += 30f;
        }

        public override bool Satisfied(Thing interviewer, Thing target)
        {
            return target.Faction?.def == this.faction;
        }

        public override void ExposeData()
        {
            Scribe_Defs.Look(ref this.faction, "DialogTreeCondition_Faction_faction");
        }

        public FactionDef faction;
    }
    public class DialogTreeDef : Def, ISaveable
    {
        public void AddIdleNode(DialogNode node)
        {
            this.idleNodes.Add(node);
            node.subNodeIndexs.ForEach(i =>
            {
                DialogNode subNode = this.nodeMoulds[i];
                if (this.IsIdleNode(subNode))
                {
                    this.AddIdleNode(subNode);
                }
            });
        }
        public bool IsIdleNode(DialogNode node)
        {
            return !this.nodeMoulds.Values.ToList().Exists(x => x.options.Exists(o => o.results.Exists(r => r.nextIndex == node.index)));
        }
        public void ChangeNextNodeToOtherNode(DialogNode parent, DialogNode newNode,DialogResult result, bool isNewNode = false)
        {
            DialogNode oldNode = result.nextIndex == null ? null : this.nodeMoulds[result.nextIndex.Value];
            if (newNode != null)
            {
                if (this.idleNodes.Contains(newNode) || isNewNode)
                {
                    parent.subNodeIndexs.Add(newNode.index);
                }
                if (this.idleNodes.Contains(newNode))
                {
                    this.idleNodes.Remove(newNode);
                }
                result.nextIndex = newNode.index;
            }
            else
            {
                result.nextIndex = null;
            }
            if (oldNode != null)
            {
                parent.subNodeIndexs.Remove(oldNode.index);
                this.AddIdleNode(oldNode);
            }
        }
        public DialogNode CreateNewNode(DialogNode parent)
        {
            DialogNode result = new DialogNode(this.curIndex);
            this.nodeMoulds.Add(this.curIndex, result);
            this.curIndex++;
            if (parent != null)
            {
                result.parentIndex = parent.index;
            }
            return result;
        }
        public Dialog_NodeTree CreateDialog(Thing interviwer, Thing interviwee)
        {
            string targetText = interviwee is Pawn pawnTarget ? pawnTarget.Name.ToStringFull : interviwee.Label;
            Dictionary<int, DiaNode> nodes = new Dictionary<int, DiaNode>();
            string interviewrText = interviwer is Pawn ? interviwer.Label : ((Pawn)interviwer).Name.ToStringFull;
            foreach (KeyValuePair<int, DialogNode> nodeMould in this.nodeMoulds)
            {
                string text;
                if (interviwee is Pawn targetPawn2)
                {
                    text = nodeMould.Value.text.Translate().Formatted(interviwer.Named("Interviewer"), targetPawn2.Named("Interviewee")).AdjustedFor(targetPawn2, "Interviewee", true).Resolve();
                }
                else
                {

                    text = nodeMould.Value.text.Translate(targetText, interviewrText);

                }
                DiaNode node = new DiaNode(text);
                nodeMould.Value.options.ForEach(o =>
                {
                    DiaOption option = new DiaOption(o.text.Translate(targetText, interviewrText));
                    foreach (DialogCondition condition in o.conditions)
                    {
                        Dictionary<string, TargetInfo> targets = new Dictionary<string, TargetInfo>();
                        targets.Add("Interviewee", interviwee);
                        targets.Add("Interviewer", interviwer);
                        string reason = "Unkonw";
                        if ((!condition?.Satisfied(targets, out reason)).Value)
                        {
                            option.Disable(reason);
                        }

                    }
                    if (o.requiredThings.Any())
                    {
                        if (interviwer.Map.IsPlayerHome)
                        {
                            if (!GameTools.CheckRequiredThings(o.requiredThings, GameTools.AllConsumableThing(interviwer.Map).ToList(), out ThingDef def, out int count))
                            {
                                option.Disable("NoRequiredTHing".Translate(def, count));
                            }
                        }
                        else
                        {
                            if (!GameTools.CheckRequiredThings(o.requiredThings, ((Pawn)interviwer).inventory.innerContainer.InnerListForReading, out ThingDef def, out int count))
                            {
                                option.Disable("NoRequiredTHing".Translate(def, count));
                            }
                        }
                    }
                    option.action = () =>
                    {
                        Dictionary<string, TargetInfo> targets = new Dictionary<string, TargetInfo>();
                        targets.Add("Interviewer", interviwer);
                        targets.Add("Interviewee", interviwee);
                        o.ProduceResult(interviwee, interviwer).actions.ForEach(a => a.Work(targets));
                        GameTools.ConsumeRequiredThings((Pawn)interviwer, (Pawn)interviwee,o.requiredThings);
                    };
                    if (!o.hideWhenDisabled || !option.disabled)
                    {
                        node.options.Add(option);
                    }
                });
                nodes.Add(nodeMould.Key, node);
            }
            foreach (KeyValuePair<int, DiaNode> node in nodes)
            {
                node.Value.options.ForEach(o =>
                {
                    string text = (string)(o.GetType().GetField("text", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(o));
                    int? nextIndex = this.nodeMoulds[node.Key]?.options?.Find(x => x.text.Translate(targetText, interviewrText) == text)?.ProduceResult(interviwee,interviwer).nextIndex;
                    if (nextIndex == null)
                    {
                        o.resolveTree = true;
                        return;
                    }
                    o.link = nodes[nextIndex.Value];
                });
            }
            if (!nodes.Any())
            {
                Log.Error("Create dialog error:Null node");
                return null;
            }
            Dialog_NodeTree result = new Dialog_NodeTree(nodes.First().Value, false, false, this.title.Translate(interviwer, interviwee));
            return result;
        }

        public XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            result.Add(new XElement("defName", this.defName));
            result.Add(new XElement("title", this.title));
            result.Add(new XElement("requireNonHostile", this.requireNonHostile));
            result.Add(new XElement("dialogReportKey", this.dialogReportKey));
            result.Add(new XElement("curIndex", this.curIndex));
            if (this.idleNodes.Any())
            {
                XElement idleNodes = new XElement("idleNodes");
                this.idleNodes.ForEach(x => idleNodes.Add(x.SaveToXElement("li")));
                result.Add(idleNodes);
            }
            XElement nodes = new XElement("nodeMoulds");
            foreach (KeyValuePair<int, DialogNode> nodeMould in this.nodeMoulds)
            {
                XElement li = new XElement("li");
                li.Add(new XElement("key", nodeMould.Key));
                li.Add(nodeMould.Value.SaveToXElement("value"));
                nodes.Add(li);
            }
            result.Add(nodes);
            return result;
        }

        public string title;
        public string dialogReportKey = "DefaultDialogKey";
        public bool requireNonHostile = true;
        public int curIndex = 1;
        public List<DialogNode> idleNodes = new List<DialogNode>();
        public Dictionary<int, DialogNode> nodeMoulds = new Dictionary<int, DialogNode>() { [0] = new DialogNode(0) };
    }

    public class DialogNode : ISaveable
    {
        public DialogNode()
        {
        }
        public DialogNode(int index)
        {
            this.index = index;
        }
        public DialogNode(int index, DialogNode parent)
        {
            this.index = index;
            parent.subNodeIndexs.Add(this.index);
        }
        public string DebugInformation(DialogTreeDef tree)
        {
            StringBuilder result = new StringBuilder();
            result.AppendLine("父节点索引：" + this.parentIndex);
            result.AppendLine("索引：" + this.index);
            result.AppendLine("子节点：");
            this.subNodeIndexs.ForEach(x => result.AppendLine(x.ToString()));
            result.AppendLine("所需空间：" + this.GetRequiredSpace(tree));
            return result.ToString().Trim();
        }
        public float GetRequiredSpace(DialogTreeDef tree)
        {
            float result = 0f;
            this.options.ForEach(o => result += o.GetRequiredSpace(tree));
            return Math.Max(result,40f);
        }
        public XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            result.Add(new XElement("text", this.text));
            result.Add(new XElement("index", this.index));
            if (this.parentIndex != null)
            {
                result.Add(new XElement("parentIndex", this.parentIndex));
            }
            XElement options = new XElement("options");
            this.options.ForEach(x =>
            {
                options.Add(x.SaveToXElement("li"));
            });
            XElement subNodeIndexs = new XElement("subNodeIndexs");
            this.subNodeIndexs.ForEach(x =>
            {
                subNodeIndexs.Add(new XElement("li", x));
            });
            result.Add(subNodeIndexs);
            result.Add(options);
            return result;
        }

        public string text = "New";
        public int index;
        public int? parentIndex = null;
        public List<DialogOption> options = new List<DialogOption>();
        public List<int> subNodeIndexs = new List<int>();
    }

    public class DialogOption : ISaveable
    {
        public DialogResult ProduceResult(Thing target,Thing interviwer) 
        {
            Dictionary<string, TargetInfo> targets = new Dictionary<string, TargetInfo>();
            targets.Add("Interviewee", target);
            targets.Add("Interviewer", interviwer);
            return this.results.Find(r => !r.conditions.Exists(c => !c.Satisfied(targets,out string reason)));
        }
        public float GetRequiredSpace(DialogTreeDef tree)
        {
            float result = 0f;
            List<DialogNode> subNodes = new List<DialogNode>();
            foreach (KeyValuePair<int, DialogNode> node in tree.nodeMoulds)
            {
                if (this.results.Exists(r => r.nextIndex == node.Key))
                {
                    subNodes.Add(node.Value);
                }
            }
            foreach (DialogNode node in subNodes)
            {
                result += node.GetRequiredSpace(tree);
            }
            return Math.Max(result, 40f);
        }
        public XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            result.Add(new XElement("text", this.text));
            result.Add(new XElement("hideWhenDisabled", this.hideWhenDisabled));
            //result.Add(new XElement("requiredThingsWillBeGivenToInterviewer", this.requiredThingsWillBeGivenToInterviewer));
            if (this.conditions.Any())
            {
                XElement conditions = new XElement("conditions");
                this.conditions.ForEach(c =>
                {
                    conditions.Add(c.SaveToXElement("li"));
                });     
                result.Add(conditions);
            }
            if (this.results.Any()) 
            {
                result.Add(EditorTools.SaveList_Saveable(this.results, "results"));
            }
            if (this.requiredThings.Any())
            {
                result.Add(EditorTools.SaveList_Saveable(this.requiredThings, "requiredThings"));
            }
            return result;
        }
        public string DebugInformation(DialogTreeDef tree)
        {
            StringBuilder result = new StringBuilder();
            result.AppendLine("所需空间：" + this.GetRequiredSpace(tree));
            return result.ToString().Trim();
        }
        public string text = "New";
        public bool hideWhenDisabled = false;
        public List<DialogCondition> conditions = new List<DialogCondition>();
        public List<DialogResult> results = new List<DialogResult>() {new DialogResult()};
        public List<LootThingData> requiredThings = new List<LootThingData>();
        //public bool requiredThingsWillBeGivenToInterviewer = false;
    }

    public class DialogResult : ISaveable
    {
        public XElement SaveToXElement(string nodeName)
        {
            XElement result = new XElement(nodeName);
            result.Add(new XElement("resultName",this.resultName));
            if (this.actions.Any())
            {
                XElement actions = new XElement("actions");
                this.actions.ForEach(x =>
                {
                    actions.Add(x.SaveToXElement("li"));
                });
                result.Add(actions);
            }
            if (this.nextIndex != null)
            {
                result.Add(new XElement("nextIndex", this.nextIndex));
            }
            if (this.conditions.Any())
            {
                XElement conditions = new XElement("conditions");
                this.conditions.ForEach(c =>
                {
                    conditions.Add(c.SaveToXElement("li"));
                });    
                result.Add(conditions);
            }
            return result;
        }

        public string resultName = "Undefined";
        public List<DialogCondition> conditions = new List<DialogCondition>();
        public List<CQFAction> actions = new List<CQFAction>();
        public int? nextIndex = null;
    }
}